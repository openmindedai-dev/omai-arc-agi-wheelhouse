#ifndef IKET_IKET_PROFILING_SESSION_H_
#define IKET_IKET_PROFILING_SESSION_H_

/**
 * @file iket_profiling_session.h
 * @brief Stable C ABI for in-process IKET profiling sessions.
 *
 * This header is intentionally valid as both C11 and C++17. It contains no
 * CUDA or C++ standard-library types, so C and Rust FFI clients can consume it
 * without parsing the wider IKET C++ API.
 *
 * Calls made exclusively through this C ABI are thread-safe and session
 * control is serialized process-wide. Only one profiling session may be
 * active at a time. Do not concurrently control sessions through both this
 * ABI and the C++ IketProfilingSession API.
 */

#include <stddef.h>
#include <stdint.h>

// Compile-time version of the C ABI declared by this header. Consumers can
// compare these values with IketProfilingSessionGetApiVersion() after loading
// the runtime library. The major version changes for incompatible ABI changes;
// the minor version changes for backward-compatible additions.
#define IKET_PROFILING_SESSION_API_VERSION_MAJOR UINT32_C(1)
#define IKET_PROFILING_SESSION_API_VERSION_MINOR UINT32_C(0)

// Values returned by this ABI. They match the corresponding iket::IketError
// values without importing the C++ enum into the FFI header.
#define IKET_PROFILING_SESSION_SUCCESS UINT32_C(0)
#define IKET_PROFILING_SESSION_INVALID_ARGUMENT UINT32_C(1)
#define IKET_PROFILING_SESSION_FEATURE_NOT_SUPPORTED UINT32_C(2)
#define IKET_PROFILING_SESSION_NOT_IMPLEMENTED UINT32_C(3)
#define IKET_PROFILING_SESSION_NOT_INSTRUMENTED UINT32_C(4)
#define IKET_PROFILING_SESSION_UNKNOWN_ERROR UINT32_C(5)
#define IKET_PROFILING_SESSION_INVALID_EVENT_RECORD UINT32_C(6)
#define IKET_PROFILING_SESSION_NO_INSTRUMENT_CONFIG UINT32_C(7)
#define IKET_PROFILING_SESSION_INVALID_STATE UINT32_C(8)
#define IKET_PROFILING_SESSION_DUPLICATE_OPERATION UINT32_C(9)
#define IKET_PROFILING_SESSION_IO_ERROR UINT32_C(13)
#define IKET_PROFILING_SESSION_INTERNAL_ERROR UINT32_C(14)

#ifndef IKET_API
#ifdef _WIN32
#define IKET_API __stdcall
#else
#define IKET_API
#endif
#endif

#ifdef _WIN32
#ifdef IKET_PROFILING_SESSION_EXPORTS
#define IKET_PROFILING_SESSION_C_EXPORT __declspec(dllexport)
#else
#define IKET_PROFILING_SESSION_C_EXPORT __declspec(dllimport)
#endif
#elif defined(__GNUC__) || defined(__clang__)
#define IKET_PROFILING_SESSION_C_EXPORT __attribute__((visibility("default")))
#else
#define IKET_PROFILING_SESSION_C_EXPORT
#endif

#ifdef __cplusplus
#ifndef IKET_NAMESPACE
#define IKET_NAMESPACE iket
#endif
namespace IKET_NAMESPACE {
extern "C" {
#endif

typedef uint32_t IketProfilingSessionResult;

// Trace only one logical cluster. This cannot be combined with lifetime-only capture.
#define IKET_PROFILING_SESSION_ENABLE_CLUSTER (UINT32_C(1) << 0)
// Keep launch buffers on the device until stop() or context destruction. IKET synchronizes the
// target context before collection; a persistent/non-terminating kernel can block stop().
#define IKET_PROFILING_SESSION_DEFER_TRACE_READBACK (UINT32_C(1) << 1)
// Leave instrumented kernel bodies untouched and capture only warp entry/exit timestamps.
// Without this flag, full tracing captures detailed events/ranges and warp lifetimes together.
#define IKET_PROFILING_SESSION_WARP_LIFETIME_ONLY (UINT32_C(1) << 2)

typedef uint32_t IketProfilingSessionLogLevelValue;
#define IKET_PROFILING_SESSION_LOG_ERROR UINT32_C(0)
#define IKET_PROFILING_SESSION_LOG_WARN UINT32_C(1)
#define IKET_PROFILING_SESSION_LOG_INFO UINT32_C(2)

typedef struct IketProfilingSessionClusterIndex {
    uint32_t x;
    uint16_t y;
    uint16_t z;
} IketProfilingSessionClusterIndex;

/**
 * C ABI representation of profiling-session configuration.
 *
 * Zero-initialize the struct, set struct_size to
 * sizeof(IketProfilingSessionOptions), then call
 * IketProfilingSessionOptionsInit() before changing individual fields.
 * profiled_cuda_contexts points to an array of opaque CUcontext values. An
 * empty array selects all CUDA contexts. IKET copies the array in
 * IketProfilingSessionSetOptions() and does not retain the pointer.
 * max_ts_per_warp must be in [1, UINT32_MAX].
 * IKET_PROFILING_SESSION_WARP_LIFETIME_ONLY records only warp entry and exit
 * timestamps and uses an effective timestamp budget of 1.
 *
 * Binary compatibility: the v1.0 prefix is 56 bytes and is permanently
 * accepted. Fields are append-only; later implementations default fields that
 * are absent from an older caller.
 */
typedef struct IketProfilingSessionOptions {
    uint32_t struct_size;
    uint32_t flags;
    uint64_t max_ts_per_warp;
    uint64_t device_buffer_size;
    const void* const* profiled_cuda_contexts;
    uint64_t num_profiled_cuda_contexts;
    IketProfilingSessionClusterIndex enabled_cluster;
    IketProfilingSessionLogLevelValue log_level;
} IketProfilingSessionOptions;

typedef struct IketProfilingSessionHandleImpl* IketProfilingSessionHandle;

/** Return the major and minor version of this C ABI. */
IKET_PROFILING_SESSION_C_EXPORT IketProfilingSessionResult IKET_API IketProfilingSessionGetApiVersion(uint32_t* major,
                                                                                                      uint32_t* minor);

/** Initialize options with the defaults used by IketProfilingSession. */
IKET_PROFILING_SESSION_C_EXPORT IketProfilingSessionResult IKET_API
IketProfilingSessionOptionsInit(IketProfilingSessionOptions* options);

/** Create an inactive session with default options. */
IKET_PROFILING_SESSION_C_EXPORT IketProfilingSessionResult IKET_API
IketProfilingSessionCreate(IketProfilingSessionHandle* session);

/**
 * Destroy a session. An active session is stopped first.
 * The handle is invalid after this call; any later use is undefined.
 */
IKET_PROFILING_SESSION_C_EXPORT IketProfilingSessionResult IKET_API
IketProfilingSessionDestroy(IketProfilingSessionHandle session);

/** Replace session options. The session must be inactive. */
IKET_PROFILING_SESSION_C_EXPORT IketProfilingSessionResult IKET_API
IketProfilingSessionSetOptions(IketProfilingSessionHandle session, const IketProfilingSessionOptions* options);

/** Begin profiling. Only one session may be active in a process. */
IKET_PROFILING_SESSION_C_EXPORT IketProfilingSessionResult IKET_API
IketProfilingSessionStart(IketProfilingSessionHandle session);

/** Stop profiling, collect trace data, and restore patched kernels. */
IKET_PROFILING_SESSION_C_EXPORT IketProfilingSessionResult IKET_API
IketProfilingSessionStop(IketProfilingSessionHandle session);

/** Discard all collected trace data. The session must be inactive. */
IKET_PROFILING_SESSION_C_EXPORT IketProfilingSessionResult IKET_API
IketProfilingSessionClearTraceData(IketProfilingSessionHandle session);

/**
 * Save collected traces in the current IKET decoded-results format.
 * The file is a same-version pipeline artifact, not a cross-version ABI.
 */
IKET_PROFILING_SESSION_C_EXPORT IketProfilingSessionResult IKET_API
IketProfilingSessionSaveTrace(IketProfilingSessionHandle session, const char* output_path);

#ifdef __cplusplus
}  // extern "C"
}  // namespace IKET_NAMESPACE

static_assert(sizeof(IKET_NAMESPACE::IketProfilingSessionClusterIndex) == 8);
static_assert(sizeof(IKET_NAMESPACE::IketProfilingSessionOptions) == 56);
static_assert(offsetof(IKET_NAMESPACE::IketProfilingSessionOptions, struct_size) == 0);
static_assert(offsetof(IKET_NAMESPACE::IketProfilingSessionOptions, flags) == 4);
static_assert(offsetof(IKET_NAMESPACE::IketProfilingSessionOptions, max_ts_per_warp) == 8);
static_assert(offsetof(IKET_NAMESPACE::IketProfilingSessionOptions, device_buffer_size) == 16);
static_assert(offsetof(IKET_NAMESPACE::IketProfilingSessionOptions, profiled_cuda_contexts) == 24);
static_assert(offsetof(IKET_NAMESPACE::IketProfilingSessionOptions, num_profiled_cuda_contexts) == 32);
static_assert(offsetof(IKET_NAMESPACE::IketProfilingSessionOptions, enabled_cluster) == 40);
static_assert(offsetof(IKET_NAMESPACE::IketProfilingSessionOptions, log_level) == 48);
#else
_Static_assert(sizeof(IketProfilingSessionClusterIndex) == 8, "IketProfilingSessionClusterIndex ABI drift");
_Static_assert(sizeof(IketProfilingSessionOptions) == 56, "IketProfilingSessionOptions ABI drift");
_Static_assert(offsetof(IketProfilingSessionOptions, struct_size) == 0, "IketProfilingSessionOptions ABI drift");
_Static_assert(offsetof(IketProfilingSessionOptions, flags) == 4, "IketProfilingSessionOptions ABI drift");
_Static_assert(offsetof(IketProfilingSessionOptions, max_ts_per_warp) == 8, "IketProfilingSessionOptions ABI drift");
_Static_assert(offsetof(IketProfilingSessionOptions, device_buffer_size) == 16,
               "IketProfilingSessionOptions ABI drift");
_Static_assert(offsetof(IketProfilingSessionOptions, profiled_cuda_contexts) == 24,
               "IketProfilingSessionOptions ABI drift");
_Static_assert(offsetof(IketProfilingSessionOptions, num_profiled_cuda_contexts) == 32,
               "IketProfilingSessionOptions ABI drift");
_Static_assert(offsetof(IketProfilingSessionOptions, enabled_cluster) == 40, "IketProfilingSessionOptions ABI drift");
_Static_assert(offsetof(IketProfilingSessionOptions, log_level) == 48, "IketProfilingSessionOptions ABI drift");
#endif

#endif  // IKET_IKET_PROFILING_SESSION_H_
