import os
import json
import argparse
import shutil
from copy import deepcopy
from pathlib import Path
from typing import List, Tuple, Dict, Optional
from subprocess import run, PIPE, STDOUT
from ..utils import iket_print

from ..profiler import (
    TrackerRecord,
    IketModuleConfig,
    module_select_resource,
    generate_config,
    IketPostprocessorV2,
    InstrumentConfig,
)
from ..profiler.utils import compute_required_buffer_size
from .common import DEFAULT_DEFER_TRACE_READBACK, IketConfig, parse_arg
from .base import IketRun
from .run_iket_timing import (
    RUN_IKET_STATS_FILENAME,
    RunIketTimings,
    measure_optional,
    measure_optional_postprocess_subphase,
    skip_optional,
)

INTERMEDIATE_OUTPUT_DIRS = ("tracker", "gen-config", "iket")

# Component limits for a cluster coordinate, matching the packing used on the C++ side
# (x: 32 bits, y/z: 16 bits each).
_ENABLED_CLUSTER_COMPONENT_LIMITS = (2**32, 2**16, 2**16)


def parse_enabled_cluster(value: str) -> Tuple[int, int, int]:
    """Parse a `--enabled-cluster X,Y,Z` argument into a coordinate tuple."""
    parts = value.split(",")
    if len(parts) != 3:
        raise ValueError(f"--enabled-cluster expects X,Y,Z (got {value!r})")
    coords = []
    for i, (p, limit) in enumerate(zip(parts, _ENABLED_CLUSTER_COMPONENT_LIMITS)):
        try:
            n = int(p, 10)
        except ValueError as e:
            raise ValueError(
                f"--enabled-cluster component {i} is not an integer: {p!r}"
            ) from e
        if n < 0 or n >= limit:
            raise ValueError(
                f"--enabled-cluster component {i} out of range [0, {limit}): {n}"
            )
        coords.append(n)
    return tuple(coords)


def normalize_enabled_cluster(value: object) -> Tuple[int, int, int]:
    """Normalize a raw coordinate string or revalidate a normalized tuple."""
    if isinstance(value, str):
        return parse_enabled_cluster(value)
    if not isinstance(value, tuple) or len(value) != 3:
        raise ValueError(
            "--enabled-cluster must be X,Y,Z or a normalized three-component tuple"
        )
    if not all(
        isinstance(component, int) and not isinstance(component, bool)
        for component in value
    ):
        raise ValueError(
            "--enabled-cluster normalized tuple must contain integer components"
        )
    for i, (component, limit) in enumerate(
        zip(value, _ENABLED_CLUSTER_COMPONENT_LIMITS)
    ):
        if component < 0 or component >= limit:
            raise ValueError(
                f"--enabled-cluster component {i} out of range [0, {limit}): {component}"
            )
    return value


def normalize_enabled_cluster_config(
    raw: object,
) -> Dict[str, Optional[List[int]]]:
    """Normalize a kernel-name-pattern mapping to cluster targets or full dumps."""
    if not isinstance(raw, dict):
        raise ValueError("--enabled-cluster-config must contain a JSON object")
    out: Dict[str, Optional[List[int]]] = {}
    for kernel_name_pattern, cluster_target in raw.items():
        if not isinstance(kernel_name_pattern, str):
            raise ValueError(
                "--enabled-cluster-config kernel-name patterns must be strings"
            )
        if cluster_target is None or cluster_target == "all":
            out[kernel_name_pattern] = None
            continue
        if (
            not isinstance(cluster_target, list)
            or len(cluster_target) != 3
            or not all(
                isinstance(component, int) and not isinstance(component, bool)
                for component in cluster_target
            )
        ):
            raise ValueError(
                f"cluster target for kernel-name pattern {kernel_name_pattern!r} "
                'must be [x, y, z], null, or "all"'
            )
        x, y, z = cluster_target
        for i, (component, limit) in enumerate(
            zip(cluster_target, _ENABLED_CLUSTER_COMPONENT_LIMITS)
        ):
            if component < 0 or component >= limit:
                raise ValueError(
                    f"cluster target for kernel-name pattern {kernel_name_pattern!r} "
                    f"component {i} out of range [0, {limit}): {component}"
                )
        out[kernel_name_pattern] = [x, y, z]
    return out


def load_enabled_cluster_config(path: Path) -> Dict[str, Optional[List[int]]]:
    """Load and validate a `--enabled-cluster-config` JSON file.

    The JSON object maps a kernel-name pattern to an enabled cluster [x, y, z] or
    a full dump selected by null or "all". Patterns support substring matching.
    "all" is normalized to None.
    """
    with open(path, encoding="utf-8") as f:
        raw = json.load(f)
    return normalize_enabled_cluster_config(raw)


def validate_and_normalize_profile_args(
    parser: argparse.ArgumentParser, args: argparse.Namespace
) -> None:
    """Validate profile arguments and replace their raw values with normalized data."""
    if args.warp_trace and (
        args.enabled_cluster is not None or args.enabled_cluster_config is not None
    ):
        parser.error(
            "--enabled-cluster/--enabled-cluster-config cannot be combined with --warp-trace"
        )

    try:
        if args.enabled_cluster is not None:
            args.enabled_cluster = normalize_enabled_cluster(args.enabled_cluster)
        if args.enabled_cluster_config is not None:
            if isinstance(args.enabled_cluster_config, dict):
                args.enabled_cluster_config = normalize_enabled_cluster_config(
                    args.enabled_cluster_config
                )
            elif isinstance(args.enabled_cluster_config, (str, os.PathLike)):
                args.enabled_cluster_config = load_enabled_cluster_config(
                    args.enabled_cluster_config
                )
            else:
                raise ValueError(
                    "--enabled-cluster-config must be a file path or normalized mapping"
                )
    except (OSError, ValueError) as error:
        parser.error(str(error))


def configure_iket(parser: argparse.ArgumentParser):
    """
    configure iket parser for profile command
    """
    default_postprocess = "perfetto"
    keep_intermediate_outputs = False
    parser.add_argument(
        "--use-config",
        type=str,
        help="use given config instead of auto-generated config",
    )
    parser.add_argument(
        "--use-tracker-dir", type=str, help="use given tracker dir and skip dryrun"
    )
    parser.add_argument(
        "--max-ts-cnt-per-warp",
        type=int,
        default=None,
        help="Tell profiler how many timestamps is possibly stored per warp as a hint to let profiler allocate buffer properly. Default: None auto detect from tracker",
        dest="max_ts_cnt_per_warp",
    )
    parser.add_argument(
        "--postprocess",
        type=str,
        choices=["perfetto", "json", "html", "none", "all"],
        default=default_postprocess,
        help="specify the post process option (default: %(default)s)",
    )
    parser.add_argument(
        "--keep",
        action=argparse.BooleanOptionalAction,
        default=keep_intermediate_outputs,
        help="keep intermediate profiling outputs (default: %(default)s)",
    )
    parser.add_argument(
        "--enable-stats",
        action="store_true",
        default=False,
        help="collect and report IKET profiling orchestration statistics",
    )
    parser.add_argument(
        "--warp-trace",
        dest="warp_trace",
        action="store_true",
        help=(
            "Enable warp-trace profiling: every non-internal kernel launch uses the entry/exit "
            "trampoline to record warp lifetimes, while body SASS is left unpatched and the "
            "tracker pre-pass is skipped."
        ),
    )
    parser.add_argument(
        "--defer-trace-readback",
        dest="defer_trace_readback",
        action=argparse.BooleanOptionalAction,
        default=DEFAULT_DEFER_TRACE_READBACK,
        help=(
            "Batch regular and CUDA Graph trace readback at collection points (default: enabled). "
            "Collection waits for all work in each target CUDA context; use "
            "--no-defer-trace-readback for eager per-launch readback."
        ),
    )
    parser.add_argument(
        "--enabled-cluster",
        type=str,
        default=None,
        metavar="X,Y,Z",
        help=(
            "Dump IKET timing data for only the CUDA cluster at coordinate X,Y,Z in the regular/minimum "
            "cluster grid. A non-cluster kernel counts as a 1x1x1 cluster, so the coordinate then "
            "selects a single thread block. For flexible-cluster launches the coordinate always "
            "addresses the regular/minimum cluster grid; the selected tile may be only part of a "
            "larger runtime cluster. Out-of-range coordinates fall back to cluster 0,0,0."
        ),
    )
    parser.add_argument(
        "--enabled-cluster-config",
        type=Path,
        default=None,
        metavar="FILE.json",
        help=(
            "Per-kernel cluster selection: JSON object mapping a kernel-name pattern to "
            '[x, y, z], null, or "all" (null/"all" force full dumping for matching kernels). '
            "Patterns are matched as substrings of the mangled kernel name. Exact matches take "
            "priority; otherwise the longest matching pattern wins. "
            "Kernels matching no entry use --enabled-cluster if given, else dump the full grid."
        ),
    )
    parser.set_defaults(
        func=run_iket,
        _validate_args=validate_and_normalize_profile_args,
    )


def merge_instrument_configs(configs: List[InstrumentConfig]) -> InstrumentConfig:
    if len(configs) == 0:
        return InstrumentConfig({"version": 1}, [])

    for cfg in configs:
        if cfg.meta != {"version": 1}:
            raise ValueError("instrument config meta must be {'version': 1}")

    modules_by_hash: Dict[str, Dict] = {}
    for cfg in configs:
        for module_cfg in cfg.modules:
            cubin_hash = module_cfg["hash"]
            existing = modules_by_hash.get(cubin_hash)
            if existing is None:
                modules_by_hash[cubin_hash] = deepcopy(module_cfg)
                continue
            if existing["size"] != module_cfg["size"]:
                raise ValueError(f"conflicting CUBIN sizes for hash {cubin_hash}")
            for kernel_name, function_cfgs in module_cfg["functions"].items():
                if kernel_name not in existing["functions"]:
                    existing["functions"][kernel_name] = deepcopy(function_cfgs)
                elif existing["functions"][kernel_name] != function_cfgs:
                    raise ValueError(
                        "conflicting instrument configs for "
                        f"CUBIN {cubin_hash}, kernel {kernel_name}"
                    )

    return InstrumentConfig({"version": 1}, list(modules_by_hash.values()))


def get_config_max_ts_cnt_per_warp(config: Dict) -> int:
    version = config["meta"]["version"]
    if version != 1:
        raise ValueError(f"instrument config version must be 1, got {version}")
    values = [
        function_cfg["maxTsCntPerWarp"]
        for module_cfg in config["modules"]
        for function_cfgs in module_cfg["functions"].values()
        for function_cfg in function_cfgs
    ]
    if not values:
        raise ValueError("instrument config contains no kernel configurations")
    return max(values)


def select_recommended_max_ts_cnt_per_warp(tracker_dirs: List[Path]) -> int:
    recommendations = []
    for process_tracker_dir in tracker_dirs:
        tracker_json_path = process_tracker_dir / "tracker.json"
        if tracker_json_path.exists():
            with open(tracker_json_path, "r") as f:
                tracker_data = json.load(f)
                if tracker_data is None:
                    iket_print(
                        f"Warning: tracker.json at {tracker_json_path} is empty or invalid"
                    )
                    continue
                if "recommended_max_ts_cnt_per_warp" in tracker_data:
                    recommendations.append(
                        tracker_data["recommended_max_ts_cnt_per_warp"]
                    )
                else:
                    iket_print(
                        f"Warning: 'recommended_max_ts_cnt_per_warp' not found in {tracker_json_path}"
                    )

    assert recommendations, "recommended_max_ts_cnt_per_warp is not found in tracker"
    return max(recommendations)


def run_tracker_and_generate_config(
    known: argparse.Namespace,
    runner: IketRun,
    enabled_cluster: Optional[Tuple[int, int, int]] = None,
    enabled_cluster_config: Optional[Dict[str, Optional[List[int]]]] = None,
    timings: Optional[RunIketTimings] = None,
) -> Tuple[int, Path, Optional[int]]:
    """
    Run tracker pass and generate instrument config.
    if use_config is provided, skip tracker pass and use the provided config directly.
    Returns (max_ts_cnt_per_warp, instrument_config_path, computed_buffer_size_or_none).
    """
    # The parsed cluster selections scale the auto-computed buffer pool down to the
    # cluster tiles that the profiling pass will allocate.
    if known.use_config:
        skip_optional(timings, "trackerWorkload")
        with measure_optional(timings, "configGeneration"):
            instrument_config_path = Path(known.use_config)
            assert instrument_config_path.exists()
            with open(instrument_config_path, "r") as f:
                instrument_config_data = json.load(f)
            max_ts_cnt_per_warp = get_config_max_ts_cnt_per_warp(instrument_config_data)
        return max_ts_cnt_per_warp, instrument_config_path, None

    if not known.use_tracker_dir:
        iket_print(
            "============= Dry run application first to collect some info... ============="
        )
        with measure_optional(timings, "trackerWorkload"):
            result = runner.launch_gpu_workload(
                "tracker",
                {},
                job="tracker",
            )
        if result.returncode != 0:
            iket_print(f"Tracker failed with return code: {result.returncode}")
            exit(1)
        tracker_dir = runner.get_output_dir("tracker")
    else:
        skip_optional(timings, "trackerWorkload")
        tracker_dir = Path(known.use_tracker_dir)

    with measure_optional(timings, "configGeneration"):
        tracker_dirs = []
        for subdir in tracker_dir.iterdir():
            if subdir.name.startswith("pid"):
                tracker = os.path.join(subdir, "tracker.json")
                if os.path.exists(tracker):
                    tracker_dirs.append(subdir)
                else:
                    iket_print("Tracker json not found in ", subdir)

        if known.max_ts_cnt_per_warp is None:
            max_ts_cnt_per_warp = select_recommended_max_ts_cnt_per_warp(tracker_dirs)
        else:
            max_ts_cnt_per_warp = known.max_ts_cnt_per_warp
            print(
                f"\nUsing user-specified max-ts-cnt-per-warp: {max_ts_cnt_per_warp}\n"
            )

        gen_config_dir = runner.get_output_dir("gen-config")
        if not gen_config_dir.exists():
            gen_config_dir.mkdir()

        all_cfgs: List[InstrumentConfig] = []
        tracker_records_with_configs = []
        for process_tracker_dir in tracker_dirs:
            tracker_record = TrackerRecord.parse_json(
                process_tracker_dir / "tracker.json"
            )
            iket_modules = tracker_record.make_iket_modules()
            modules_configs: Dict[int, IketModuleConfig] = {}
            for cubin_hash, iket_module in iket_modules.items():
                modules_configs[cubin_hash] = module_select_resource(
                    iket_module, max_ts_cnt_per_warp
                )
            configs = generate_config(modules_configs)
            all_cfgs.append(configs)
            tracker_records_with_configs.append((tracker_record, modules_configs))

        merged_cfg = merge_instrument_configs(all_cfgs)
        instrument_config_path = gen_config_dir / "instrument.config.json"
        with open(instrument_config_path, "w") as f:
            json.dump(merged_cfg.to_dict(), f, indent=2)

        computed_buffer_size = compute_required_buffer_size(
            tracker_records_with_configs,
            max_ts_cnt_per_warp,
            enabled_cluster=enabled_cluster,
            enabled_cluster_config=enabled_cluster_config,
        )

    return max_ts_cnt_per_warp, instrument_config_path, computed_buffer_size


def postprocess_results(
    known: argparse.Namespace,
    runner: IketRun,
    iket_job: str = "iket",
    timings: Optional[RunIketTimings] = None,
):
    """Run post-processing on self-contained raw captures."""
    iket_output_dir = runner.get_output_dir(iket_job)

    def measure(subphase):
        return measure_optional_postprocess_subphase(timings, subphase)

    for subdir in iket_output_dir.iterdir():
        if subdir.name.startswith("pid"):
            pid = subdir.name.split("_")[1]
            raw_capture_path = subdir / "iket.data.json"
            iket_postprocess_dir = runner.get_output_dir()
            with IketPostprocessorV2(
                raw_capture_path,
                measure=measure,
                enable_stats=timings is not None,
            ) as processor:
                trace_bytes = None
                if known.postprocess in ["perfetto", "all"]:
                    trace_bytes = processor.dump_perfetto(
                        iket_postprocess_dir / f"iket_pid_{pid}.pftrace"
                    )
                if known.postprocess in ["json", "all"]:
                    processor.dump_json(
                        iket_postprocess_dir / f"iket_pid_{pid}.trace.json"
                    )
                if known.postprocess in ["html", "all"]:
                    processor.dump_perfetto_html(
                        iket_postprocess_dir / f"iket_pid_{pid}.html", trace_bytes
                    )
                if timings is not None:
                    timings.record_raw_capture_decoder_stats(
                        processor.get_raw_capture_decoder_stats()
                    )


def is_relative_to(path: Path, parent: Path) -> bool:
    try:
        path.relative_to(parent)
        return True
    except ValueError:
        return False


def get_cleanup_protected_paths(known: argparse.Namespace) -> List[Path]:
    protected_paths = []
    for attr in ("use_tracker_dir", "use_config"):
        path = getattr(known, attr, None)
        if path:
            protected_paths.append(Path(path).expanduser().resolve(strict=False))
    return protected_paths


def cleanup_intermediate_outputs(known: argparse.Namespace, runner: IketRun):
    """Remove intermediate workflow directories after a successful profiling run."""
    if known.postprocess == "none":
        iket_print(
            "Warning: --postprocess none requested with --no-keep; no final trace artifact will remain."
        )

    output_dir = runner.get_output_dir()
    protected_paths = get_cleanup_protected_paths(known)
    for dirname in INTERMEDIATE_OUTPUT_DIRS:
        intermediate_dir = output_dir / dirname
        if intermediate_dir.exists():
            if intermediate_dir.is_symlink() or not intermediate_dir.is_dir():
                iket_print(
                    f"Skipping non-directory intermediate output path: {intermediate_dir}"
                )
                continue
            intermediate_path = intermediate_dir.expanduser().resolve(strict=False)
            if any(is_relative_to(path, intermediate_path) for path in protected_paths):
                iket_print(
                    f"Skipping intermediate output directory containing a user-supplied path: {intermediate_dir}"
                )
                continue
            iket_print(f"Removing intermediate output directory: {intermediate_dir}")
            shutil.rmtree(intermediate_dir)


def should_cleanup_intermediate_outputs(
    known: argparse.Namespace, runner: IketRun, iket_result
) -> bool:
    should_cleanup = not known.keep and iket_result.returncode == 0
    return should_cleanup


def make_warp_trace_stub_config(runner: IketRun) -> Path:
    """Write a minimal empty instrument config for warp-trace mode.

    Warp-trace mode never reads kernel-specific instrument info, but the IKET tool config
    still expects an appInstrument JSON path. Provide an empty v1 config that the
    configuration loader can accept.
    """
    gen_config_dir = runner.get_output_dir("gen-config")
    if not gen_config_dir.exists():
        gen_config_dir.mkdir()
    stub_path = gen_config_dir / "instrument.config.json"
    with open(stub_path, "w") as f:
        json.dump(
            {
                "meta": {"version": 1},
                "modules": [],
            },
            f,
        )
    return stub_path


def _run_iket_impl(
    known: argparse.Namespace,
    unknown: List[str],
    timings: Optional[RunIketTimings],
):
    enabled_cluster = getattr(known, "enabled_cluster", None)
    enabled_cluster_config = getattr(known, "enabled_cluster_config", None)

    runner = IketRun.create(known, unknown, require_cmd=True)
    if timings is not None:
        timings.set_output_dir(runner.get_output_dir())

    patch_mode_override = None
    if known.warp_trace:
        # Warp-trace mode: trampoline writes warp_start (header) + 4-byte warp_end (fixed slot)
        # for every launch; no body SASS patching, no per-instrument-point configs needed.
        # Skip the tracker pass entirely — its outputs (max_ts_cnt_per_warp, PMTRIG configs)
        # are all unused here. ts_cnt is always 1.
        from iket._core.iket import IketInstrumentPatchMode as PatchMode

        patch_mode_override = PatchMode.kWarpTrace
        max_ts_cnt_per_warp = 1
        skip_optional(timings, "trackerWorkload")
        with measure_optional(timings, "configGeneration"):
            instrument_config_path = make_warp_trace_stub_config(runner)
        computed_buffer_size = None
        iket_print(
            "Warp-trace mode enabled: tracker pass skipped, trampoline-only profiling. "
            "Use this run to capture warp lifetimes without body instrumentation."
        )
    else:
        # Pass 1: Tracker + config generation
        (
            max_ts_cnt_per_warp,
            instrument_config_path,
            computed_buffer_size,
        ) = run_tracker_and_generate_config(
            known,
            runner,
            enabled_cluster,
            enabled_cluster_config,
            timings,
        )

    # Apply auto-computed buffer size if user did not explicitly set one.
    # computed_buffer_size semantics:
    #   None  = no tracker data (e.g. --use-config or --warp-trace), keep the 1GB fallback
    #   0     = tracker ran, no kernel launches require a timestamp buffer
    #   >0    = tracker ran, computed the required buffer size
    if known.context_buffer_size is None and computed_buffer_size is not None:
        runner.context_buffer_size = computed_buffer_size
        if computed_buffer_size == 0:
            iket_print(
                "No kernel launches require a timestamp buffer; "
                "skipping context buffer allocation."
            )
        else:
            size_gb = computed_buffer_size / (1 << 30)
            iket_print(
                f"Auto-computed context buffer size: "
                f"{size_gb:.2f} GB "
                f"({computed_buffer_size:,} bytes)"
            )
            if size_gb > 10:
                iket_print(
                    f"WARNING: IKET will allocate {size_gb:.2f} GB of device memory for "
                    f"warp buffers. This may cause the workload to run out of GPU memory. "
                    f"Consider using --context-buffer-size to set a smaller value, or reduce "
                    f"the number of instrumented kernel launches."
                )

    # Only forward the cluster-selection kwargs when set, so callers/tests that construct
    # IketConfig (or a stand-in) without knowledge of these newer fields keep working.
    cluster_config_kwargs = {}
    if enabled_cluster is not None:
        cluster_config_kwargs["enabled_cluster"] = enabled_cluster
    if enabled_cluster_config is not None:
        cluster_config_kwargs["enabled_cluster_config"] = enabled_cluster_config

    tool_config = IketConfig(
        max_ts_cnt_per_warp,
        instrument_config_path,
        patch_mode=patch_mode_override,
        **cluster_config_kwargs,
    )
    iket_print("============= Run application for real profiling... =============")
    skip_profiling_workload = False
    if skip_profiling_workload:
        skip_optional(timings, "profilingWorkload")
    with measure_optional(
        None if skip_profiling_workload else timings, "profilingWorkload"
    ):
        iket_result = runner.launch_gpu_workload(
            "iket", tool_config.to_dict(), job="iket"
        )

    should_postprocess = known.postprocess != "none" and iket_result.returncode == 0
    if should_postprocess:
        with measure_optional(timings, "postprocess"):
            postprocess_results(known, runner, "iket", timings)
    else:
        skip_optional(timings, "postprocess")

    if should_cleanup_intermediate_outputs(known, runner, iket_result):
        with measure_optional(timings, "cleanup"):
            cleanup_intermediate_outputs(known, runner)
    else:
        skip_optional(timings, "cleanup")

    return iket_result


def run_iket(known: argparse.Namespace, unknown: List[str]):
    timings = RunIketTimings() if getattr(known, "enable_stats", False) else None
    try:
        return _run_iket_impl(known, unknown, timings)
    finally:
        if timings is not None:
            timings.finish()
            timings.print_summary()
            try:
                timings.write_report()
            except Exception as exc:
                iket_print(f"Warning: could not write {RUN_IKET_STATS_FILENAME}: {exc}")
