"""Shared safety helpers for tool-owned CLI output directories."""

import os
import sys
from pathlib import Path
from typing import Optional


DEFAULT_OUTPUT_DIR_NAME = "iket_output"


class UnsafeOutputDirError(RuntimeError):
    """Raised when a tool-owned output directory must not be deleted."""


def _resolve_dir(path: Path) -> Path:
    """Resolve a directory path for comparison, without requiring it to exist."""
    return Path(path).expanduser().resolve(strict=False)


def _is_same_or_ancestor(candidate: Path, other: Path) -> bool:
    """Return True if `candidate` is `other` itself or one of its ancestors."""
    return candidate == other or candidate in other.parents


def _stdin_is_interactive() -> bool:
    """Return True only when stdin can actually answer a prompt."""
    stdin = getattr(sys, "stdin", None)
    if stdin is None:
        return False
    try:
        return bool(stdin.isatty())
    except (AttributeError, ValueError):
        # Detached or already-closed stdin: treat as non-interactive.
        return False


def check_output_dir_is_safe(
    output_dir: Path,
    working_dir: Optional[Path] = None,
    *,
    owner_name: str = "run-iket",
    example_output_dir_name: str = DEFAULT_OUTPUT_DIR_NAME,
) -> Path:
    """Reject an output directory that a CLI tool must never own or delete.

    The output directory itself must not be a symlink. The resolved directory
    must also not be the current/workload directory or an ancestor of either.
    The returned resolved path is the exact path callers may delete.
    """
    if Path(output_dir).is_symlink():
        raise UnsafeOutputDirError(
            f"Refusing to use {output_dir} as the {owner_name} output directory: "
            f"it is a symlink, and {owner_name} could destroy "
            f"{Path(output_dir).resolve(strict=False)} instead of the link. Pass "
            "--output-dir with a real directory."
        )

    resolved_output_dir = _resolve_dir(output_dir)
    protected_dirs = [_resolve_dir(Path(os.getcwd()))]
    if working_dir is not None:
        protected_dirs.append(_resolve_dir(working_dir))

    for protected_dir in protected_dirs:
        if not _is_same_or_ancestor(resolved_output_dir, protected_dir):
            continue
        relation = "is" if resolved_output_dir == protected_dir else "contains"
        raise UnsafeOutputDirError(
            f"Refusing to use {resolved_output_dir} as the {owner_name} output "
            f"directory: it {relation} the working directory {protected_dir}, and "
            f"{owner_name} may delete and recreate its output directory. Pass "
            "--output-dir with a dedicated directory (for example --output-dir "
            f"./{example_output_dir_name})."
        )

    return resolved_output_dir
