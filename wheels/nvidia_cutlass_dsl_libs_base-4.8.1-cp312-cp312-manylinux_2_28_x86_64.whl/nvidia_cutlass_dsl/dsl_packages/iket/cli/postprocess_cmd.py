import argparse
from pathlib import Path
from typing import List


def configure_postprocess(parser: argparse.ArgumentParser):
    """Configure parser for the postprocess subcommand."""
    parser.add_argument(
        "run_dir",
        type=str,
        help="Path to an existing IKET run output directory",
    )
    parser.add_argument(
        "--format",
        type=str,
        choices=["perfetto", "json", "html", "all"],
        default="all",
        help="Output format (default: all)",
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        default=None,
        help="Output directory for generated files (default: same as run_dir)",
    )
    parser.set_defaults(func=postprocess)


class _PostprocessResult:
    """Minimal result object matching the interface expected by entrypoint()."""

    def __init__(self, returncode: int):
        self.returncode = returncode


def _iket_print(*args, **kwargs):
    try:
        from ..utils import iket_print

        iket_print(*args, **kwargs)
    except Exception:
        print("[run-iket]", *args, **kwargs)


def postprocess(known: argparse.Namespace, unknown: List[str]):
    """Run postprocessing on an existing IKET run directory."""
    del unknown

    run_dir = Path(known.run_dir).resolve()
    if not run_dir.is_dir():
        _iket_print(f"Error: run directory does not exist: {run_dir}")
        return _PostprocessResult(1)

    output_dir = Path(known.output_dir).resolve() if known.output_dir else run_dir
    output_dir.mkdir(parents=True, exist_ok=True)

    iket_output_dir = run_dir / "iket"
    if not iket_output_dir.is_dir():
        _iket_print(f"Error: no iket/ subdirectory found in {run_dir}")
        return _PostprocessResult(1)

    from ..profiler.postprocess import IketPostprocessorV2

    processed = 0

    for subdir in sorted(iket_output_dir.iterdir()):
        if not subdir.name.startswith("pid"):
            continue

        pid = subdir.name.split("_")[1]
        raw_capture_path = subdir / "iket.data.json"
        if not raw_capture_path.exists():
            _iket_print(f"Warning: no raw capture found in {subdir}, skipping")
            continue

        _iket_print(f"Post-processing results for pid {pid}...")
        try:
            with IketPostprocessorV2(raw_capture_path) as processor:
                trace_bytes = None
                if known.format in ["perfetto", "all"]:
                    perfetto_path = output_dir / f"iket_pid_{pid}.pftrace"
                    trace_bytes = processor.dump_perfetto(perfetto_path)
                    _iket_print(f"  -> {perfetto_path}")

                if known.format in ["html", "all"]:
                    html_path = output_dir / f"iket_pid_{pid}.html"
                    processor.dump_perfetto_html(html_path, trace_bytes)
                    _iket_print(f"  -> {html_path}")

                if known.format in ["json", "all"]:
                    json_path = output_dir / f"iket_pid_{pid}.trace.json"
                    processor.dump_json(json_path)
                    _iket_print(f"  -> {json_path}")
        except Exception as exc:
            _iket_print(
                f"Error: could not post-process raw capture for pid {pid}: {exc}."
            )
            return _PostprocessResult(1)

        processed += 1

    if processed == 0:
        _iket_print("Error: no pid_* directories with raw captures found")
        return _PostprocessResult(1)

    _iket_print(f"Post-processing complete. {processed} pid(s) processed.")
    return _PostprocessResult(0)
