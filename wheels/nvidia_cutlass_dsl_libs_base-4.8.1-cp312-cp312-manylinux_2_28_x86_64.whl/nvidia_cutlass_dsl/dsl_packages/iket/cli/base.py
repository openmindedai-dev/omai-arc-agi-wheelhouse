import os
import re
import sys
import argparse

import time
import shutil

from typing import List, Dict, Optional, Callable
from pathlib import Path
from subprocess import run, PIPE, STDOUT, Popen, CompletedProcess

from ..profiler import default_injection_lib
from .common import DEFAULT_DEFER_TRACE_READBACK, InjectionConfig, parse_arg
from .output_dir import (
    DEFAULT_OUTPUT_DIR_NAME,
    UnsafeOutputDirError,
    _stdin_is_interactive,
    check_output_dir_is_safe,
)
from ..utils import iket_print


# Environment variable prefixes of the CuTe-family DSLs. Each DSL reads only
# its own <PREFIX>_COMPILER_OPT (no cross-prefix fallback), so every prefix
# must be handled independently.
CUTE_DSL_FAMILY_PREFIXES = [
    "CUTE_DSL",  # @cute.jit
    "CUTE_EXPERIMENTAL_DSL",  # @cute.experimental.jit
]

# CuTe DSL accepts comma- or space-separated option tokens with an optional
# "--" prefix and an optional "{...}", "={...}" or "=value" argument. The whole
# token is matched, including its argument and the separator that follows it, so
# the same pattern both detects iket and removes it in one substitution without
# leaving argument fragments or doubled delimiters behind. The leading separator
# is matched with a lookbehind so removal never eats a neighbouring token's
# delimiter; the other tokens keep their original separators.
_IKET_OPT_RE = re.compile(
    r"(?:^|(?<=[\s,]))(?:--)?iket(?:=?\{[^}]*\}|=[^\s,]*)?(?:[\s,]+|$)"
)


def _append_iket_to_compiler_opt(existing_opt: str) -> Optional[str]:
    r"""Return the new *_COMPILER_OPT value with iket enabled, or None if it
    already is.

    The appended token is separated by a space, never a comma: the CuTe DSL
    option parser matches name=value tokens with a greedy `=([\S]+)` that only
    stops at whitespace, so "name=value,iket" would swallow ",iket" into the
    value while a space-separated token always parses.
    """
    if _IKET_OPT_RE.search(existing_opt):
        # return None if iket is already enabled
        return None
    return f"{existing_opt} iket" if existing_opt else "iket"


def _strip_iket_from_compiler_opt(existing_opt: str) -> Optional[str]:
    """Return the *_COMPILER_OPT value with the iket token removed, or None if
    it is not present.

    The token takes its trailing separator with it, so only a dangling
    separator at either end can be left over.
    """
    if not _IKET_OPT_RE.search(existing_opt):
        return None
    return _IKET_OPT_RE.sub("", existing_opt).strip(", \t")


def _cute_dsl_iket_env_updates(env: Dict[str, str]) -> Dict[str, str]:
    """Env updates that keep iket ops alive for every CuTe-family DSL.

    CuTe-family DSLs strip iket ops at JIT compile time by default; appending
    "iket" to each DSL's <PREFIX>_COMPILER_OPT makes them survive into LLVM
    lowering so the injection tool can patch them. Values the user already set
    are preserved per variable.
    """
    updates: Dict[str, str] = {}
    for dsl_prefix in CUTE_DSL_FAMILY_PREFIXES:
        opt_var = f"{dsl_prefix}_COMPILER_OPT"
        new_opt = _append_iket_to_compiler_opt(env.get(opt_var, ""))
        if new_opt is not None:
            updates[opt_var] = new_opt
    return updates


def _cute_dsl_iket_env_removals(env: Dict[str, str]) -> Dict[str, str]:
    """Env updates that let every CuTe-family DSL strip iket ops (the JIT
    default), even when the surrounding environment pre-enables them.

    Used for uninstrumented baseline runs (overhead comparison): only
    variables that currently enable iket are rewritten, everything else in
    them is preserved.
    """
    updates: Dict[str, str] = {}
    for dsl_prefix in CUTE_DSL_FAMILY_PREFIXES:
        opt_var = f"{dsl_prefix}_COMPILER_OPT"
        if opt_var in env:
            new_opt = _strip_iket_from_compiler_opt(env[opt_var])
            if new_opt is not None:
                updates[opt_var] = new_opt
    return updates




def configure_base(parser: argparse.ArgumentParser):
    default_log_level = "error"

    log_level_choices = ["error", "warn", "info"]
    parser.add_argument(
        "--context-buffer-size",
        type=str,
        default=None,
        help="size of extra device buffer allocated per context. "
        "Default: auto-computed from tracker data, fallback 1G.",
    )
    parser.add_argument(
        "--log-level",
        type=str,
        choices=log_level_choices,
        default=default_log_level,
        help=f"default: {default_log_level}",
    )


    parser.add_argument("--working-dir", type=str)
    parser.add_argument(
        "--output-dir",
        "-o",
        type=str,
        help="directory for profiling outputs. run-iket owns this directory and removes it "
        "when clobbering, so it must not be the working directory itself. "
        f"Default: <working-dir>/{DEFAULT_OUTPUT_DIR_NAME}",
    )
    parser.add_argument(
        "--clobber", action="store_true", help="clobber existing output directory"
    )


def default(val: object, default: object):
    if val is not None:
        return val
    else:
        return default


class IketRunResult:
    def __init__(self, returncode: int, outputs: List[str]):
        self.returncode = returncode
        self.outputs = outputs


class IketRun:
    def __init__(
        self,
        cmd: list[str],
        clobber: bool,
        context_buffer_size: int,
        log_level: str,
        working_dir: Optional[Path] = None,
        base_output_dir: Optional[Path] = None,
        defer_trace_readback: bool = DEFAULT_DEFER_TRACE_READBACK,
        dsl_iket: bool = True,
    ):
        self.cmd = cmd

        self.clobber = clobber
        self.context_buffer_size = context_buffer_size
        self.log_level = log_level
        self.dsl_iket = dsl_iket
        self.defer_trace_readback = defer_trace_readback

        if not working_dir:
            self.working_dir = Path(os.getcwd()).absolute()
        else:
            self.working_dir = working_dir.absolute()

        if not base_output_dir:
            # Never default to the working directory itself: run-iket clobbers
            # and cleans up whatever directory it is given.
            self._output_dir = self.working_dir / DEFAULT_OUTPUT_DIR_NAME
            iket_print(f"No --output-dir given, using {self._output_dir}")
        else:
            self._output_dir = base_output_dir.absolute()

        check_output_dir_is_safe(self._output_dir, self.working_dir)


        if self._output_dir.exists():
            if self.clobber or self._confirm_output_dir_removal():
                self._remove_output_dir()
            else:
                iket_print(
                    f"Output directory {self._output_dir} already exists. Exit now. Please use --clobber to overwrite or confirm removal."
                )
                sys.exit(1)
        os.makedirs(self._output_dir, exist_ok=True)

    def _confirm_output_dir_removal(self) -> bool:
        """Ask the user whether the existing output directory may be removed.

        Prompting only makes sense on a terminal: in a non-interactive run (CI,
        a pipe, nohup) there is nobody to answer and input() would raise
        EOFError instead of telling the user what to do.
        """
        if not _stdin_is_interactive():
            iket_print(
                f"Output directory {self._output_dir} already exists and stdin is not a terminal, "
                "so its removal cannot be confirmed interactively. Re-run with --clobber to "
                "overwrite it, or pass --output-dir with a new directory."
            )
            sys.exit(1)

        user_input = (
            input(
                f"[run-iket] Output directory {self._output_dir} already exists. Remove it? [y/N]: "
            )
            .strip()
            .lower()
        )
        return user_input == "y"

    def _remove_output_dir(self) -> None:
        """Remove the output directory, re-checking that it is safe to delete."""
        # Deliberately redundant with the check in __init__: this is the call
        # that can destroy a user's directory, so it validates its own target.
        # rmtree gets the exact path the check returned - never a re-resolved one -
        # so the path that was validated is the path that is removed.
        validated_output_dir = check_output_dir_is_safe(
            self._output_dir, self.working_dir
        )
        iket_print(f"Removing existing output directory: {self._output_dir}")
        shutil.rmtree(validated_output_dir)

    def get_output_dir(self, job: str = ""):
        if job:
            return self._output_dir / job
        else:
            return self._output_dir

    def get_injection_config_name(self, job: str = ""):
        if job:
            return f"{job}.config.json"
        else:
            return "config.json"

    @property
    def injection_lib_path(self):
        return default_injection_lib

    def launch_gpu_workload(
        self,
        tool: str,
        tool_config: dict,
        env: Dict[str, str] = {},
        job: str = "",
        extra_env: Dict[str, str] = {},
    ):
        """
        Launch a GPU workload.

        args:
            tool: the name of the tool, could be tracker, iket
            tool_config: the config of the tool
            env: the environment variables
        """
        if not env:
            env = os.environ.copy()

        job_output_dir = self.get_output_dir(job)
        if not job_output_dir.exists():
            job_output_dir.mkdir()

        injection_config_path = job_output_dir / self.get_injection_config_name(job)

        if tool:
            injection_config = InjectionConfig(
                self.context_buffer_size,
                job_output_dir,
                tool,
                tool_config,
                self.log_level,
                defer_trace_readback=self.defer_trace_readback,
            )
            injection_config.save(injection_config_path)

            injection_envs: Dict[str, str] = {
                "CUDA_INJECTION64_PATH": self.injection_lib_path,
                "IKET_INJECTION_CONFIG": f"{injection_config_path}",
            }
        else:
            # dry run
            injection_envs = {}


        if self.dsl_iket:
            cute_dsl_envs = _cute_dsl_iket_env_updates(env)
        else:
            cute_dsl_envs = _cute_dsl_iket_env_removals(env)


        env.update(cute_dsl_envs)
        env.update(injection_envs)
        env.update(extra_env)

        outputs: List[str] = []
        returncode: int = None

        should_run = True
        if should_run:
            proc = Popen(
                self.cmd, stdout=PIPE, stderr=STDOUT, env=env, cwd=self.working_dir
            )

            while True:
                stdout_lines = proc.stdout.readlines()
                if not stdout_lines:
                    returncode = proc.poll()
                    if returncode is not None:
                        break

                for line_bytes in stdout_lines:
                    line = line_bytes.decode().rstrip("\n")
                    print(
                        line
                    )  # use print instead of iket_print to avoid unnecessary prefix
                    outputs.append(line)

                time.sleep(0.1)

            if returncode != 0:
                iket_print(
                    f"Launch GPU workload exits abnormally with return code: {returncode} => Tool: {tool}, Job: {job}"
                )
                iket_print(
                    "Re-run the same run-iket command and keep the output directory "
                    "when reporting the issue."
                )

        result = IketRunResult(returncode, outputs)

        return result

    @staticmethod
    def create(
        known: argparse.Namespace, unknown: list[str], *, require_cmd: bool = True
    ) -> "IketRun":
        """
        parse the arguments and create the IketRun instance.

        args:
            known: the known arguments
            unknown: the unknown arguments
            require_cmd: whether to require the command

        return the IketRun instance
        """
        if require_cmd and (not unknown or unknown == ["--"]):
            raise RuntimeError("Missing command")
        elif unknown:
            # FORCE our users to add '--'
            if unknown[0] != "--":
                raise RuntimeError(f'Command MUST start with "--"!')
            else:
                cmd = unknown[1:]
        else:
            cmd = []

        clobber = known.clobber
        if known.context_buffer_size is not None:
            context_buffer_size = IketRun.parse_context_buffer_size(
                known.context_buffer_size
            )
        else:
            context_buffer_size = (
                1 << 30
            )  # 1GB fallback, may be overridden by auto-detection

        working_dir: Path = parse_arg(
            known.working_dir, ctor=Path, default=Path(os.getcwd())
        )
        # No default here: IketRun picks a dedicated subdirectory of the working
        # directory, because the working directory itself must never be clobbered.
        base_output_dir: Optional[Path] = parse_arg(known.output_dir, ctor=Path)



        return IketRun(
            cmd=cmd,
            clobber=clobber,
            context_buffer_size=context_buffer_size,
            log_level=known.log_level,
            working_dir=working_dir,
            base_output_dir=base_output_dir,
            defer_trace_readback=getattr(
                known, "defer_trace_readback", DEFAULT_DEFER_TRACE_READBACK
            ),
            dsl_iket=getattr(known, "dsl_iket", True),
        )

    @staticmethod
    def parse_context_buffer_size(s: str):
        if s.isdigit():
            return int(s)
        else:
            assert len(s) > 1 and s[-1] in (
                "k",
                "K",
                "m",
                "M",
                "g",
                "G",
            ), f"Invalid context buffer size => {s}"
            unit = 1
            if s[-1] in ("k", "K"):
                unit = 1 << 10
            elif s[-1] in ("m", "M"):
                unit = 1 << 20
            elif s[-1] in ("g", "G"):
                unit = 1 << 30

            base = int(s[:-1])
            return base * unit
