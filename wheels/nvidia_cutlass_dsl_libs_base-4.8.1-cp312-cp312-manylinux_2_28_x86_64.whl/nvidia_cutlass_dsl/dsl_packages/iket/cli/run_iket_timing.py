import json
import time
from contextlib import contextmanager, nullcontext
from pathlib import Path
from typing import Callable, Iterator, Optional

from ..utils import iket_print

RUN_IKET_STATS_FILENAME = "run-iket.stats.json"

_TIMING_PHASE_LABELS = {
    "trackerWorkload": "tracker workload",
    "configGeneration": "config generation",
    "profilingWorkload": "profiling workload",
    "postprocess": "postprocess",
    "cleanup": "cleanup",
}

_POSTPROCESS_SUBPHASE_LABELS = {
    "rawCaptureDecoderInit": "raw-capture decoder init",
    "perfettoTraceExport": "C++ Perfetto trace export",
    "decodedJsonExport": "decoded JSON export",
    "pftraceWrite": "Perfetto trace write",
    "optionalOutput": "optional output",
}

_RAW_CAPTURE_DECODER_SUBPHASE_LABELS = {
}


class RunIketTimings:
    """Collect monotonic wall-clock timings for run-iket orchestration."""

    def __init__(self, clock: Optional[Callable[[], int]] = None):
        self._clock = clock or time.perf_counter_ns
        self._start_ns = self._clock()
        self._total_ns: Optional[int] = None
        self._output_dir: Optional[Path] = None
        self._phases = {
            name: {"status": "notRun", "durationNs": None}
            for name in _TIMING_PHASE_LABELS
        }
        self._phases["postprocess"]["subphases"] = {
            name: {"status": "notRun", "durationNs": None}
            for name in _POSTPROCESS_SUBPHASE_LABELS
        }

    def set_output_dir(self, output_dir: Path) -> None:
        self._output_dir = output_dir

    @contextmanager
    def measure(self, phase: str) -> Iterator[None]:
        if phase not in self._phases:
            raise ValueError(f"Unknown run-iket timing phase: {phase}")
        if self._phases[phase]["status"] != "notRun":
            raise RuntimeError(f"run-iket timing phase already recorded: {phase}")

        start_ns = self._clock()
        try:
            yield
        except BaseException:
            self._phases[phase] = {
                "status": "failed",
                "durationNs": max(0, self._clock() - start_ns),
                **(
                    {"subphases": self._phases[phase]["subphases"]}
                    if phase == "postprocess"
                    else {}
                ),
            }
            raise
        else:
            self._phases[phase] = {
                "status": "completed",
                "durationNs": max(0, self._clock() - start_ns),
                **(
                    {"subphases": self._phases[phase]["subphases"]}
                    if phase == "postprocess"
                    else {}
                ),
            }
            if phase == "postprocess":
                self._skip_unrecorded_postprocess_subphases()

    @contextmanager
    def measure_postprocess_subphase(self, subphase: str) -> Iterator[None]:
        """Measure and accumulate one postprocess subphase.

        A subphase may run once per captured process, so repeated measurements
        add to the same duration instead of being rejected.
        """
        subphases = self._phases["postprocess"]["subphases"]
        if subphase not in subphases:
            raise ValueError(f"Unknown postprocess timing subphase: {subphase}")

        result = subphases[subphase]
        if result["status"] == "skipped":
            raise RuntimeError(
                f"postprocess timing subphase already skipped: {subphase}"
            )

        start_ns = self._clock()
        try:
            yield
        except BaseException:
            self._accumulate_duration(result, self._clock() - start_ns)
            result["status"] = "failed"
            raise
        else:
            self._accumulate_duration(result, self._clock() - start_ns)
            result["status"] = "completed"

    def skip(self, phase: str) -> None:
        if phase not in self._phases:
            raise ValueError(f"Unknown run-iket timing phase: {phase}")
        if self._phases[phase]["status"] == "notRun":
            self._phases[phase]["status"] = "skipped"
            if phase == "postprocess":
                self._skip_unrecorded_postprocess_subphases()

    def record_raw_capture_decoder_stats(
        self, stats: dict[str, dict[str, int]]
    ) -> None:
        """Accumulate raw-capture decoder timings under their Python call."""
        subphases = self._phases["postprocess"]["subphases"]
        for parent_name, decoder_stats in stats.items():
            if parent_name not in ("rawCaptureDecoderInit", "perfettoTraceExport"):
                # Stats are diagnostic and may gain decoder parents before Python learns
                # how to present them. Never fail an otherwise valid profiling run.
                continue
            parent = subphases[parent_name]
            children = parent.setdefault("subphases", {})
            for child_name, duration_ns in decoder_stats.items():
                child = children.setdefault(
                    child_name, {"status": "completed", "durationNs": None}
                )
                self._accumulate_duration(child, duration_ns)

    @staticmethod
    def _accumulate_duration(result: dict, duration_ns: int) -> None:
        duration_ns = max(0, duration_ns)
        previous_duration_ns = result["durationNs"]
        result["durationNs"] = duration_ns + (
            previous_duration_ns if previous_duration_ns is not None else 0
        )

    def _skip_unrecorded_postprocess_subphases(self) -> None:
        for result in self._phases["postprocess"]["subphases"].values():
            if result["status"] == "notRun":
                result["status"] = "skipped"

    def finish(self) -> None:
        if self._total_ns is None:
            self._total_ns = max(0, self._clock() - self._start_ns)

    def to_dict(self) -> dict:
        self.finish()
        return {
            "meta": {"version": 1},
            "clock": "monotonic",
            "unit": "nanoseconds",
            "phases": self._phases,
            "totalNs": self._total_ns,
        }

    def print_summary(self) -> None:
        report = self.to_dict()
        iket_print("run-iket stats summary:")
        for phase, label in _TIMING_PHASE_LABELS.items():
            phase_result = report["phases"][phase]
            duration_ns = phase_result["durationNs"]
            if duration_ns is None:
                display = phase_result["status"]
            else:
                display = f"{duration_ns / 1_000_000_000:.3f} s"
                if phase_result["status"] == "failed":
                    display += " (failed)"
            iket_print(f"  {label + ':':22} {display}")
            if phase == "postprocess":
                for subphase, subphase_label in _POSTPROCESS_SUBPHASE_LABELS.items():
                    subphase_result = phase_result["subphases"][subphase]
                    subphase_duration_ns = subphase_result["durationNs"]
                    if subphase_duration_ns is None:
                        subphase_display = subphase_result["status"]
                    else:
                        subphase_display = (
                            f"{subphase_duration_ns / 1_000_000_000:.3f} s"
                        )
                        if subphase_result["status"] == "failed":
                            subphase_display += " (failed)"
                    iket_print(f"    {subphase_label + ':':28} {subphase_display}")
                    for decoder_subphase, decoder_result in subphase_result.get(
                        "subphases", {}
                    ).items():
                        decoder_label = _RAW_CAPTURE_DECODER_SUBPHASE_LABELS.get(
                            decoder_subphase, decoder_subphase
                        )
                        decoder_duration_ns = decoder_result["durationNs"]
                        decoder_display = (
                            f"{decoder_duration_ns / 1_000_000_000:.3f} s"
                            if decoder_duration_ns is not None
                            else decoder_result["status"]
                        )
                        iket_print(f"      {decoder_label + ':':26} {decoder_display}")
        iket_print(f"  {'total:':22} {report['totalNs'] / 1_000_000_000:.3f} s")

    def write_report(self) -> None:
        if self._output_dir is None:
            return
        output_path = self._output_dir / RUN_IKET_STATS_FILENAME
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, indent=2)
            f.write("\n")


def measure_optional(timings: Optional[RunIketTimings], phase: str):
    return timings.measure(phase) if timings is not None else nullcontext()


def measure_optional_postprocess_subphase(
    timings: Optional[RunIketTimings], subphase: str
):
    return (
        timings.measure_postprocess_subphase(subphase)
        if timings is not None
        else nullcontext()
    )


def skip_optional(timings: Optional[RunIketTimings], phase: str) -> None:
    if timings is not None:
        timings.skip(phase)
