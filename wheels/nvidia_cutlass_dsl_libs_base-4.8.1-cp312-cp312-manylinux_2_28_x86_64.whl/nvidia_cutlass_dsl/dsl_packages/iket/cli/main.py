import os
import sys
import argparse

from iket.cli import configure_base, configure_iket, run_iket
from iket.cli.postprocess_cmd import configure_postprocess


def get_parser():
    parser = argparse.ArgumentParser()
    configure_base(parser)

    subparsers = parser.add_subparsers(required=True)

    iket_parser = subparsers.add_parser("profile", help="run In-Kernel-Event-Tracing")
    configure_iket(iket_parser)

    postprocess_parser = subparsers.add_parser(
        "postprocess",
        help="post-process an existing IKET run directory to generate traces",
    )
    configure_postprocess(postprocess_parser)

    return parser


def main():
    parser = get_parser()
    args, unknown = parser.parse_known_args()
    validate_args = getattr(args, "_validate_args", None)
    if validate_args is not None:
        validate_args(parser, args)
    if args.func is run_iket and (not unknown or unknown == ["--"]):
        parser.error('profile requires a workload command after "--"')
    return args.func(args, unknown)


def entrypoint():
    r = main()
    sys.exit(r.returncode)


if __name__ == "__main__":
    entrypoint()
