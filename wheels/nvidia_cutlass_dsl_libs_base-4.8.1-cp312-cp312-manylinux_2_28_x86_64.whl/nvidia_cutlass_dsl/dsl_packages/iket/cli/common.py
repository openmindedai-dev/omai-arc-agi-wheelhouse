import argparse
import json
import os
from typing import Dict, Tuple, List, TextIO, Optional, Any, Callable
from pathlib import Path

from iket._core.iket import IketInstrumentPatchMode as PatchMode

DEFAULT_DEFER_TRACE_READBACK = True


def parse_arg(arg: Any, ctor: Optional[Callable] = None, default: Optional[Any] = None):
    if arg is not None:
        if ctor is not None:
            return ctor(arg)
        else:
            return arg
    else:
        return default


class InjectionConfig:
    def __init__(
        self,
        context_buffer_size: int,
        output_dir: Path,
        tool_name: str,
        tool_config: dict,
        log_level: str = "warn",
        defer_trace_readback: bool = DEFAULT_DEFER_TRACE_READBACK,
    ):
        self.context_buffer_size = context_buffer_size
        self.output_dir = output_dir
        self.tool_name = tool_name
        self.tool_config = tool_config
        self.log_level = log_level
        # Tracker and IKET both own launch trace buffers, so both passes must use
        # the selected readback policy consistently.
        self.defer_trace_readback = defer_trace_readback

    def to_dict(self):
        return {
            "bufferSize": self.context_buffer_size,
            "outputDir": str(self.output_dir),
            "logLevel": self.log_level,
            "toolName": self.tool_name,
            "toolConfig": self.tool_config,
            "deferTraceReadback": self.defer_trace_readback,
        }

    def save(self, p: Path):
        with open(p, "w") as f:
            json.dump(self.to_dict(), f, indent=2)


class IketConfig:
    def __init__(
        self,
        max_ts_cnt_per_warp: int,
        app_instrument: Path,
        patch_mode: Optional[PatchMode] = None,
        enabled_cluster: Optional[Tuple[int, int, int]] = None,
        enabled_cluster_config: Optional[Dict[str, Optional[List[int]]]] = None,
    ):
        self.max_ts_cnt_per_warp = max_ts_cnt_per_warp
        self.app_instrument = app_instrument  # path to the instrument config
        self.patch_mode = patch_mode  # None=auto-detect
        self.enabled_cluster = enabled_cluster  # None=no global single-cluster target
        self.enabled_cluster_config = enabled_cluster_config  # None=no per-kernel rules

    def to_dict(self):
        d = {
            "maxTsCntPerWarp": self.max_ts_cnt_per_warp,
            "appInstrument": str(self.app_instrument),
        }
        if self.patch_mode is not None:
            d["patchMode"] = int(self.patch_mode)
        if self.enabled_cluster is not None:
            d["enabledCluster"] = list(self.enabled_cluster)
        if self.enabled_cluster_config is not None:
            d["enabledClusterConfig"] = self.enabled_cluster_config
        return d

    def save(self, p: Path):
        with open(p, "w") as f:
            json.dump(self.to_dict(), f, indent=2)
