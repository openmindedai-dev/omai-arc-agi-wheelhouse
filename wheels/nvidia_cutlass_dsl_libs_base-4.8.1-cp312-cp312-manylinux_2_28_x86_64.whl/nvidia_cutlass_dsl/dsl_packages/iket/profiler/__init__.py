from .tracker_record import TrackerRecord
from .utils import IketModule, IketModuleConfig, module_select_resource, generate_config
from .postprocess import IketPostprocessorV2
from .utils import InstrumentConfig

from ..utils import get_binary_files_with_war

(default_injection_lib,) = get_binary_files_with_war(
    __package__, "libiket_injection.so"
)

assert (
    default_injection_lib.exists()
), f"injection lib does not exist: {default_injection_lib}"
