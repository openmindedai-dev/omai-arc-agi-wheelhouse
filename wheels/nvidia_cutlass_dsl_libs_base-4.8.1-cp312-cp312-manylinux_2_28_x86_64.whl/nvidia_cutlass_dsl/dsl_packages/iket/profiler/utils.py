from typing import List, Dict, Tuple, Set, Optional, Iterable, TYPE_CHECKING
from ..core import (
    IketContext,
    IketEventPos,
    IketInstrumentMethod,
    IketEventSummary,
    IketKernelInstrumentPoint,
)

_sass_analysis_available = False

if TYPE_CHECKING:
    pass



class InstrumentConfig:
    def __init__(self, meta: Dict, modules: List[Dict]):
        self.meta = meta  # metadata
        self.modules = modules

    def to_dict(self):
        return {"meta": self.meta, "modules": self.modules}


def jsonify_iket_range_pos(r: IketEventPos):
    val = str(r).replace("IketEventPos.", "")
    val = val[1].lower() + val[2:]
    if val == "rangeStartEnd":
        val = "startEnd"
    return val


class IketModule:
    def __init__(
        self,
        image: str,
        mhash: int,
        size: int,
        functions: Set[str],
        events: Dict[int, IketEventSummary],
        iket_cubin_context: IketContext,
    ):
        self.image = image
        self.hash = mhash
        self.size = size
        self.functions = functions
        self.events = events
        self.iket_cubin_context = iket_cubin_context
        self._sass_module: Optional["Module"] = None
        self._sass_functions: Optional[Dict[str, "Function"]] = None

    @property
    def sass_module(self) -> "Module":
        if self._sass_module is None:
            if not _sass_analysis_available:
                raise RuntimeError(
                    "This IKET installation cannot process PMTrig instrumentation. "
                    "Rebuild the workload with NativeDump instrumentation."
                )
            self._sass_module = Module.create_module_from_file(
                self.image, list(self.functions)
            )
        return self._sass_module

    @property
    def sass_functions(self) -> Dict[str, "Function"]:
        if self._sass_functions is None:
            self._sass_functions = self.sass_module.funcs
        return self._sass_functions


class IketPointConfig:
    def __init__(
        self,
        instrument_method: IketInstrumentMethod,
        offset: int,
        idx: int,
        reg: int,
        scoreboard_rd: int,
        scoreboard_reqs: List[int],
        name: Optional[str] = None,
        range_pos: Optional[str] = None,
        offset_end: int = -1,
    ):
        self.instrument_method = instrument_method
        self.offset = offset  # program counter
        self.idx = idx  # event id
        self.reg = reg
        self.scoreboard_rd = scoreboard_rd
        self.scoreboard_reqs = scoreboard_reqs
        self.name = name
        self.range_pos = range_pos
        # pc of the point's last instruction (the PMTRIG placeholder patched
        # into the buffer-pointer bump); -1 when not recorded
        self.offset_end = offset_end

    def to_dict(self):
        result = {
            "instrumentMethod": str(self.instrument_method),
            "offset": self.offset,
            "idx": self.idx,
            "reg": self.reg,
            "scoreboardRd": self.scoreboard_rd,
            "scoreboardReqs": self.scoreboard_reqs,
            "offsetHex": f"0x{self.offset:05x}",
            "countOnly": 0,
        }
        if self.name is not None:
            result["name"] = self.name
        if self.range_pos is not None:
            result["rangePos"] = self.range_pos
        if self.offset_end >= 0:
            result["offsetEnd"] = self.offset_end
        return result

    @property
    def scoreboard_req_mask(self):
        # convert list of reqs to bit mask store in insturment config
        mask = 0
        for req in self.scoreboard_reqs:
            mask |= 1 << req
        return mask


class IketFunctionConfig:
    def __init__(
        self, name: str, max_ts_cnt_per_warp: int, points: List[IketPointConfig]
    ):
        self.name = name
        self.max_ts_cnt_per_warp = max_ts_cnt_per_warp
        self.points = points

    def to_dict(self):
        return {
            "name": self.name,
            "maxTsCntPerWarp": self.max_ts_cnt_per_warp,
            "points": [p.to_dict() for p in self.points],
        }


class IketModuleConfig:
    def __init__(self, module: IketModule, functions: Dict[str, IketFunctionConfig]):
        self.module = module
        self.functions = functions  # function name -> function config

    @property
    def hash(self):
        return self.module.hash

    @property
    def size(self):
        return self.module.size

    def to_dict(self):
        return {
            "hash": f"{self.hash:016x}",
            "size": self.size,
            "functions": {
                name: [func.to_dict()]
                for name, func in self.functions.items()
                if func.points
            },
        }


class IketAppConfig:
    def __init__(self, modules: List[IketModuleConfig]):
        self.modules = modules


class SassFunctionGetter:
    def __init__(self, module: IketModule):
        self.module = module
        self._funcs: Dict[str, "Function"] = {}

    def __getitem__(self, func_name: str) -> Optional["Function"]:
        assert isinstance(func_name, str)
        if func_name not in self._funcs:
            f = self._check_and_get_func(func_name)
            if f is None:
                return None
            self._funcs[func_name] = f
        return self._funcs[func_name]

    def _check_and_get_func(self, func_name: str) -> Optional["Function"]:
        if not _sass_analysis_available:
            return None
        return self.module.sass_functions[func_name]


# Instrument methods that process_targets() can forward to the native-dump decode path
# unchanged: the profiler only needs the instrument-point PC, not a SASS analysis pass.
# Built with getattr() because the internal-only members are absent from the enum in
# external-release builds of the native binding.
_PASS_THROUGH_INSTRUMENT_METHODS = frozenset(
    m
    for m in (
        getattr(IketInstrumentMethod, name, None)
        for name in (
            "kNativeDump",
            "kExtendedNativeDump",
        )
    )
    if m is not None
)


def process_targets(
    funcs_getter: SassFunctionGetter,
    func_name: str,
    targets: List[IketKernelInstrumentPoint],
) -> Tuple[List[IketKernelInstrumentPoint], List[Tuple[int, List[int]]]]:
    """
    Process the instrument points of a function.
    return:
        native_targets: List[IketKernelInstrumentPoint]
        analysis_targets: List[Tuple[int, List[int]]]
    """
    # native dump targets
    native_targets: List[IketKernelInstrumentPoint] = []
    # event id -> sequence of pcs
    analysis_target: List[Tuple[int, List[int]]] = []

    for t in targets:
        if t.evt_attr.instrument_method == IketInstrumentMethod.kPMTrig5:
            # PMTrig5 is the only method that needs a SASS analysis pass to locate the 5 PMTRIG PCs.
            func = funcs_getter[func_name]
            if func is None:
                raise RuntimeError(
                    "This IKET installation cannot process PMTrig instrumentation. "
                    "Rebuild the workload with NativeDump instrumentation."
                )

            seq = []
            # analysis requires the exact 5 locations of targets
            for pc in range(t.offset_start, t.offset_end + 1, 16):
                if func.get_instruction_by_pc(pc).opcode.opcode == "PMTRIG":
                    seq.append(pc)

            analysis_target.append((t.evt_attr.event_id, seq))
        elif t.evt_attr.instrument_method == IketInstrumentMethod.kPMTrig6:
            # PMTrig6 (the 6-PMTRIG variant) also relies on register/scoreboard config and is not
            # handled by this profiling path. It already fell through to the generic error below;
            # this branch only exists to give a message that names the actual limitation instead
            # of "unsupported instrument method". kPMTrig6 is a public enum value, so referencing
            # it here is safe in external-release builds.
            raise RuntimeError(
                "PMTrig6 instrumentation method is not supported in this profiling path; "
                "use PMTrig5 or a NativeDump-family method instead."
            )
        elif t.evt_attr.instrument_method in _PASS_THROUGH_INSTRUMENT_METHODS:
            # NativeDump / ExtendedNativeDump and the HWPM-path variants pass through
            # directly; no SASS analysis pass needed.
            native_targets.append(t)
        else:
            # Unknown / future method: fail loudly rather than treating it as a NativeDump-style
            # target, which would silently produce wrong results. Include the kernel and the
            # instrument-point offset so the offending call site is identifiable without a rerun.
            raise RuntimeError(
                f"Unsupported instrument method {t.evt_attr.instrument_method} at instrument point "
                f"offset 0x{t.offset_start:x} in kernel '{func_name}'"
            )

    return native_targets, analysis_target


def module_select_resource(module: IketModule, max_ts_cnt_per_warp: int):
    """
    return the iket module config with selected resources
    """
    funcs_getter = SassFunctionGetter(module)
    functions_configs: Dict[str, IketFunctionConfig] = {}
    for func_name in module.functions:
        targets = module.iket_cubin_context.get_kernel_instrument_points(func_name)
        native_targets, analysis_targets = process_targets(
            funcs_getter, func_name, targets
        )

        points: List[IketPointConfig] = []
        for native_target in native_targets:
            event = module.events[native_target.evt_attr.event_id]
            points.append(
                IketPointConfig(
                    native_target.evt_attr.instrument_method,
                    native_target.offset_start,  # pc of the timer read (CS2R/S2UR)
                    native_target.evt_attr.event_id,
                    -1,  # default value and won't be used by injection lib
                    -1,  #
                    [],  # NOTE: scoreboard reqs are reserved by injection lib
                    event.name,
                    jsonify_iket_range_pos(event.range_pos),
                    offset_end=native_target.offset_end,
                )
            )
        if analysis_targets:
            func = funcs_getter[func_name]
            if func is None:
                raise RuntimeError(
                    "This IKET installation cannot process PMTrig instrumentation. "
                    "Rebuild the workload with NativeDump instrumentation."
                )
            resource_selection = ResourceSelection(
                module.sass_module.meta, func, analysis_targets
            )
            specs = resource_selection.select_res_by_scoreboard0()
            for offset, spec in specs.items():
                assert offset == spec.cs2r_pc
                event = module.events[spec.event_id]
                # TODO: update the iket injection lib to support both native/analysis point
                points.append(
                    IketPointConfig(
                        IketInstrumentMethod.kPMTrig5,
                        offset,
                        spec.event_id,
                        spec.reg,
                        spec.scoreboard_rd,
                        spec.scoreboard_reqs,
                        event.name,
                        jsonify_iket_range_pos(event.range_pos),
                    )
                )

        points.sort(key=lambda p: p.offset)
        functions_configs[func_name] = IketFunctionConfig(
            func_name, max_ts_cnt_per_warp, points
        )

    return IketModuleConfig(module, functions_configs)


def generate_config(configs: Dict[int, IketModuleConfig]) -> InstrumentConfig:
    meta = {"version": 1}

    modules: List[Dict] = []
    for module_config in configs.values():
        serialized = module_config.to_dict()
        if serialized["functions"]:
            modules.append(serialized)

    return InstrumentConfig(meta, modules)


# --- Auto buffer pool sizing ---
def compute_warp_buffer_size_bytes(
    iket_module: IketModule,
    max_ts_cnt_per_warp: int,
    kernel_name: str,
    single_cluster: bool = False,
) -> int:
    """Return the native patch recipe's timestamp-buffer bytes per warp."""
    return iket_module.iket_cubin_context._get_warp_buffer_size_bytes(
        kernel_name,
        max_ts_cnt_per_warp,
        single_cluster,
    )


def resolve_enabled_cluster_for_kernel(
    rules: Dict[str, Optional[List[int]]],
    global_target: Optional[Tuple[int, int, int]],
    kernel_name: str,
) -> Optional[Tuple[int, int, int]]:
    """Resolve the effective single-cluster target for one kernel.

    An exact mangled-name key match wins, then the longest matching substring, then the
    global default. A matched rule with value None ("all"/null in the JSON config) forces a
    full dump. Returns None for "full dump" and an (x, y, z) tuple when a target applies.
    The winner among equally long substring matches is deliberately not a stable contract.
    """
    if kernel_name in rules:
        value = rules[kernel_name]
        return tuple(value) if value is not None else None
    best_key = None
    best_len = 0
    for key in sorted(rules):
        if len(key) > best_len and key in kernel_name:
            best_key = key
            best_len = len(key)
    if best_key is not None:
        value = rules[best_key]
        return tuple(value) if value is not None else None
    return global_target


def _cluster_tile_ctas(launch) -> Optional[int]:
    """CTAs in one regular-cluster tile for a tracker launch record.

    Mirrors the normalization done by the C++ cluster-target resolver: each cluster
    dim is clamped to >= 1 AND capped at the grid extent, so a non-cluster launch (dims 0)
    normalizes to a 1x1x1 tile (a single CTA). Hostile/non-integer dimensions return
    None so the caller keeps full-grid sizing.
    """
    cluster_dim = launch.cluster_dim
    tile_ctas = 1
    for cluster_d, grid_d in (
        (cluster_dim.x, launch.grid_dim.x),
        (cluster_dim.y, launch.grid_dim.y),
        (cluster_dim.z, launch.grid_dim.z),
    ):
        if (
            not isinstance(cluster_d, int)
            or isinstance(cluster_d, bool)
            or cluster_d < 0
        ):
            return None
        tile_ctas *= min(max(cluster_d, 1), max(grid_d, 1))
    return tile_ctas


def compute_required_buffer_size(
    tracker_records_with_configs: List[
        Tuple["TrackerRecord", Dict[int, "IketModuleConfig"]]
    ],
    max_ts_cnt_per_warp: int,
    headroom_factor: float = 1.15,
    enabled_cluster: Optional[Tuple[int, int, int]] = None,
    enabled_cluster_config: Optional[Dict[str, Optional[List[int]]]] = None,
) -> int:
    """Compute required context buffer pool size from tracker data.

    Sums per-launch buffer sizes across all instrumented kernel launches
    (worst-case: all launches concurrent). Returns 0 if no instrumented
    launches need a buffer.

    Args:
        tracker_records_with_configs: list of (TrackerRecord, modules_configs) pairs
        max_ts_cnt_per_warp: max timestamps per warp (from tracker)
        headroom_factor: safety multiplier (default 1.15 = 15% headroom)
    """
    # A single-cluster selection scales a matching, compact-eligible launch to one cluster tile;
    # anything else keeps full-grid sizing.
    # Avoid circular import
    from .tracker_record import TrackerRecord

    rules = enabled_cluster_config if enabled_cluster_config is not None else {}
    has_cluster_selection = enabled_cluster is not None or len(rules) > 0

    total_bytes = 0

    for tracker_record, modules_configs in tracker_records_with_configs:
        warp_buffer_sizes: Dict[Tuple[int, str, bool], int] = {}

        # Sum over all instrumented launches
        for launch in tracker_record.iterate_kernel_launches():
            module_key = launch.cubin_hash
            if module_key not in modules_configs:
                continue

            ctas = launch.grid_dim.x * launch.grid_dim.y * launch.grid_dim.z
            threads = launch.block_dim.x * launch.block_dim.y * launch.block_dim.z
            warps_per_cta = (threads + 31) // 32
            single_cluster = False

            if has_cluster_selection:
                target = resolve_enabled_cluster_for_kernel(
                    rules, enabled_cluster, launch.kernel_name
                )
                # An ineligible kernel is captured over the whole grid with the legacy per-warp
                # layout, so it gets neither the compact rounding nor the tile CTA count. An
                # unlisted kernel counts as ineligible so we never under-allocate.
                eligible = tracker_record.compact_mode_eligible.get(
                    (launch.cubin_hash, launch.kernel_name), False
                )
                if target is not None and eligible:
                    single_cluster = True
                    tile_ctas = _cluster_tile_ctas(launch)
                    if tile_ctas is not None:
                        ctas = tile_ctas

            cache_key = (module_key, launch.kernel_name, single_cluster)
            if cache_key not in warp_buffer_sizes:
                warp_buffer_sizes[cache_key] = compute_warp_buffer_size_bytes(
                    modules_configs[module_key].module,
                    max_ts_cnt_per_warp,
                    launch.kernel_name,
                    single_cluster,
                )
            warp_buf_size = warp_buffer_sizes[cache_key]
            if warp_buf_size == 0:
                continue

            total_bytes += ctas * warps_per_cta * warp_buf_size

    if total_bytes == 0:
        return 0

    return int(total_bytes * headroom_factor)
