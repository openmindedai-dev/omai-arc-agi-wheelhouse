from typing import List, Dict, Set, Tuple
from os import PathLike, path
from pathlib import Path
import json

from ..core import IketContext, IketEventPos, IketInstrumentMethod, IketEventSummary
from .utils import IketModule

TRACKER_FORMAT_VERSION = 1


def parse_cubin_hash(value) -> int:
    if isinstance(value, str) and len(value) == 16:
        return int(value, 16)
    raise ValueError("CUBIN hash must be a 16-digit hexadecimal string")


class TrackerDim3:
    def __init__(self, x: int, y: int, z: int):
        self.x = x
        self.y = y
        self.z = z

    def to_dict(self):
        return {"x": self.x, "y": self.y, "z": self.z}

    @staticmethod
    def from_dict(d: Dict):
        return TrackerDim3(d["x"], d["y"], d["z"])

    def __repr__(self):
        return str(self.to_dict())


class ParameterDeviceFunction:
    def __init__(
        self,
        name: str,
        offset: int,
        function_id: int,
        cubin_hash: int,
    ):
        self.name = name
        self.offset = offset
        self.function_id = function_id
        self.cubin_hash = cubin_hash

    @property
    def module_key(self) -> int:
        return self.cubin_hash

    def to_dict(self):
        result = {
            "name": self.name,
            "offset": self.offset,
            "functionId": self.function_id,
            "cubinHash": f"{self.cubin_hash:016x}",
        }
        return result

    @staticmethod
    def from_dict(d: Dict):
        return ParameterDeviceFunction(
            d["name"],
            d["offset"],
            d["functionId"],
            parse_cubin_hash(d["cubinHash"]),
        )

    def __repr__(self):
        return f"ParameterDeviceFunction{{.name={self.name}, .offset={self.offset}, .cubin_hash={self.cubin_hash:016x}, .function_id={self.function_id}}}"

    def __iter__(self):
        yield self.name
        yield self.offset
        yield self.cubin_hash
        yield self.function_id


class TrackerLaunchRecord:
    def __init__(
        self,
        grid_dim: TrackerDim3,
        block_dim: TrackerDim3,
        context_id: int,
        function_id: int,
        module_id: int,
        kernel_name: str,
        parameters_devfunc: List[ParameterDeviceFunction],
        cluster_dim: TrackerDim3,
        cubin_hash: int,
    ):
        self.grid_dim = grid_dim
        self.block_dim = block_dim
        self.context_id = context_id
        self.function_id = function_id
        self.module_id = module_id
        self.kernel_name = kernel_name
        self.parameters_devfunc = parameters_devfunc
        self.cubin_hash = cubin_hash
        # Regular/minimum cluster dims of the launch (zero dims = non-cluster launch).
        self.cluster_dim = cluster_dim

    @property
    def module_key(self) -> int:
        return self.cubin_hash

    def to_dict(self):
        d = {
            "gridDim": self.grid_dim.to_dict(),
            "blockDim": self.block_dim.to_dict(),
            "contextId": self.context_id,
            "functionId": self.function_id,
            "moduleId": self.module_id,
            "kernelName": self.kernel_name,
            "parametersDeviceFunction": self.parameters_devfunc,
            "clusterDim": self.cluster_dim.to_dict(),
            "cubinHash": f"{self.cubin_hash:016x}",
        }
        return d

    @staticmethod
    def from_dict(d: Dict):
        return TrackerLaunchRecord(
            TrackerDim3.from_dict(d["gridDim"]),
            TrackerDim3.from_dict(d["blockDim"]),
            d["contextId"],
            d["functionId"],
            d["moduleId"],
            d["kernelName"],
            [
                ParameterDeviceFunction.from_dict(pdf)
                for pdf in d["parametersDeviceFunction"]
            ],
            cluster_dim=TrackerDim3.from_dict(d["clusterDim"]),
            cubin_hash=parse_cubin_hash(d["cubinHash"]),
        )


class TrackerModuleRecord:
    def __init__(
        self,
        image: str,
        size: int,
        cubin_hash: int,
    ):
        self.image = image
        self.size = size
        self.cubin_hash = cubin_hash

    @property
    def module_key(self) -> int:
        return self.cubin_hash

    def to_dict(self):
        result = {
            "image": self.image,
            "size": self.size,
            "cubinHash": f"{self.cubin_hash:016x}",
        }
        return result

    @staticmethod
    def from_dict(d: Dict):
        return TrackerModuleRecord(
            d["image"],
            d["size"],
            parse_cubin_hash(d["cubinHash"]),
        )

    def __repr__(self):
        return str(self.to_dict())


class TrackerRecord:
    def __init__(
        self,
        launches: List[TrackerLaunchRecord],
        modules: Dict[int, TrackerModuleRecord],
        graph_launches: Dict[str, List[TrackerLaunchRecord]] | None = None,
        compact_mode_eligible: Dict[Tuple[int, str], bool] | None = None,
    ):
        self.launches = launches
        self.modules_records = modules
        self.graph_launches = graph_launches or {}
        # Missing eligibility is conservatively treated as full-grid sizing.
        self.compact_mode_eligible = compact_mode_eligible or {}
        launches_with_devfunc = [
            l for l in self.iterate_kernel_launches() if l.parameters_devfunc
        ]
        dev_func_related_modules = set()
        for l in launches_with_devfunc:
            dev_func_related_modules.add(l.module_key)
            for f in l.parameters_devfunc:
                dev_func_related_modules.add(f.module_key)
        # only need to care for those functions that been instrumented if they have device function
        self.has_parameter_device_function = (
            len(dev_func_related_modules & modules.keys()) > 0
        )
        self.launched_kernels: Set[Tuple[int, str]] = set(
            (l.module_key, l.kernel_name) for l in launches
        )

    def iterate_kernel_launches(self):
        for l in self.launches:
            yield l
        for gl in self.graph_launches.values():
            for l in gl:
                yield l

    @staticmethod
    def parse_compact_mode_eligible(
        entries,
    ) -> Dict[Tuple[int, str], bool]:
        """Parse compactModeEligible, treating malformed verdicts as ineligible."""
        result: Dict[Tuple[int, str], bool] = {}
        if entries is None:
            return result
        for entry in entries:
            key = (parse_cubin_hash(entry["cubinHash"]), entry["kernelName"])
            eligible = entry.get("eligible") is True
            if key not in result or not eligible:
                result[key] = eligible
        return result

    @staticmethod
    def from_dict(d: Dict):
        meta = d["meta"]
        if meta != {"version": TRACKER_FORMAT_VERSION}:
            raise ValueError(
                "tracker format meta must be "
                f"{{'version': {TRACKER_FORMAT_VERSION}}}, got {meta!r}"
            )

        launches = []
        for l in d["launches"]:
            launch = TrackerLaunchRecord.from_dict(l)
            launches.append(launch)

        modules = {}
        for m in d["modules"]:
            module = TrackerModuleRecord.from_dict(m)
            modules[module.module_key] = module

        graph_launches: Dict[str, List[TrackerLaunchRecord]] = {}
        for key, gl in d["graphLaunches"].items():
            graph_launched_kernels = []
            for l in gl:
                launch = TrackerLaunchRecord.from_dict(l)
                graph_launched_kernels.append(launch)
            graph_launches[key] = graph_launched_kernels
        compact_mode_eligible = TrackerRecord.parse_compact_mode_eligible(
            d.get("compactModeEligible")
        )
        return TrackerRecord(launches, modules, graph_launches, compact_mode_eligible)

    @staticmethod
    def parse_json(j: PathLike):
        assert path.exists(j), f"Nonexist path: {j}"

        with open(j, "r") as f:
            d = json.load(f)
        return TrackerRecord.from_dict(d)

    def make_iket_modules(self):
        """
        make iket modules from the tracker record.

        return:
            modules: CUBIN hash -> iket module
        """
        # Step-0: get all events in each module
        cubin_context: Dict[int, IketContext] = {}
        # CUBIN hash -> event id -> iket event summary
        events: Dict[int, Dict[int, IketEventSummary]] = {}
        for module_key, module in self.modules_records.items():
            with open(module.image, "rb") as f:
                binary = f.read()
            ctx = IketContext.create(binary)
            events[module_key] = ctx.get_events()
            cubin_context[module_key] = ctx

        # Step-1: collect target functions (kernel or device)
        # CUBIN hash -> function name
        target_functions: Dict[int, Set[str]] = {}

        def add_target(module_key: int, function_name: str):
            if module_key not in target_functions:
                target_functions[module_key] = set()

            # a device is target function if it's related to a launched kernel and belongs to a module instrumented by IKET
            # TODO: add more device function tracking methods: relocation, devfunc table, ...
            target_functions[module_key].add(function_name)

        for lr in self.iterate_kernel_launches():
            add_target(lr.module_key, lr.kernel_name)

            for param_devfun in lr.parameters_devfunc:
                add_target(param_devfun.module_key, param_devfun.name)

        # Step-2: generate iket modules
        # CUBIN hash -> iket module
        modules: Dict[int, IketModule] = {}
        for module_key, module_events in events.items():
            functions = target_functions[module_key]
            # only those related functions are parsed
            mr = self.modules_records[module_key]
            size = mr.size
            modules[module_key] = IketModule(
                mr.image,
                mr.cubin_hash,
                size,
                functions,
                module_events,
                cubin_context[module_key],
            )

        return modules
