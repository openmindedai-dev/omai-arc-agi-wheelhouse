import gzip
from contextlib import nullcontext
from pathlib import Path
from typing import Callable, ContextManager, Optional

from .perfetto_viewer_template import HTML_TEMPLATE as _PERFETTO_HTML_TEMPLATE
from ..utils import iket_print


class IketPostprocessorV2:
    """Write trace outputs from a self-contained IKET raw capture."""

    def __init__(
        self,
        input_path: Path,
        measure: Optional[Callable[[str], ContextManager[None]]] = None,
        enable_stats: bool = False,
    ):
        """Construct the C++ decoder for an ``iket.data.json`` manifest."""
        self.input_path = Path(input_path)
        if self.input_path.name != "iket.data.json":
            raise ValueError(
                "IketPostprocessorV2 accepts only an iket.data.json raw-capture "
                "manifest; persisted decoded JSON is an output, not a postprocess input"
            )
        self._measure = measure or (lambda _: nullcontext())

        from iket import RawCaptureDecoder

        decoder_options = (
            {"enable_stats": True}
            if enable_stats and hasattr(RawCaptureDecoder, "get_stats")
            else {}
        )
        with self._measure_subphase("rawCaptureDecoderInit"):
            self.raw_capture_decoder = RawCaptureDecoder(
                str(self.input_path), **decoder_options
            )

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.close()
        return False

    def close(self) -> None:
        """Release decoded C++ state. Safe to call more than once."""
        self.raw_capture_decoder.close()

    def _measure_subphase(self, subphase: str):
        return self._measure(subphase)

    def get_raw_capture_decoder_stats(self) -> dict[str, dict[str, int]]:
        """Return C++ subphase timings in nanoseconds."""
        get_stats = getattr(self.raw_capture_decoder, "get_stats", None)
        return get_stats() if get_stats is not None else {}

    def dump_perfetto(self, output_path: Path) -> bytes:
        """Generate a Perfetto trace and return its serialized bytes."""
        with self._measure_subphase("perfettoTraceExport"):
            trace_bytes = self.raw_capture_decoder.export_perfetto_trace()
        with self._measure_subphase("pftraceWrite"):
            Path(output_path).write_bytes(trace_bytes)
        iket_print(f"Dumped perfetto trace to {output_path}")
        return trace_bytes

    def dump_perfetto_html(
        self, output_path: Path, trace_bytes: Optional[bytes] = None
    ) -> None:
        """Write an HTML viewer and its companion compressed Perfetto trace."""
        output_path = Path(output_path)
        if trace_bytes is None:
            with self._measure_subphase("perfettoTraceExport"):
                trace_bytes = self.raw_capture_decoder.export_perfetto_trace()

        with self._measure_subphase("optionalOutput"):
            gz_filename = output_path.stem + ".pftrace.gz"
            gz_path = output_path.parent / gz_filename
            gz_path.write_bytes(gzip.compress(trace_bytes))
            iket_print(f"Dumped compressed trace to {gz_path}")

            title = output_path.stem
            html = _PERFETTO_HTML_TEMPLATE.replace(
                "{{TRACE_URL}}", gz_filename
            ).replace("{{TITLE}}", title)
            output_path.write_text(html)
            iket_print(f"Dumped perfetto HTML viewer to {output_path}")

        output_dir = str(output_path.resolve().parent)
        html_filename = output_path.name
        iket_print(
            f"To view: cd {output_dir} && python3 -m http.server 8080"
            f" , then open http://localhost:8080/{html_filename}"
        )

    def dump_json(self, output_path: Path) -> None:
        """Write compact decoded JSON directly from the C++ decoder."""
        with self._measure_subphase("decodedJsonExport"):
            decoded_json = self.raw_capture_decoder.export_decoded_json()
        with self._measure_subphase("optionalOutput"):
            Path(output_path).write_text(decoded_json)
        iket_print(f"Dumped json trace to {output_path}")
