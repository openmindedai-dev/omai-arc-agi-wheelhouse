"""HTML template for the Perfetto trace viewer shipped with the IKET wheel."""

HTML_TEMPLATE = r"""<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>{{TITLE}}</title>
  <style>
    html, body { margin: 0; padding: 0; height: 100%; overflow: hidden; }
    #status {
      position: fixed; top: 0; left: 0; right: 0;
      background: #1a73e8; color: white;
      padding: 8px 16px; font-family: sans-serif; font-size: 14px;
      z-index: 10; text-align: center;
    }
    #file-picker {
      display: none;
      position: fixed; top: 0; left: 0; right: 0;
      background: #1a73e8; color: white;
      padding: 16px; font-family: sans-serif; font-size: 14px;
      z-index: 10; text-align: center;
    }
    #file-picker label {
      cursor: pointer; background: white; color: #1a73e8;
      padding: 8px 20px; border-radius: 4px; font-weight: bold;
    }
    #file-picker label:hover { background: #e8e8e8; }
    iframe {
      position: fixed; top: 36px; left: 0; right: 0; bottom: 0;
      width: 100%; height: calc(100% - 36px); border: none;
    }
  </style>
</head>
<body>
  <div id="status">Loading trace &mdash; waiting for Perfetto UI to be ready...</div>
  <div id="file-picker">
    Opened via file:// &mdash; select the companion trace file:
    <label>Choose {{TRACE_URL}}<input type="file" id="file-input" accept=".gz,.pftrace" hidden></label>
  </div>
  <iframe id="pf" src="about:blank" style="display:none" allow="clipboard-write"></iframe>
  <script>
    const traceUrl = "{{TRACE_URL}}";
    const perfettoUiUrl = 'https://ui.perfetto.dev';
    const perfettoUiOrigin = new URL(perfettoUiUrl).origin;
    const isLocal = window.location.protocol === 'file:';
    const iframe = document.getElementById('pf');
    const status = document.getElementById('status');
    const filePicker = document.getElementById('file-picker');
    const fileInput = document.getElementById('file-input');
    let sent = false;

    async function decompress(bytes) {
      const ds = new DecompressionStream('gzip');
      const writer = ds.writable.getWriter();
      writer.write(bytes);
      writer.close();
      const reader = ds.readable.getReader();
      const chunks = [];
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        chunks.push(value);
      }
      let totalLength = 0;
      for (const c of chunks) totalLength += c.length;
      const result = new Uint8Array(totalLength);
      let offset = 0;
      for (const c of chunks) { result.set(c, offset); offset += c.length; }
      return result;
    }

    async function resolveTrace(raw) {
      const sizeMB = (raw.length / 1048576).toFixed(1);
      const isGzip = raw[0] === 0x1f && raw[1] === 0x8b;
      if (isGzip) {
        status.textContent = `Decompressing trace (${sizeMB} MB compressed)...`;
        return await decompress(raw);
      }
      return raw;
    }

    // =====================================================================
    // HTTP mode: iframe + postMessage (for web server deployments)
    // =====================================================================
    function initHttpMode() {
      iframe.style.display = '';
      let ready = false;
      let loadGeneration = 0;
      let hasSeenIframeLoad = false;
      let pingTimer = null;
      let readinessTimer = null;
      let statusHideTimer = null;
      let traceDataPromise = null;
      let tracePrepared = false;
      let traceLoadError = null;

      function stopReadinessTimers() {
        if (pingTimer !== null) {
          clearInterval(pingTimer);
          pingTimer = null;
        }
        if (readinessTimer !== null) {
          clearTimeout(readinessTimer);
          readinessTimer = null;
        }
      }

      function loadTrace() {
        if (traceDataPromise === null) {
          traceLoadError = null;
          const pendingTrace = (async () => {
            status.textContent = 'Downloading compressed trace...';
            const resp = await fetch(traceUrl);
            if (!resp.ok) throw new Error(`Fetch failed: ${resp.status}`);
            const raw = new Uint8Array(await resp.arrayBuffer());
            const traceData = await resolveTrace(raw);
            tracePrepared = true;
            if (!ready) {
              status.textContent = 'Trace ready; waiting for Perfetto UI...';
            }
            return traceData;
          })();
          traceDataPromise = pendingTrace;
          pendingTrace.catch((e) => {
            if (traceDataPromise === pendingTrace) {
              traceDataPromise = null;
              tracePrepared = false;
              traceLoadError = e;
              status.textContent = `Unable to load trace: ${e.message}`;
            }
          });
        }
        return traceDataPromise;
      }

      async function postTrace(generation) {
        if (sent || !ready || generation !== loadGeneration) return;
        try {
          const traceData = await loadTrace();
          if (sent || !ready || generation !== loadGeneration) return;
          status.textContent = 'Sending trace to Perfetto UI...';
          iframe.contentWindow.postMessage({
            perfetto: {
              buffer: traceData.buffer,
              title: "{{TITLE}}",
              fileName: "{{TITLE}}.pftrace"
            }
          }, perfettoUiOrigin);
          sent = true;
          status.textContent = 'Trace sent to Perfetto.';
          statusHideTimer = setTimeout(() => {
            if (sent && generation === loadGeneration) status.style.display = 'none';
            statusHideTimer = null;
          }, 2000);
        } catch (e) {
          if (generation === loadGeneration) {
            status.textContent = `Unable to load trace: ${e.message}`;
          }
        }
      }

      window.addEventListener('message', (e) => {
        if (e.origin !== perfettoUiOrigin) return;
        if (e.source !== iframe.contentWindow) return;
        if (e.data !== 'PONG' || ready) return;
        ready = true;
        stopReadinessTimers();
        postTrace(loadGeneration);
      });

      function startReadinessHandshake() {
        stopReadinessTimers();
        if (statusHideTimer !== null) {
          clearTimeout(statusHideTimer);
          statusHideTimer = null;
        }
        ready = false;
        sent = false;
        const generation = ++loadGeneration;
        status.style.display = '';
        if (traceLoadError !== null) {
          status.textContent = `Unable to load trace: ${traceLoadError.message}`;
        } else if (tracePrepared) {
          status.textContent = 'Trace ready; waiting for Perfetto UI...';
        } else {
          status.textContent = 'Loading trace and waiting for Perfetto UI...';
        }

        const ping = () => {
          if (!ready && generation === loadGeneration) {
            iframe.contentWindow.postMessage('PING', perfettoUiOrigin);
          }
        };
        ping();
        pingTimer = setInterval(ping, 250);
        readinessTimer = setTimeout(() => {
          if (generation !== loadGeneration) return;
          readinessTimer = null;
          if (!ready && traceLoadError === null) {
            status.textContent = tracePrepared
              ? 'Trace ready; Perfetto UI is still loading...'
              : 'Trace and Perfetto UI are still loading...';
          }
        }, 30000);
      }

      iframe.addEventListener('load', () => {
        if (!hasSeenIframeLoad) {
          hasSeenIframeLoad = true;
          return;
        }
        startReadinessHandshake();
      });
      iframe.src = perfettoUiUrl;
      startReadinessHandshake();
      void loadTrace();
    }

    // =====================================================================
    // File mode: file picker + iframe with targetOrigin '*' (for file://)
    // =====================================================================
    function initFileMode() {
      iframe.src = perfettoUiUrl;
      iframe.style.display = '';
      status.style.display = 'none';
      filePicker.style.display = 'block';

      let traceData = null;

      fileInput.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (!file) return;
        filePicker.style.display = 'none';
        status.style.display = '';
        status.textContent = 'Reading file...';

        const raw = new Uint8Array(await file.arrayBuffer());
        traceData = await resolveTrace(raw);
        if (iframeLoaded) onReady();
        else status.textContent = 'Waiting for Perfetto UI to load...';
      });

      let iframeLoaded = false;

      function sendTrace() {
        if (sent || !traceData) return;
        iframe.contentWindow.postMessage({
          perfetto: { buffer: traceData.buffer, title: "{{TITLE}}", keepApiOpen: true }
        }, '*');
        sent = true;
        status.textContent = 'Trace sent. If it did not load, click Retry.';
        // Show retry button after a moment
        setTimeout(() => {
          if (status.style.display !== 'none') {
            status.innerHTML = 'Trace sent. <button id="retry-btn" style="cursor:pointer;background:white;color:#1a73e8;border:none;padding:4px 12px;border-radius:3px;font-weight:bold;margin-left:8px">Retry</button>';
            document.getElementById('retry-btn').onclick = () => {
              sent = false;
              sendTrace();
            };
          }
        }, 3000);
      }

      function onReady() {
        if (!traceData || sent) return;
        // Wait 5s after iframe load for Perfetto to fully initialize
        status.textContent = 'Perfetto UI loaded — sending trace in 10s...';
        setTimeout(() => sendTrace(), 10000);
      }

      iframe.addEventListener('load', () => {
        iframeLoaded = true;
        if (traceData) onReady();
      });
    }

    // =====================================================================
    if (isLocal) {
      initFileMode();
    } else {
      initHttpMode();
    }
  </script>
</body>
</html>
"""
