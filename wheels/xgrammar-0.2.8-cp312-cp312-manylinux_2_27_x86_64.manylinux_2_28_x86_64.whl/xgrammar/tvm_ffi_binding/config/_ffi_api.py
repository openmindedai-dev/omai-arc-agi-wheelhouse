"""FFI API bindings for xgrammar.tvm_ffi_binding.config."""

# tvm-ffi-stubgen(begin): import-section
# fmt: off
# isort: off
from __future__ import annotations
from tvm_ffi import init_ffi_api as _FFI_INIT_FUNC
from typing import TYPE_CHECKING
# isort: on
# fmt: on
# tvm-ffi-stubgen(end)
# tvm-ffi-stubgen(begin): global/xgrammar.tvm_ffi_binding.config
# fmt: off
_FFI_INIT_FUNC("xgrammar.tvm_ffi_binding.config", __name__)
if TYPE_CHECKING:
    def get_max_recursion_depth() -> int: ...
    def get_serialization_version() -> str: ...
    def set_max_recursion_depth(_0: int, /) -> None: ...
# fmt: on
# tvm-ffi-stubgen(end)

__all__ = [
    # tvm-ffi-stubgen(begin): __all__
    "get_max_recursion_depth",
    "get_serialization_version",
    "set_max_recursion_depth",
    # tvm-ffi-stubgen(end)
]
