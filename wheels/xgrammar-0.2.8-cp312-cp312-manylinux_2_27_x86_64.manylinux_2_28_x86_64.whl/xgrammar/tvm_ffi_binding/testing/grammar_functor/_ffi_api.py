"""FFI API bindings for xgrammar.tvm_ffi_binding.testing.grammar_functor."""

# tvm-ffi-stubgen(begin): import-section
# fmt: off
# isort: off
from __future__ import annotations
from tvm_ffi import init_ffi_api as _FFI_INIT_FUNC
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from tvm_ffi import Object
# isort: on
# fmt: on
# tvm-ffi-stubgen(end)
# tvm-ffi-stubgen(begin): global/xgrammar.tvm_ffi_binding.testing.grammar_functor
# fmt: off
_FFI_INIT_FUNC("xgrammar.tvm_ffi_binding.testing.grammar_functor", __name__)
if TYPE_CHECKING:
    def byte_string_fuser(_0: Object, /) -> Object: ...
    def dead_code_eliminator(_0: Object, /) -> Object: ...
    def fsm_builder(_0: Object, /) -> Object: ...
    def grammar_optimizer(_0: Object, /) -> Object: ...
    def lookahead_assertion_analyzer(_0: Object, /) -> Object: ...
    def repetition_normalizer(_0: Object, /) -> Object: ...
    def rule_inliner(_0: Object, /) -> Object: ...
    def structure_normalizer(_0: Object, /) -> Object: ...
# fmt: on
# tvm-ffi-stubgen(end)

__all__ = [
    # tvm-ffi-stubgen(begin): __all__
    "byte_string_fuser",
    "dead_code_eliminator",
    "fsm_builder",
    "grammar_optimizer",
    "lookahead_assertion_analyzer",
    "repetition_normalizer",
    "rule_inliner",
    "structure_normalizer",
    # tvm-ffi-stubgen(end)
]
