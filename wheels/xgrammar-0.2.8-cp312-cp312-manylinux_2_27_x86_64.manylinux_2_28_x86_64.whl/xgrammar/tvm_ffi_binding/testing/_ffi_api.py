"""FFI API bindings for xgrammar.tvm_ffi_binding.testing."""

# tvm-ffi-stubgen(begin): import-section
# fmt: off
# isort: off
from __future__ import annotations
from tvm_ffi import init_ffi_api as _FFI_INIT_FUNC
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from collections.abc import Sequence
    from tvm_ffi import Object
    from typing import Any
# isort: on
# fmt: on
# tvm-ffi-stubgen(end)
# tvm-ffi-stubgen(begin): global/xgrammar.tvm_ffi_binding.testing
# fmt: off
_FFI_INIT_FUNC("xgrammar.tvm_ffi_binding.testing", __name__)
if TYPE_CHECKING:
    def _ebnf_to_grammar_no_normalization(_0: str, _1: str, /) -> Object: ...
    def _generate_float_regex(_0: Any, _1: Any, _2: bool, _3: bool, /) -> str: ...
    def _generate_range_regex(_0: Any, _1: Any, /) -> str: ...
    def _get_allow_empty_rule_ids(_0: Object, /) -> Sequence[int]: ...
    def _get_masked_tokens_from_bitmask(_0: int, _1: Sequence[int], _2: int, _3: int, /) -> Sequence[int]: ...
    def _is_rule_fsm_accept_string(_0: Object, _1: int, _2: str, /) -> bool: ...
    def _is_single_token_bitmask(_0: int, _1: Sequence[int], _2: int, _3: int, /) -> Sequence[int]: ...
    def _json_schema_to_ebnf(_0: str, _1: bool, _2: Any, _3: Any, _4: bool, _5: Any, _6: str, _7: bool, /) -> str: ...
    def _print_grammar_fsms(_0: Object, /) -> str: ...
    def _regex_to_ebnf(_0: str, _1: Any, /) -> str: ...
    def _traverse_draft_tree(_0: Any, _1: Any, _2: Any, _3: Object, _4: Any, _5: Any, /) -> bool: ...
# fmt: on
# tvm-ffi-stubgen(end)

__all__ = [
    # tvm-ffi-stubgen(begin): __all__
    "_ebnf_to_grammar_no_normalization",
    "_generate_float_regex",
    "_generate_range_regex",
    "_get_allow_empty_rule_ids",
    "_get_masked_tokens_from_bitmask",
    "_is_rule_fsm_accept_string",
    "_is_single_token_bitmask",
    "_json_schema_to_ebnf",
    "_print_grammar_fsms",
    "_regex_to_ebnf",
    "_traverse_draft_tree",
    # tvm-ffi-stubgen(end)
]
