"""FFI API bindings for xgrammar.tvm_ffi_binding.kernels."""

# tvm-ffi-stubgen(begin): import-section
# fmt: off
# isort: off
from __future__ import annotations
from tvm_ffi import init_ffi_api as _FFI_INIT_FUNC
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from collections.abc import Sequence
    from typing import Any
# isort: on
# fmt: on
# tvm-ffi-stubgen(end)
# tvm-ffi-stubgen(begin): global/xgrammar.tvm_ffi_binding.kernels
# fmt: off
_FFI_INIT_FUNC("xgrammar.tvm_ffi_binding.kernels", __name__)
if TYPE_CHECKING:
    def apply_token_bitmask_inplace_cpu(_0: int, _1: Sequence[int], _2: Sequence[int], _3: int, _4: Sequence[int], _5: Sequence[int], _6: int, _7: Any, _8: str, /) -> None: ...
# fmt: on
# tvm-ffi-stubgen(end)

__all__ = [
    # tvm-ffi-stubgen(begin): __all__
    "apply_token_bitmask_inplace_cpu",
    # tvm-ffi-stubgen(end)
]
