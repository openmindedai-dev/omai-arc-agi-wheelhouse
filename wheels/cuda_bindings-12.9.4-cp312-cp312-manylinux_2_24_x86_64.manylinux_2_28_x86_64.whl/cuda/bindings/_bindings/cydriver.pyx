# SPDX-FileCopyrightText: Copyright (c) 2021-2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NVIDIA-SOFTWARE-LICENSE

# This code was automatically generated with version 12.9.0. Do not modify it directly.
cimport cuda.bindings._lib.dlfcn as dlfcn
from libc.stdint cimport intptr_t, uintptr_t
import os
import sys
cimport cuda.bindings._bindings.loader as loader
import threading

cdef object __symbol_lock = threading.Lock()
cdef bint __cuPythonInit = False
cdef void *__cuGetErrorString = NULL
cdef void *__cuGetErrorName = NULL
cdef void *__cuInit = NULL
cdef void *__cuDriverGetVersion = NULL
cdef void *__cuDeviceGet = NULL
cdef void *__cuDeviceGetCount = NULL
cdef void *__cuDeviceGetName = NULL
cdef void *__cuDeviceGetUuid = NULL
cdef void *__cuDeviceGetUuid_v2 = NULL
cdef void *__cuDeviceGetLuid = NULL
cdef void *__cuDeviceTotalMem_v2 = NULL
cdef void *__cuDeviceGetTexture1DLinearMaxWidth = NULL
cdef void *__cuDeviceGetAttribute = NULL
cdef void *__cuDeviceGetNvSciSyncAttributes = NULL
cdef void *__cuDeviceSetMemPool = NULL
cdef void *__cuDeviceGetMemPool = NULL
cdef void *__cuDeviceGetDefaultMemPool = NULL
cdef void *__cuDeviceGetExecAffinitySupport = NULL
cdef void *__cuFlushGPUDirectRDMAWrites = NULL
cdef void *__cuDeviceGetProperties = NULL
cdef void *__cuDeviceComputeCapability = NULL
cdef void *__cuDevicePrimaryCtxRetain = NULL
cdef void *__cuDevicePrimaryCtxRelease_v2 = NULL
cdef void *__cuDevicePrimaryCtxSetFlags_v2 = NULL
cdef void *__cuDevicePrimaryCtxGetState = NULL
cdef void *__cuDevicePrimaryCtxReset_v2 = NULL
cdef void *__cuCtxCreate_v2 = NULL
cdef void *__cuCtxCreate_v3 = NULL
cdef void *__cuCtxCreate_v4 = NULL
cdef void *__cuCtxDestroy_v2 = NULL
cdef void *__cuCtxPushCurrent_v2 = NULL
cdef void *__cuCtxPopCurrent_v2 = NULL
cdef void *__cuCtxSetCurrent = NULL
cdef void *__cuCtxGetCurrent = NULL
cdef void *__cuCtxGetDevice = NULL
cdef void *__cuCtxGetFlags = NULL
cdef void *__cuCtxSetFlags = NULL
cdef void *__cuCtxGetId = NULL
cdef void *__cuCtxSynchronize = NULL
cdef void *__cuCtxSetLimit = NULL
cdef void *__cuCtxGetLimit = NULL
cdef void *__cuCtxGetCacheConfig = NULL
cdef void *__cuCtxSetCacheConfig = NULL
cdef void *__cuCtxGetApiVersion = NULL
cdef void *__cuCtxGetStreamPriorityRange = NULL
cdef void *__cuCtxResetPersistingL2Cache = NULL
cdef void *__cuCtxGetExecAffinity = NULL
cdef void *__cuCtxRecordEvent = NULL
cdef void *__cuCtxWaitEvent = NULL
cdef void *__cuCtxAttach = NULL
cdef void *__cuCtxDetach = NULL
cdef void *__cuCtxGetSharedMemConfig = NULL
cdef void *__cuCtxSetSharedMemConfig = NULL
cdef void *__cuModuleLoad = NULL
cdef void *__cuModuleLoadData = NULL
cdef void *__cuModuleLoadDataEx = NULL
cdef void *__cuModuleLoadFatBinary = NULL
cdef void *__cuModuleUnload = NULL
cdef void *__cuModuleGetLoadingMode = NULL
cdef void *__cuModuleGetFunction = NULL
cdef void *__cuModuleGetFunctionCount = NULL
cdef void *__cuModuleEnumerateFunctions = NULL
cdef void *__cuModuleGetGlobal_v2 = NULL
cdef void *__cuLinkCreate_v2 = NULL
cdef void *__cuLinkAddData_v2 = NULL
cdef void *__cuLinkAddFile_v2 = NULL
cdef void *__cuLinkComplete = NULL
cdef void *__cuLinkDestroy = NULL
cdef void *__cuModuleGetTexRef = NULL
cdef void *__cuModuleGetSurfRef = NULL
cdef void *__cuLibraryLoadData = NULL
cdef void *__cuLibraryLoadFromFile = NULL
cdef void *__cuLibraryUnload = NULL
cdef void *__cuLibraryGetKernel = NULL
cdef void *__cuLibraryGetKernelCount = NULL
cdef void *__cuLibraryEnumerateKernels = NULL
cdef void *__cuLibraryGetModule = NULL
cdef void *__cuKernelGetFunction = NULL
cdef void *__cuKernelGetLibrary = NULL
cdef void *__cuLibraryGetGlobal = NULL
cdef void *__cuLibraryGetManaged = NULL
cdef void *__cuLibraryGetUnifiedFunction = NULL
cdef void *__cuKernelGetAttribute = NULL
cdef void *__cuKernelSetAttribute = NULL
cdef void *__cuKernelSetCacheConfig = NULL
cdef void *__cuKernelGetName = NULL
cdef void *__cuKernelGetParamInfo = NULL
cdef void *__cuMemGetInfo_v2 = NULL
cdef void *__cuMemAlloc_v2 = NULL
cdef void *__cuMemAllocPitch_v2 = NULL
cdef void *__cuMemFree_v2 = NULL
cdef void *__cuMemGetAddressRange_v2 = NULL
cdef void *__cuMemAllocHost_v2 = NULL
cdef void *__cuMemFreeHost = NULL
cdef void *__cuMemHostAlloc = NULL
cdef void *__cuMemHostGetDevicePointer_v2 = NULL
cdef void *__cuMemHostGetFlags = NULL
cdef void *__cuMemAllocManaged = NULL
cdef void *__cuDeviceRegisterAsyncNotification = NULL
cdef void *__cuDeviceUnregisterAsyncNotification = NULL
cdef void *__cuDeviceGetByPCIBusId = NULL
cdef void *__cuDeviceGetPCIBusId = NULL
cdef void *__cuIpcGetEventHandle = NULL
cdef void *__cuIpcOpenEventHandle = NULL
cdef void *__cuIpcGetMemHandle = NULL
cdef void *__cuIpcOpenMemHandle_v2 = NULL
cdef void *__cuIpcCloseMemHandle = NULL
cdef void *__cuMemHostRegister_v2 = NULL
cdef void *__cuMemHostUnregister = NULL
cdef void *__cuMemcpy = NULL
cdef void *__cuMemcpyPeer = NULL
cdef void *__cuMemcpyHtoD_v2 = NULL
cdef void *__cuMemcpyDtoH_v2 = NULL
cdef void *__cuMemcpyDtoD_v2 = NULL
cdef void *__cuMemcpyDtoA_v2 = NULL
cdef void *__cuMemcpyAtoD_v2 = NULL
cdef void *__cuMemcpyHtoA_v2 = NULL
cdef void *__cuMemcpyAtoH_v2 = NULL
cdef void *__cuMemcpyAtoA_v2 = NULL
cdef void *__cuMemcpy2D_v2 = NULL
cdef void *__cuMemcpy2DUnaligned_v2 = NULL
cdef void *__cuMemcpy3D_v2 = NULL
cdef void *__cuMemcpy3DPeer = NULL
cdef void *__cuMemcpyAsync = NULL
cdef void *__cuMemcpyPeerAsync = NULL
cdef void *__cuMemcpyHtoDAsync_v2 = NULL
cdef void *__cuMemcpyDtoHAsync_v2 = NULL
cdef void *__cuMemcpyDtoDAsync_v2 = NULL
cdef void *__cuMemcpyHtoAAsync_v2 = NULL
cdef void *__cuMemcpyAtoHAsync_v2 = NULL
cdef void *__cuMemcpy2DAsync_v2 = NULL
cdef void *__cuMemcpy3DAsync_v2 = NULL
cdef void *__cuMemcpy3DPeerAsync = NULL
cdef void *__cuMemcpyBatchAsync = NULL
cdef void *__cuMemcpy3DBatchAsync = NULL
cdef void *__cuMemsetD8_v2 = NULL
cdef void *__cuMemsetD16_v2 = NULL
cdef void *__cuMemsetD32_v2 = NULL
cdef void *__cuMemsetD2D8_v2 = NULL
cdef void *__cuMemsetD2D16_v2 = NULL
cdef void *__cuMemsetD2D32_v2 = NULL
cdef void *__cuMemsetD8Async = NULL
cdef void *__cuMemsetD16Async = NULL
cdef void *__cuMemsetD32Async = NULL
cdef void *__cuMemsetD2D8Async = NULL
cdef void *__cuMemsetD2D16Async = NULL
cdef void *__cuMemsetD2D32Async = NULL
cdef void *__cuArrayCreate_v2 = NULL
cdef void *__cuArrayGetDescriptor_v2 = NULL
cdef void *__cuArrayGetSparseProperties = NULL
cdef void *__cuMipmappedArrayGetSparseProperties = NULL
cdef void *__cuArrayGetMemoryRequirements = NULL
cdef void *__cuMipmappedArrayGetMemoryRequirements = NULL
cdef void *__cuArrayGetPlane = NULL
cdef void *__cuArrayDestroy = NULL
cdef void *__cuArray3DCreate_v2 = NULL
cdef void *__cuArray3DGetDescriptor_v2 = NULL
cdef void *__cuMipmappedArrayCreate = NULL
cdef void *__cuMipmappedArrayGetLevel = NULL
cdef void *__cuMipmappedArrayDestroy = NULL
cdef void *__cuMemGetHandleForAddressRange = NULL
cdef void *__cuMemBatchDecompressAsync = NULL
cdef void *__cuMemAddressReserve = NULL
cdef void *__cuMemAddressFree = NULL
cdef void *__cuMemCreate = NULL
cdef void *__cuMemRelease = NULL
cdef void *__cuMemMap = NULL
cdef void *__cuMemMapArrayAsync = NULL
cdef void *__cuMemUnmap = NULL
cdef void *__cuMemSetAccess = NULL
cdef void *__cuMemGetAccess = NULL
cdef void *__cuMemExportToShareableHandle = NULL
cdef void *__cuMemImportFromShareableHandle = NULL
cdef void *__cuMemGetAllocationGranularity = NULL
cdef void *__cuMemGetAllocationPropertiesFromHandle = NULL
cdef void *__cuMemRetainAllocationHandle = NULL
cdef void *__cuMemFreeAsync = NULL
cdef void *__cuMemAllocAsync = NULL
cdef void *__cuMemPoolTrimTo = NULL
cdef void *__cuMemPoolSetAttribute = NULL
cdef void *__cuMemPoolGetAttribute = NULL
cdef void *__cuMemPoolSetAccess = NULL
cdef void *__cuMemPoolGetAccess = NULL
cdef void *__cuMemPoolCreate = NULL
cdef void *__cuMemPoolDestroy = NULL
cdef void *__cuMemAllocFromPoolAsync = NULL
cdef void *__cuMemPoolExportToShareableHandle = NULL
cdef void *__cuMemPoolImportFromShareableHandle = NULL
cdef void *__cuMemPoolExportPointer = NULL
cdef void *__cuMemPoolImportPointer = NULL
cdef void *__cuMulticastCreate = NULL
cdef void *__cuMulticastAddDevice = NULL
cdef void *__cuMulticastBindMem = NULL
cdef void *__cuMulticastBindAddr = NULL
cdef void *__cuMulticastUnbind = NULL
cdef void *__cuMulticastGetGranularity = NULL
cdef void *__cuPointerGetAttribute = NULL
cdef void *__cuMemPrefetchAsync = NULL
cdef void *__cuMemPrefetchAsync_v2 = NULL
cdef void *__cuMemAdvise = NULL
cdef void *__cuMemAdvise_v2 = NULL
cdef void *__cuMemRangeGetAttribute = NULL
cdef void *__cuMemRangeGetAttributes = NULL
cdef void *__cuPointerSetAttribute = NULL
cdef void *__cuPointerGetAttributes = NULL
cdef void *__cuStreamCreate = NULL
cdef void *__cuStreamCreateWithPriority = NULL
cdef void *__cuStreamGetPriority = NULL
cdef void *__cuStreamGetDevice = NULL
cdef void *__cuStreamGetFlags = NULL
cdef void *__cuStreamGetId = NULL
cdef void *__cuStreamGetCtx = NULL
cdef void *__cuStreamGetCtx_v2 = NULL
cdef void *__cuStreamWaitEvent = NULL
cdef void *__cuStreamAddCallback = NULL
cdef void *__cuStreamBeginCapture_v2 = NULL
cdef void *__cuStreamBeginCaptureToGraph = NULL
cdef void *__cuThreadExchangeStreamCaptureMode = NULL
cdef void *__cuStreamEndCapture = NULL
cdef void *__cuStreamIsCapturing = NULL
cdef void *__cuStreamGetCaptureInfo_v2 = NULL
cdef void *__cuStreamGetCaptureInfo_v3 = NULL
cdef void *__cuStreamUpdateCaptureDependencies = NULL
cdef void *__cuStreamUpdateCaptureDependencies_v2 = NULL
cdef void *__cuStreamAttachMemAsync = NULL
cdef void *__cuStreamQuery = NULL
cdef void *__cuStreamSynchronize = NULL
cdef void *__cuStreamDestroy_v2 = NULL
cdef void *__cuStreamCopyAttributes = NULL
cdef void *__cuStreamGetAttribute = NULL
cdef void *__cuStreamSetAttribute = NULL
cdef void *__cuEventCreate = NULL
cdef void *__cuEventRecord = NULL
cdef void *__cuEventRecordWithFlags = NULL
cdef void *__cuEventQuery = NULL
cdef void *__cuEventSynchronize = NULL
cdef void *__cuEventDestroy_v2 = NULL
cdef void *__cuEventElapsedTime = NULL
cdef void *__cuEventElapsedTime_v2 = NULL
cdef void *__cuImportExternalMemory = NULL
cdef void *__cuExternalMemoryGetMappedBuffer = NULL
cdef void *__cuExternalMemoryGetMappedMipmappedArray = NULL
cdef void *__cuDestroyExternalMemory = NULL
cdef void *__cuImportExternalSemaphore = NULL
cdef void *__cuSignalExternalSemaphoresAsync = NULL
cdef void *__cuWaitExternalSemaphoresAsync = NULL
cdef void *__cuDestroyExternalSemaphore = NULL
cdef void *__cuStreamWaitValue32_v2 = NULL
cdef void *__cuStreamWaitValue64_v2 = NULL
cdef void *__cuStreamWriteValue32_v2 = NULL
cdef void *__cuStreamWriteValue64_v2 = NULL
cdef void *__cuStreamBatchMemOp_v2 = NULL
cdef void *__cuFuncGetAttribute = NULL
cdef void *__cuFuncSetAttribute = NULL
cdef void *__cuFuncSetCacheConfig = NULL
cdef void *__cuFuncGetModule = NULL
cdef void *__cuFuncGetName = NULL
cdef void *__cuFuncGetParamInfo = NULL
cdef void *__cuFuncIsLoaded = NULL
cdef void *__cuFuncLoad = NULL
cdef void *__cuLaunchKernel = NULL
cdef void *__cuLaunchKernelEx = NULL
cdef void *__cuLaunchCooperativeKernel = NULL
cdef void *__cuLaunchCooperativeKernelMultiDevice = NULL
cdef void *__cuLaunchHostFunc = NULL
cdef void *__cuFuncSetBlockShape = NULL
cdef void *__cuFuncSetSharedSize = NULL
cdef void *__cuParamSetSize = NULL
cdef void *__cuParamSeti = NULL
cdef void *__cuParamSetf = NULL
cdef void *__cuParamSetv = NULL
cdef void *__cuLaunch = NULL
cdef void *__cuLaunchGrid = NULL
cdef void *__cuLaunchGridAsync = NULL
cdef void *__cuParamSetTexRef = NULL
cdef void *__cuFuncSetSharedMemConfig = NULL
cdef void *__cuGraphCreate = NULL
cdef void *__cuGraphAddKernelNode_v2 = NULL
cdef void *__cuGraphKernelNodeGetParams_v2 = NULL
cdef void *__cuGraphKernelNodeSetParams_v2 = NULL
cdef void *__cuGraphAddMemcpyNode = NULL
cdef void *__cuGraphMemcpyNodeGetParams = NULL
cdef void *__cuGraphMemcpyNodeSetParams = NULL
cdef void *__cuGraphAddMemsetNode = NULL
cdef void *__cuGraphMemsetNodeGetParams = NULL
cdef void *__cuGraphMemsetNodeSetParams = NULL
cdef void *__cuGraphAddHostNode = NULL
cdef void *__cuGraphHostNodeGetParams = NULL
cdef void *__cuGraphHostNodeSetParams = NULL
cdef void *__cuGraphAddChildGraphNode = NULL
cdef void *__cuGraphChildGraphNodeGetGraph = NULL
cdef void *__cuGraphAddEmptyNode = NULL
cdef void *__cuGraphAddEventRecordNode = NULL
cdef void *__cuGraphEventRecordNodeGetEvent = NULL
cdef void *__cuGraphEventRecordNodeSetEvent = NULL
cdef void *__cuGraphAddEventWaitNode = NULL
cdef void *__cuGraphEventWaitNodeGetEvent = NULL
cdef void *__cuGraphEventWaitNodeSetEvent = NULL
cdef void *__cuGraphAddExternalSemaphoresSignalNode = NULL
cdef void *__cuGraphExternalSemaphoresSignalNodeGetParams = NULL
cdef void *__cuGraphExternalSemaphoresSignalNodeSetParams = NULL
cdef void *__cuGraphAddExternalSemaphoresWaitNode = NULL
cdef void *__cuGraphExternalSemaphoresWaitNodeGetParams = NULL
cdef void *__cuGraphExternalSemaphoresWaitNodeSetParams = NULL
cdef void *__cuGraphAddBatchMemOpNode = NULL
cdef void *__cuGraphBatchMemOpNodeGetParams = NULL
cdef void *__cuGraphBatchMemOpNodeSetParams = NULL
cdef void *__cuGraphExecBatchMemOpNodeSetParams = NULL
cdef void *__cuGraphAddMemAllocNode = NULL
cdef void *__cuGraphMemAllocNodeGetParams = NULL
cdef void *__cuGraphAddMemFreeNode = NULL
cdef void *__cuGraphMemFreeNodeGetParams = NULL
cdef void *__cuDeviceGraphMemTrim = NULL
cdef void *__cuDeviceGetGraphMemAttribute = NULL
cdef void *__cuDeviceSetGraphMemAttribute = NULL
cdef void *__cuGraphClone = NULL
cdef void *__cuGraphNodeFindInClone = NULL
cdef void *__cuGraphNodeGetType = NULL
cdef void *__cuGraphGetNodes = NULL
cdef void *__cuGraphGetRootNodes = NULL
cdef void *__cuGraphGetEdges = NULL
cdef void *__cuGraphGetEdges_v2 = NULL
cdef void *__cuGraphNodeGetDependencies = NULL
cdef void *__cuGraphNodeGetDependencies_v2 = NULL
cdef void *__cuGraphNodeGetDependentNodes = NULL
cdef void *__cuGraphNodeGetDependentNodes_v2 = NULL
cdef void *__cuGraphAddDependencies = NULL
cdef void *__cuGraphAddDependencies_v2 = NULL
cdef void *__cuGraphRemoveDependencies = NULL
cdef void *__cuGraphRemoveDependencies_v2 = NULL
cdef void *__cuGraphDestroyNode = NULL
cdef void *__cuGraphInstantiateWithFlags = NULL
cdef void *__cuGraphInstantiateWithParams = NULL
cdef void *__cuGraphExecGetFlags = NULL
cdef void *__cuGraphExecKernelNodeSetParams_v2 = NULL
cdef void *__cuGraphExecMemcpyNodeSetParams = NULL
cdef void *__cuGraphExecMemsetNodeSetParams = NULL
cdef void *__cuGraphExecHostNodeSetParams = NULL
cdef void *__cuGraphExecChildGraphNodeSetParams = NULL
cdef void *__cuGraphExecEventRecordNodeSetEvent = NULL
cdef void *__cuGraphExecEventWaitNodeSetEvent = NULL
cdef void *__cuGraphExecExternalSemaphoresSignalNodeSetParams = NULL
cdef void *__cuGraphExecExternalSemaphoresWaitNodeSetParams = NULL
cdef void *__cuGraphNodeSetEnabled = NULL
cdef void *__cuGraphNodeGetEnabled = NULL
cdef void *__cuGraphUpload = NULL
cdef void *__cuGraphLaunch = NULL
cdef void *__cuGraphExecDestroy = NULL
cdef void *__cuGraphDestroy = NULL
cdef void *__cuGraphExecUpdate_v2 = NULL
cdef void *__cuGraphKernelNodeCopyAttributes = NULL
cdef void *__cuGraphKernelNodeGetAttribute = NULL
cdef void *__cuGraphKernelNodeSetAttribute = NULL
cdef void *__cuGraphDebugDotPrint = NULL
cdef void *__cuUserObjectCreate = NULL
cdef void *__cuUserObjectRetain = NULL
cdef void *__cuUserObjectRelease = NULL
cdef void *__cuGraphRetainUserObject = NULL
cdef void *__cuGraphReleaseUserObject = NULL
cdef void *__cuGraphAddNode = NULL
cdef void *__cuGraphAddNode_v2 = NULL
cdef void *__cuGraphNodeSetParams = NULL
cdef void *__cuGraphExecNodeSetParams = NULL
cdef void *__cuGraphConditionalHandleCreate = NULL
cdef void *__cuOccupancyMaxActiveBlocksPerMultiprocessor = NULL
cdef void *__cuOccupancyMaxActiveBlocksPerMultiprocessorWithFlags = NULL
cdef void *__cuOccupancyMaxPotentialBlockSize = NULL
cdef void *__cuOccupancyMaxPotentialBlockSizeWithFlags = NULL
cdef void *__cuOccupancyAvailableDynamicSMemPerBlock = NULL
cdef void *__cuOccupancyMaxPotentialClusterSize = NULL
cdef void *__cuOccupancyMaxActiveClusters = NULL
cdef void *__cuTexRefSetArray = NULL
cdef void *__cuTexRefSetMipmappedArray = NULL
cdef void *__cuTexRefSetAddress_v2 = NULL
cdef void *__cuTexRefSetAddress2D_v3 = NULL
cdef void *__cuTexRefSetFormat = NULL
cdef void *__cuTexRefSetAddressMode = NULL
cdef void *__cuTexRefSetFilterMode = NULL
cdef void *__cuTexRefSetMipmapFilterMode = NULL
cdef void *__cuTexRefSetMipmapLevelBias = NULL
cdef void *__cuTexRefSetMipmapLevelClamp = NULL
cdef void *__cuTexRefSetMaxAnisotropy = NULL
cdef void *__cuTexRefSetBorderColor = NULL
cdef void *__cuTexRefSetFlags = NULL
cdef void *__cuTexRefGetAddress_v2 = NULL
cdef void *__cuTexRefGetArray = NULL
cdef void *__cuTexRefGetMipmappedArray = NULL
cdef void *__cuTexRefGetAddressMode = NULL
cdef void *__cuTexRefGetFilterMode = NULL
cdef void *__cuTexRefGetFormat = NULL
cdef void *__cuTexRefGetMipmapFilterMode = NULL
cdef void *__cuTexRefGetMipmapLevelBias = NULL
cdef void *__cuTexRefGetMipmapLevelClamp = NULL
cdef void *__cuTexRefGetMaxAnisotropy = NULL
cdef void *__cuTexRefGetBorderColor = NULL
cdef void *__cuTexRefGetFlags = NULL
cdef void *__cuTexRefCreate = NULL
cdef void *__cuTexRefDestroy = NULL
cdef void *__cuSurfRefSetArray = NULL
cdef void *__cuSurfRefGetArray = NULL
cdef void *__cuTexObjectCreate = NULL
cdef void *__cuTexObjectDestroy = NULL
cdef void *__cuTexObjectGetResourceDesc = NULL
cdef void *__cuTexObjectGetTextureDesc = NULL
cdef void *__cuTexObjectGetResourceViewDesc = NULL
cdef void *__cuSurfObjectCreate = NULL
cdef void *__cuSurfObjectDestroy = NULL
cdef void *__cuSurfObjectGetResourceDesc = NULL
cdef void *__cuTensorMapEncodeTiled = NULL
cdef void *__cuTensorMapEncodeIm2col = NULL
cdef void *__cuTensorMapEncodeIm2colWide = NULL
cdef void *__cuTensorMapReplaceAddress = NULL
cdef void *__cuDeviceCanAccessPeer = NULL
cdef void *__cuCtxEnablePeerAccess = NULL
cdef void *__cuCtxDisablePeerAccess = NULL
cdef void *__cuDeviceGetP2PAttribute = NULL
cdef void *__cuGraphicsUnregisterResource = NULL
cdef void *__cuGraphicsSubResourceGetMappedArray = NULL
cdef void *__cuGraphicsResourceGetMappedMipmappedArray = NULL
cdef void *__cuGraphicsResourceGetMappedPointer_v2 = NULL
cdef void *__cuGraphicsResourceSetMapFlags_v2 = NULL
cdef void *__cuGraphicsMapResources = NULL
cdef void *__cuGraphicsUnmapResources = NULL
cdef void *__cuGetProcAddress_v2 = NULL
cdef void *__cuCoredumpGetAttribute = NULL
cdef void *__cuCoredumpGetAttributeGlobal = NULL
cdef void *__cuCoredumpSetAttribute = NULL
cdef void *__cuCoredumpSetAttributeGlobal = NULL
cdef void *__cuGetExportTable = NULL
cdef void *__cuGreenCtxCreate = NULL
cdef void *__cuGreenCtxDestroy = NULL
cdef void *__cuCtxFromGreenCtx = NULL
cdef void *__cuDeviceGetDevResource = NULL
cdef void *__cuCtxGetDevResource = NULL
cdef void *__cuGreenCtxGetDevResource = NULL
cdef void *__cuDevSmResourceSplitByCount = NULL
cdef void *__cuDevResourceGenerateDesc = NULL
cdef void *__cuGreenCtxRecordEvent = NULL
cdef void *__cuGreenCtxWaitEvent = NULL
cdef void *__cuStreamGetGreenCtx = NULL
cdef void *__cuGreenCtxStreamCreate = NULL
cdef void *__cuLogsRegisterCallback = NULL
cdef void *__cuLogsUnregisterCallback = NULL
cdef void *__cuLogsCurrent = NULL
cdef void *__cuLogsDumpToFile = NULL
cdef void *__cuLogsDumpToMemory = NULL
cdef void *__cuCheckpointProcessGetRestoreThreadId = NULL
cdef void *__cuCheckpointProcessGetState = NULL
cdef void *__cuCheckpointProcessLock = NULL
cdef void *__cuCheckpointProcessCheckpoint = NULL
cdef void *__cuCheckpointProcessRestore = NULL
cdef void *__cuCheckpointProcessUnlock = NULL
cdef void *__cuProfilerStart = NULL
cdef void *__cuProfilerStop = NULL
cdef void *__cuGraphicsEGLRegisterImage = NULL
cdef void *__cuEGLStreamConsumerConnect = NULL
cdef void *__cuEGLStreamConsumerConnectWithFlags = NULL
cdef void *__cuEGLStreamConsumerDisconnect = NULL
cdef void *__cuEGLStreamConsumerAcquireFrame = NULL
cdef void *__cuEGLStreamConsumerReleaseFrame = NULL
cdef void *__cuEGLStreamProducerConnect = NULL
cdef void *__cuEGLStreamProducerDisconnect = NULL
cdef void *__cuEGLStreamProducerPresentFrame = NULL
cdef void *__cuEGLStreamProducerReturnFrame = NULL
cdef void *__cuGraphicsResourceGetMappedEglFrame = NULL
cdef void *__cuEventCreateFromEGLSync = NULL
cdef void *__cuGraphicsGLRegisterBuffer = NULL
cdef void *__cuGraphicsGLRegisterImage = NULL
cdef void *__cuGLGetDevices_v2 = NULL
cdef void *__cuVDPAUGetDevice = NULL
cdef void *__cuVDPAUCtxCreate_v2 = NULL
cdef void *__cuGraphicsVDPAURegisterVideoSurface = NULL
cdef void *__cuGraphicsVDPAURegisterOutputSurface = NULL

# To make cuPythonInit reentrant
ctypedef CUresult (*__cuGetProcAddress_v2_T)(const char*, void**, int, cuuint64_t, CUdriverProcAddressQueryResult*) except?CUDA_ERROR_NOT_FOUND nogil
cdef __cuGetProcAddress_v2_T _F_cuGetProcAddress_v2 = NULL

cdef int _cuPythonInit() except -1 nogil:
    global __cuPythonInit

    cdef bint usePTDS
    cdef char libPath[260]

    with gil, __symbol_lock:
        usePTDS = os.getenv('CUDA_PYTHON_CUDA_PER_THREAD_DEFAULT_STREAM', default=0)

        # Load library
        libPath[0] = 0
        status = loader.getCUDALibraryPath(libPath, sys.maxsize > 2**32)
        if status == 0 and len(libPath) != 0:
            path = libPath.decode('utf-8')
        else:
            path = 'libcuda.so.1'
        handle = dlfcn.dlopen(bytes(path, encoding='utf-8'), dlfcn.RTLD_NOW)
        if handle == NULL:
            raise RuntimeError('Failed to dlopen ' + path)

        # Get latest __cuGetProcAddress_v2
        global __cuGetProcAddress_v2
        __cuGetProcAddress_v2 = dlfcn.dlsym(handle, 'cuGetProcAddress_v2')

        # Load using cuGetProcAddress if available
        if __cuGetProcAddress_v2 != NULL:
            _F_cuGetProcAddress_v2 = <__cuGetProcAddress_v2_T>__cuGetProcAddress_v2
            if usePTDS:
                # Get all PTDS version of functions
                pass
                global __cuMemcpy
                _F_cuGetProcAddress_v2('cuMemcpy', &__cuMemcpy, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemcpyPeer
                _F_cuGetProcAddress_v2('cuMemcpyPeer', &__cuMemcpyPeer, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemcpyHtoD_v2
                _F_cuGetProcAddress_v2('cuMemcpyHtoD', &__cuMemcpyHtoD_v2, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemcpyDtoH_v2
                _F_cuGetProcAddress_v2('cuMemcpyDtoH', &__cuMemcpyDtoH_v2, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemcpyDtoD_v2
                _F_cuGetProcAddress_v2('cuMemcpyDtoD', &__cuMemcpyDtoD_v2, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemcpyDtoA_v2
                _F_cuGetProcAddress_v2('cuMemcpyDtoA', &__cuMemcpyDtoA_v2, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemcpyAtoD_v2
                _F_cuGetProcAddress_v2('cuMemcpyAtoD', &__cuMemcpyAtoD_v2, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemcpyHtoA_v2
                _F_cuGetProcAddress_v2('cuMemcpyHtoA', &__cuMemcpyHtoA_v2, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemcpyAtoH_v2
                _F_cuGetProcAddress_v2('cuMemcpyAtoH', &__cuMemcpyAtoH_v2, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemcpyAtoA_v2
                _F_cuGetProcAddress_v2('cuMemcpyAtoA', &__cuMemcpyAtoA_v2, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemcpy2D_v2
                _F_cuGetProcAddress_v2('cuMemcpy2D', &__cuMemcpy2D_v2, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemcpy2DUnaligned_v2
                _F_cuGetProcAddress_v2('cuMemcpy2DUnaligned', &__cuMemcpy2DUnaligned_v2, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemcpy3D_v2
                _F_cuGetProcAddress_v2('cuMemcpy3D', &__cuMemcpy3D_v2, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemcpy3DPeer
                _F_cuGetProcAddress_v2('cuMemcpy3DPeer', &__cuMemcpy3DPeer, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemcpyAsync
                _F_cuGetProcAddress_v2('cuMemcpyAsync', &__cuMemcpyAsync, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemcpyPeerAsync
                _F_cuGetProcAddress_v2('cuMemcpyPeerAsync', &__cuMemcpyPeerAsync, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemcpyHtoDAsync_v2
                _F_cuGetProcAddress_v2('cuMemcpyHtoDAsync', &__cuMemcpyHtoDAsync_v2, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemcpyDtoHAsync_v2
                _F_cuGetProcAddress_v2('cuMemcpyDtoHAsync', &__cuMemcpyDtoHAsync_v2, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemcpyDtoDAsync_v2
                _F_cuGetProcAddress_v2('cuMemcpyDtoDAsync', &__cuMemcpyDtoDAsync_v2, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemcpyHtoAAsync_v2
                _F_cuGetProcAddress_v2('cuMemcpyHtoAAsync', &__cuMemcpyHtoAAsync_v2, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemcpyAtoHAsync_v2
                _F_cuGetProcAddress_v2('cuMemcpyAtoHAsync', &__cuMemcpyAtoHAsync_v2, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemcpy2DAsync_v2
                _F_cuGetProcAddress_v2('cuMemcpy2DAsync', &__cuMemcpy2DAsync_v2, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemcpy3DAsync_v2
                _F_cuGetProcAddress_v2('cuMemcpy3DAsync', &__cuMemcpy3DAsync_v2, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemcpy3DPeerAsync
                _F_cuGetProcAddress_v2('cuMemcpy3DPeerAsync', &__cuMemcpy3DPeerAsync, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemcpyBatchAsync
                _F_cuGetProcAddress_v2('cuMemcpyBatchAsync', &__cuMemcpyBatchAsync, 12080, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemcpy3DBatchAsync
                _F_cuGetProcAddress_v2('cuMemcpy3DBatchAsync', &__cuMemcpy3DBatchAsync, 12080, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemsetD8_v2
                _F_cuGetProcAddress_v2('cuMemsetD8', &__cuMemsetD8_v2, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemsetD16_v2
                _F_cuGetProcAddress_v2('cuMemsetD16', &__cuMemsetD16_v2, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemsetD32_v2
                _F_cuGetProcAddress_v2('cuMemsetD32', &__cuMemsetD32_v2, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemsetD2D8_v2
                _F_cuGetProcAddress_v2('cuMemsetD2D8', &__cuMemsetD2D8_v2, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemsetD2D16_v2
                _F_cuGetProcAddress_v2('cuMemsetD2D16', &__cuMemsetD2D16_v2, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemsetD2D32_v2
                _F_cuGetProcAddress_v2('cuMemsetD2D32', &__cuMemsetD2D32_v2, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemsetD8Async
                _F_cuGetProcAddress_v2('cuMemsetD8Async', &__cuMemsetD8Async, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemsetD16Async
                _F_cuGetProcAddress_v2('cuMemsetD16Async', &__cuMemsetD16Async, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemsetD32Async
                _F_cuGetProcAddress_v2('cuMemsetD32Async', &__cuMemsetD32Async, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemsetD2D8Async
                _F_cuGetProcAddress_v2('cuMemsetD2D8Async', &__cuMemsetD2D8Async, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemsetD2D16Async
                _F_cuGetProcAddress_v2('cuMemsetD2D16Async', &__cuMemsetD2D16Async, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemsetD2D32Async
                _F_cuGetProcAddress_v2('cuMemsetD2D32Async', &__cuMemsetD2D32Async, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemBatchDecompressAsync
                _F_cuGetProcAddress_v2('cuMemBatchDecompressAsync', &__cuMemBatchDecompressAsync, 12060, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemMapArrayAsync
                _F_cuGetProcAddress_v2('cuMemMapArrayAsync', &__cuMemMapArrayAsync, 11010, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemFreeAsync
                _F_cuGetProcAddress_v2('cuMemFreeAsync', &__cuMemFreeAsync, 11020, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemAllocAsync
                _F_cuGetProcAddress_v2('cuMemAllocAsync', &__cuMemAllocAsync, 11020, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemAllocFromPoolAsync
                _F_cuGetProcAddress_v2('cuMemAllocFromPoolAsync', &__cuMemAllocFromPoolAsync, 11020, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemPrefetchAsync
                _F_cuGetProcAddress_v2('cuMemPrefetchAsync', &__cuMemPrefetchAsync, 8000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuMemPrefetchAsync_v2
                _F_cuGetProcAddress_v2('cuMemPrefetchAsync', &__cuMemPrefetchAsync_v2, 12020, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuStreamGetPriority
                _F_cuGetProcAddress_v2('cuStreamGetPriority', &__cuStreamGetPriority, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuStreamGetDevice
                _F_cuGetProcAddress_v2('cuStreamGetDevice', &__cuStreamGetDevice, 12080, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuStreamGetFlags
                _F_cuGetProcAddress_v2('cuStreamGetFlags', &__cuStreamGetFlags, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuStreamGetId
                _F_cuGetProcAddress_v2('cuStreamGetId', &__cuStreamGetId, 12000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuStreamGetCtx
                _F_cuGetProcAddress_v2('cuStreamGetCtx', &__cuStreamGetCtx, 9020, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuStreamGetCtx_v2
                _F_cuGetProcAddress_v2('cuStreamGetCtx', &__cuStreamGetCtx_v2, 12050, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuStreamWaitEvent
                _F_cuGetProcAddress_v2('cuStreamWaitEvent', &__cuStreamWaitEvent, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuStreamAddCallback
                _F_cuGetProcAddress_v2('cuStreamAddCallback', &__cuStreamAddCallback, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuStreamBeginCapture_v2
                _F_cuGetProcAddress_v2('cuStreamBeginCapture', &__cuStreamBeginCapture_v2, 10010, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuStreamBeginCaptureToGraph
                _F_cuGetProcAddress_v2('cuStreamBeginCaptureToGraph', &__cuStreamBeginCaptureToGraph, 12030, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuStreamEndCapture
                _F_cuGetProcAddress_v2('cuStreamEndCapture', &__cuStreamEndCapture, 10000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuStreamIsCapturing
                _F_cuGetProcAddress_v2('cuStreamIsCapturing', &__cuStreamIsCapturing, 10000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuStreamGetCaptureInfo_v2
                _F_cuGetProcAddress_v2('cuStreamGetCaptureInfo', &__cuStreamGetCaptureInfo_v2, 11030, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuStreamGetCaptureInfo_v3
                _F_cuGetProcAddress_v2('cuStreamGetCaptureInfo', &__cuStreamGetCaptureInfo_v3, 12030, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuStreamUpdateCaptureDependencies
                _F_cuGetProcAddress_v2('cuStreamUpdateCaptureDependencies', &__cuStreamUpdateCaptureDependencies, 11030, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuStreamUpdateCaptureDependencies_v2
                _F_cuGetProcAddress_v2('cuStreamUpdateCaptureDependencies', &__cuStreamUpdateCaptureDependencies_v2, 12030, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuStreamAttachMemAsync
                _F_cuGetProcAddress_v2('cuStreamAttachMemAsync', &__cuStreamAttachMemAsync, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuStreamQuery
                _F_cuGetProcAddress_v2('cuStreamQuery', &__cuStreamQuery, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuStreamSynchronize
                _F_cuGetProcAddress_v2('cuStreamSynchronize', &__cuStreamSynchronize, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuStreamCopyAttributes
                _F_cuGetProcAddress_v2('cuStreamCopyAttributes', &__cuStreamCopyAttributes, 11000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuStreamGetAttribute
                _F_cuGetProcAddress_v2('cuStreamGetAttribute', &__cuStreamGetAttribute, 11000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuStreamSetAttribute
                _F_cuGetProcAddress_v2('cuStreamSetAttribute', &__cuStreamSetAttribute, 11000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuEventRecord
                _F_cuGetProcAddress_v2('cuEventRecord', &__cuEventRecord, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuEventRecordWithFlags
                _F_cuGetProcAddress_v2('cuEventRecordWithFlags', &__cuEventRecordWithFlags, 11010, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuSignalExternalSemaphoresAsync
                _F_cuGetProcAddress_v2('cuSignalExternalSemaphoresAsync', &__cuSignalExternalSemaphoresAsync, 10000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuWaitExternalSemaphoresAsync
                _F_cuGetProcAddress_v2('cuWaitExternalSemaphoresAsync', &__cuWaitExternalSemaphoresAsync, 10000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuStreamWaitValue32_v2
                _F_cuGetProcAddress_v2('cuStreamWaitValue32', &__cuStreamWaitValue32_v2, 11070, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuStreamWaitValue64_v2
                _F_cuGetProcAddress_v2('cuStreamWaitValue64', &__cuStreamWaitValue64_v2, 11070, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuStreamWriteValue32_v2
                _F_cuGetProcAddress_v2('cuStreamWriteValue32', &__cuStreamWriteValue32_v2, 11070, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuStreamWriteValue64_v2
                _F_cuGetProcAddress_v2('cuStreamWriteValue64', &__cuStreamWriteValue64_v2, 11070, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuStreamBatchMemOp_v2
                _F_cuGetProcAddress_v2('cuStreamBatchMemOp', &__cuStreamBatchMemOp_v2, 11070, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuLaunchKernel
                _F_cuGetProcAddress_v2('cuLaunchKernel', &__cuLaunchKernel, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuLaunchKernelEx
                _F_cuGetProcAddress_v2('cuLaunchKernelEx', &__cuLaunchKernelEx, 11060, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuLaunchCooperativeKernel
                _F_cuGetProcAddress_v2('cuLaunchCooperativeKernel', &__cuLaunchCooperativeKernel, 9000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuLaunchHostFunc
                _F_cuGetProcAddress_v2('cuLaunchHostFunc', &__cuLaunchHostFunc, 10000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuGraphInstantiateWithParams
                _F_cuGetProcAddress_v2('cuGraphInstantiateWithParams', &__cuGraphInstantiateWithParams, 12000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuGraphUpload
                _F_cuGetProcAddress_v2('cuGraphUpload', &__cuGraphUpload, 11010, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuGraphLaunch
                _F_cuGetProcAddress_v2('cuGraphLaunch', &__cuGraphLaunch, 10000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuGraphicsMapResources
                _F_cuGetProcAddress_v2('cuGraphicsMapResources', &__cuGraphicsMapResources, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
                global __cuGraphicsUnmapResources
                _F_cuGetProcAddress_v2('cuGraphicsUnmapResources', &__cuGraphicsUnmapResources, 7000, CU_GET_PROC_ADDRESS_PER_THREAD_DEFAULT_STREAM, NULL)
            else:
                # Else get the regular version
                pass
                global __cuMemcpy
                _F_cuGetProcAddress_v2('cuMemcpy', &__cuMemcpy, 4000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemcpyPeer
                _F_cuGetProcAddress_v2('cuMemcpyPeer', &__cuMemcpyPeer, 4000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemcpyHtoD_v2
                _F_cuGetProcAddress_v2('cuMemcpyHtoD', &__cuMemcpyHtoD_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemcpyDtoH_v2
                _F_cuGetProcAddress_v2('cuMemcpyDtoH', &__cuMemcpyDtoH_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemcpyDtoD_v2
                _F_cuGetProcAddress_v2('cuMemcpyDtoD', &__cuMemcpyDtoD_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemcpyDtoA_v2
                _F_cuGetProcAddress_v2('cuMemcpyDtoA', &__cuMemcpyDtoA_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemcpyAtoD_v2
                _F_cuGetProcAddress_v2('cuMemcpyAtoD', &__cuMemcpyAtoD_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemcpyHtoA_v2
                _F_cuGetProcAddress_v2('cuMemcpyHtoA', &__cuMemcpyHtoA_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemcpyAtoH_v2
                _F_cuGetProcAddress_v2('cuMemcpyAtoH', &__cuMemcpyAtoH_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemcpyAtoA_v2
                _F_cuGetProcAddress_v2('cuMemcpyAtoA', &__cuMemcpyAtoA_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemcpy2D_v2
                _F_cuGetProcAddress_v2('cuMemcpy2D', &__cuMemcpy2D_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemcpy2DUnaligned_v2
                _F_cuGetProcAddress_v2('cuMemcpy2DUnaligned', &__cuMemcpy2DUnaligned_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemcpy3D_v2
                _F_cuGetProcAddress_v2('cuMemcpy3D', &__cuMemcpy3D_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemcpy3DPeer
                _F_cuGetProcAddress_v2('cuMemcpy3DPeer', &__cuMemcpy3DPeer, 4000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemcpyAsync
                _F_cuGetProcAddress_v2('cuMemcpyAsync', &__cuMemcpyAsync, 4000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemcpyPeerAsync
                _F_cuGetProcAddress_v2('cuMemcpyPeerAsync', &__cuMemcpyPeerAsync, 4000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemcpyHtoDAsync_v2
                _F_cuGetProcAddress_v2('cuMemcpyHtoDAsync', &__cuMemcpyHtoDAsync_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemcpyDtoHAsync_v2
                _F_cuGetProcAddress_v2('cuMemcpyDtoHAsync', &__cuMemcpyDtoHAsync_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemcpyDtoDAsync_v2
                _F_cuGetProcAddress_v2('cuMemcpyDtoDAsync', &__cuMemcpyDtoDAsync_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemcpyHtoAAsync_v2
                _F_cuGetProcAddress_v2('cuMemcpyHtoAAsync', &__cuMemcpyHtoAAsync_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemcpyAtoHAsync_v2
                _F_cuGetProcAddress_v2('cuMemcpyAtoHAsync', &__cuMemcpyAtoHAsync_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemcpy2DAsync_v2
                _F_cuGetProcAddress_v2('cuMemcpy2DAsync', &__cuMemcpy2DAsync_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemcpy3DAsync_v2
                _F_cuGetProcAddress_v2('cuMemcpy3DAsync', &__cuMemcpy3DAsync_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemcpy3DPeerAsync
                _F_cuGetProcAddress_v2('cuMemcpy3DPeerAsync', &__cuMemcpy3DPeerAsync, 4000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemcpyBatchAsync
                _F_cuGetProcAddress_v2('cuMemcpyBatchAsync', &__cuMemcpyBatchAsync, 12080, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemcpy3DBatchAsync
                _F_cuGetProcAddress_v2('cuMemcpy3DBatchAsync', &__cuMemcpy3DBatchAsync, 12080, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemsetD8_v2
                _F_cuGetProcAddress_v2('cuMemsetD8', &__cuMemsetD8_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemsetD16_v2
                _F_cuGetProcAddress_v2('cuMemsetD16', &__cuMemsetD16_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemsetD32_v2
                _F_cuGetProcAddress_v2('cuMemsetD32', &__cuMemsetD32_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemsetD2D8_v2
                _F_cuGetProcAddress_v2('cuMemsetD2D8', &__cuMemsetD2D8_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemsetD2D16_v2
                _F_cuGetProcAddress_v2('cuMemsetD2D16', &__cuMemsetD2D16_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemsetD2D32_v2
                _F_cuGetProcAddress_v2('cuMemsetD2D32', &__cuMemsetD2D32_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemsetD8Async
                _F_cuGetProcAddress_v2('cuMemsetD8Async', &__cuMemsetD8Async, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemsetD16Async
                _F_cuGetProcAddress_v2('cuMemsetD16Async', &__cuMemsetD16Async, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemsetD32Async
                _F_cuGetProcAddress_v2('cuMemsetD32Async', &__cuMemsetD32Async, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemsetD2D8Async
                _F_cuGetProcAddress_v2('cuMemsetD2D8Async', &__cuMemsetD2D8Async, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemsetD2D16Async
                _F_cuGetProcAddress_v2('cuMemsetD2D16Async', &__cuMemsetD2D16Async, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemsetD2D32Async
                _F_cuGetProcAddress_v2('cuMemsetD2D32Async', &__cuMemsetD2D32Async, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemBatchDecompressAsync
                _F_cuGetProcAddress_v2('cuMemBatchDecompressAsync', &__cuMemBatchDecompressAsync, 12060, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemMapArrayAsync
                _F_cuGetProcAddress_v2('cuMemMapArrayAsync', &__cuMemMapArrayAsync, 11010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemFreeAsync
                _F_cuGetProcAddress_v2('cuMemFreeAsync', &__cuMemFreeAsync, 11020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemAllocAsync
                _F_cuGetProcAddress_v2('cuMemAllocAsync', &__cuMemAllocAsync, 11020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemAllocFromPoolAsync
                _F_cuGetProcAddress_v2('cuMemAllocFromPoolAsync', &__cuMemAllocFromPoolAsync, 11020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemPrefetchAsync
                _F_cuGetProcAddress_v2('cuMemPrefetchAsync', &__cuMemPrefetchAsync, 8000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuMemPrefetchAsync_v2
                _F_cuGetProcAddress_v2('cuMemPrefetchAsync', &__cuMemPrefetchAsync_v2, 12020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuStreamGetPriority
                _F_cuGetProcAddress_v2('cuStreamGetPriority', &__cuStreamGetPriority, 5050, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuStreamGetDevice
                _F_cuGetProcAddress_v2('cuStreamGetDevice', &__cuStreamGetDevice, 12080, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuStreamGetFlags
                _F_cuGetProcAddress_v2('cuStreamGetFlags', &__cuStreamGetFlags, 5050, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuStreamGetId
                _F_cuGetProcAddress_v2('cuStreamGetId', &__cuStreamGetId, 12000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuStreamGetCtx
                _F_cuGetProcAddress_v2('cuStreamGetCtx', &__cuStreamGetCtx, 9020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuStreamGetCtx_v2
                _F_cuGetProcAddress_v2('cuStreamGetCtx', &__cuStreamGetCtx_v2, 12050, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuStreamWaitEvent
                _F_cuGetProcAddress_v2('cuStreamWaitEvent', &__cuStreamWaitEvent, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuStreamAddCallback
                _F_cuGetProcAddress_v2('cuStreamAddCallback', &__cuStreamAddCallback, 5000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuStreamBeginCapture_v2
                _F_cuGetProcAddress_v2('cuStreamBeginCapture', &__cuStreamBeginCapture_v2, 10010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuStreamBeginCaptureToGraph
                _F_cuGetProcAddress_v2('cuStreamBeginCaptureToGraph', &__cuStreamBeginCaptureToGraph, 12030, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuStreamEndCapture
                _F_cuGetProcAddress_v2('cuStreamEndCapture', &__cuStreamEndCapture, 10000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuStreamIsCapturing
                _F_cuGetProcAddress_v2('cuStreamIsCapturing', &__cuStreamIsCapturing, 10000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuStreamGetCaptureInfo_v2
                _F_cuGetProcAddress_v2('cuStreamGetCaptureInfo', &__cuStreamGetCaptureInfo_v2, 11030, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuStreamGetCaptureInfo_v3
                _F_cuGetProcAddress_v2('cuStreamGetCaptureInfo', &__cuStreamGetCaptureInfo_v3, 12030, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuStreamUpdateCaptureDependencies
                _F_cuGetProcAddress_v2('cuStreamUpdateCaptureDependencies', &__cuStreamUpdateCaptureDependencies, 11030, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuStreamUpdateCaptureDependencies_v2
                _F_cuGetProcAddress_v2('cuStreamUpdateCaptureDependencies', &__cuStreamUpdateCaptureDependencies_v2, 12030, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuStreamAttachMemAsync
                _F_cuGetProcAddress_v2('cuStreamAttachMemAsync', &__cuStreamAttachMemAsync, 6000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuStreamQuery
                _F_cuGetProcAddress_v2('cuStreamQuery', &__cuStreamQuery, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuStreamSynchronize
                _F_cuGetProcAddress_v2('cuStreamSynchronize', &__cuStreamSynchronize, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuStreamCopyAttributes
                _F_cuGetProcAddress_v2('cuStreamCopyAttributes', &__cuStreamCopyAttributes, 11000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuStreamGetAttribute
                _F_cuGetProcAddress_v2('cuStreamGetAttribute', &__cuStreamGetAttribute, 11000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuStreamSetAttribute
                _F_cuGetProcAddress_v2('cuStreamSetAttribute', &__cuStreamSetAttribute, 11000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuEventRecord
                _F_cuGetProcAddress_v2('cuEventRecord', &__cuEventRecord, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuEventRecordWithFlags
                _F_cuGetProcAddress_v2('cuEventRecordWithFlags', &__cuEventRecordWithFlags, 11010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuSignalExternalSemaphoresAsync
                _F_cuGetProcAddress_v2('cuSignalExternalSemaphoresAsync', &__cuSignalExternalSemaphoresAsync, 10000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuWaitExternalSemaphoresAsync
                _F_cuGetProcAddress_v2('cuWaitExternalSemaphoresAsync', &__cuWaitExternalSemaphoresAsync, 10000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuStreamWaitValue32_v2
                _F_cuGetProcAddress_v2('cuStreamWaitValue32', &__cuStreamWaitValue32_v2, 11070, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuStreamWaitValue64_v2
                _F_cuGetProcAddress_v2('cuStreamWaitValue64', &__cuStreamWaitValue64_v2, 11070, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuStreamWriteValue32_v2
                _F_cuGetProcAddress_v2('cuStreamWriteValue32', &__cuStreamWriteValue32_v2, 11070, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuStreamWriteValue64_v2
                _F_cuGetProcAddress_v2('cuStreamWriteValue64', &__cuStreamWriteValue64_v2, 11070, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuStreamBatchMemOp_v2
                _F_cuGetProcAddress_v2('cuStreamBatchMemOp', &__cuStreamBatchMemOp_v2, 11070, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuLaunchKernel
                _F_cuGetProcAddress_v2('cuLaunchKernel', &__cuLaunchKernel, 4000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuLaunchKernelEx
                _F_cuGetProcAddress_v2('cuLaunchKernelEx', &__cuLaunchKernelEx, 11060, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuLaunchCooperativeKernel
                _F_cuGetProcAddress_v2('cuLaunchCooperativeKernel', &__cuLaunchCooperativeKernel, 9000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuLaunchHostFunc
                _F_cuGetProcAddress_v2('cuLaunchHostFunc', &__cuLaunchHostFunc, 10000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuGraphInstantiateWithParams
                _F_cuGetProcAddress_v2('cuGraphInstantiateWithParams', &__cuGraphInstantiateWithParams, 12000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuGraphUpload
                _F_cuGetProcAddress_v2('cuGraphUpload', &__cuGraphUpload, 11010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuGraphLaunch
                _F_cuGetProcAddress_v2('cuGraphLaunch', &__cuGraphLaunch, 10000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuGraphicsMapResources
                _F_cuGetProcAddress_v2('cuGraphicsMapResources', &__cuGraphicsMapResources, 3000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
                global __cuGraphicsUnmapResources
                _F_cuGetProcAddress_v2('cuGraphicsUnmapResources', &__cuGraphicsUnmapResources, 3000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            # Get remaining functions
            global __cuGetErrorString
            _F_cuGetProcAddress_v2('cuGetErrorString', &__cuGetErrorString, 6000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGetErrorName
            _F_cuGetProcAddress_v2('cuGetErrorName', &__cuGetErrorName, 6000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuInit
            _F_cuGetProcAddress_v2('cuInit', &__cuInit, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuDriverGetVersion
            _F_cuGetProcAddress_v2('cuDriverGetVersion', &__cuDriverGetVersion, 2020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuDeviceGet
            _F_cuGetProcAddress_v2('cuDeviceGet', &__cuDeviceGet, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuDeviceGetCount
            _F_cuGetProcAddress_v2('cuDeviceGetCount', &__cuDeviceGetCount, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuDeviceGetName
            _F_cuGetProcAddress_v2('cuDeviceGetName', &__cuDeviceGetName, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuDeviceGetUuid
            _F_cuGetProcAddress_v2('cuDeviceGetUuid', &__cuDeviceGetUuid, 9020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuDeviceGetUuid_v2
            _F_cuGetProcAddress_v2('cuDeviceGetUuid', &__cuDeviceGetUuid_v2, 11040, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuDeviceGetLuid
            _F_cuGetProcAddress_v2('cuDeviceGetLuid', &__cuDeviceGetLuid, 10000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuDeviceTotalMem_v2
            _F_cuGetProcAddress_v2('cuDeviceTotalMem', &__cuDeviceTotalMem_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuDeviceGetTexture1DLinearMaxWidth
            _F_cuGetProcAddress_v2('cuDeviceGetTexture1DLinearMaxWidth', &__cuDeviceGetTexture1DLinearMaxWidth, 11010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuDeviceGetAttribute
            _F_cuGetProcAddress_v2('cuDeviceGetAttribute', &__cuDeviceGetAttribute, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuDeviceGetNvSciSyncAttributes
            _F_cuGetProcAddress_v2('cuDeviceGetNvSciSyncAttributes', &__cuDeviceGetNvSciSyncAttributes, 10020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuDeviceSetMemPool
            _F_cuGetProcAddress_v2('cuDeviceSetMemPool', &__cuDeviceSetMemPool, 11020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuDeviceGetMemPool
            _F_cuGetProcAddress_v2('cuDeviceGetMemPool', &__cuDeviceGetMemPool, 11020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuDeviceGetDefaultMemPool
            _F_cuGetProcAddress_v2('cuDeviceGetDefaultMemPool', &__cuDeviceGetDefaultMemPool, 11020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuDeviceGetExecAffinitySupport
            _F_cuGetProcAddress_v2('cuDeviceGetExecAffinitySupport', &__cuDeviceGetExecAffinitySupport, 11040, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuFlushGPUDirectRDMAWrites
            _F_cuGetProcAddress_v2('cuFlushGPUDirectRDMAWrites', &__cuFlushGPUDirectRDMAWrites, 11030, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuDeviceGetProperties
            _F_cuGetProcAddress_v2('cuDeviceGetProperties', &__cuDeviceGetProperties, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuDeviceComputeCapability
            _F_cuGetProcAddress_v2('cuDeviceComputeCapability', &__cuDeviceComputeCapability, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuDevicePrimaryCtxRetain
            _F_cuGetProcAddress_v2('cuDevicePrimaryCtxRetain', &__cuDevicePrimaryCtxRetain, 7000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuDevicePrimaryCtxRelease_v2
            _F_cuGetProcAddress_v2('cuDevicePrimaryCtxRelease', &__cuDevicePrimaryCtxRelease_v2, 11000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuDevicePrimaryCtxSetFlags_v2
            _F_cuGetProcAddress_v2('cuDevicePrimaryCtxSetFlags', &__cuDevicePrimaryCtxSetFlags_v2, 11000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuDevicePrimaryCtxGetState
            _F_cuGetProcAddress_v2('cuDevicePrimaryCtxGetState', &__cuDevicePrimaryCtxGetState, 7000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuDevicePrimaryCtxReset_v2
            _F_cuGetProcAddress_v2('cuDevicePrimaryCtxReset', &__cuDevicePrimaryCtxReset_v2, 11000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCtxCreate_v2
            _F_cuGetProcAddress_v2('cuCtxCreate', &__cuCtxCreate_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCtxCreate_v3
            _F_cuGetProcAddress_v2('cuCtxCreate', &__cuCtxCreate_v3, 11040, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCtxCreate_v4
            _F_cuGetProcAddress_v2('cuCtxCreate', &__cuCtxCreate_v4, 12050, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCtxDestroy_v2
            _F_cuGetProcAddress_v2('cuCtxDestroy', &__cuCtxDestroy_v2, 4000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCtxPushCurrent_v2
            _F_cuGetProcAddress_v2('cuCtxPushCurrent', &__cuCtxPushCurrent_v2, 4000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCtxPopCurrent_v2
            _F_cuGetProcAddress_v2('cuCtxPopCurrent', &__cuCtxPopCurrent_v2, 4000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCtxSetCurrent
            _F_cuGetProcAddress_v2('cuCtxSetCurrent', &__cuCtxSetCurrent, 4000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCtxGetCurrent
            _F_cuGetProcAddress_v2('cuCtxGetCurrent', &__cuCtxGetCurrent, 4000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCtxGetDevice
            _F_cuGetProcAddress_v2('cuCtxGetDevice', &__cuCtxGetDevice, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCtxGetFlags
            _F_cuGetProcAddress_v2('cuCtxGetFlags', &__cuCtxGetFlags, 7000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCtxSetFlags
            _F_cuGetProcAddress_v2('cuCtxSetFlags', &__cuCtxSetFlags, 12010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCtxGetId
            _F_cuGetProcAddress_v2('cuCtxGetId', &__cuCtxGetId, 12000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCtxSynchronize
            _F_cuGetProcAddress_v2('cuCtxSynchronize', &__cuCtxSynchronize, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCtxSetLimit
            _F_cuGetProcAddress_v2('cuCtxSetLimit', &__cuCtxSetLimit, 3010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCtxGetLimit
            _F_cuGetProcAddress_v2('cuCtxGetLimit', &__cuCtxGetLimit, 3010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCtxGetCacheConfig
            _F_cuGetProcAddress_v2('cuCtxGetCacheConfig', &__cuCtxGetCacheConfig, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCtxSetCacheConfig
            _F_cuGetProcAddress_v2('cuCtxSetCacheConfig', &__cuCtxSetCacheConfig, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCtxGetApiVersion
            _F_cuGetProcAddress_v2('cuCtxGetApiVersion', &__cuCtxGetApiVersion, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCtxGetStreamPriorityRange
            _F_cuGetProcAddress_v2('cuCtxGetStreamPriorityRange', &__cuCtxGetStreamPriorityRange, 5050, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCtxResetPersistingL2Cache
            _F_cuGetProcAddress_v2('cuCtxResetPersistingL2Cache', &__cuCtxResetPersistingL2Cache, 11000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCtxGetExecAffinity
            _F_cuGetProcAddress_v2('cuCtxGetExecAffinity', &__cuCtxGetExecAffinity, 11040, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCtxRecordEvent
            _F_cuGetProcAddress_v2('cuCtxRecordEvent', &__cuCtxRecordEvent, 12050, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCtxWaitEvent
            _F_cuGetProcAddress_v2('cuCtxWaitEvent', &__cuCtxWaitEvent, 12050, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCtxAttach
            _F_cuGetProcAddress_v2('cuCtxAttach', &__cuCtxAttach, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCtxDetach
            _F_cuGetProcAddress_v2('cuCtxDetach', &__cuCtxDetach, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCtxGetSharedMemConfig
            _F_cuGetProcAddress_v2('cuCtxGetSharedMemConfig', &__cuCtxGetSharedMemConfig, 4020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCtxSetSharedMemConfig
            _F_cuGetProcAddress_v2('cuCtxSetSharedMemConfig', &__cuCtxSetSharedMemConfig, 4020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuModuleLoad
            _F_cuGetProcAddress_v2('cuModuleLoad', &__cuModuleLoad, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuModuleLoadData
            _F_cuGetProcAddress_v2('cuModuleLoadData', &__cuModuleLoadData, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuModuleLoadDataEx
            _F_cuGetProcAddress_v2('cuModuleLoadDataEx', &__cuModuleLoadDataEx, 2010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuModuleLoadFatBinary
            _F_cuGetProcAddress_v2('cuModuleLoadFatBinary', &__cuModuleLoadFatBinary, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuModuleUnload
            _F_cuGetProcAddress_v2('cuModuleUnload', &__cuModuleUnload, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuModuleGetLoadingMode
            _F_cuGetProcAddress_v2('cuModuleGetLoadingMode', &__cuModuleGetLoadingMode, 11070, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuModuleGetFunction
            _F_cuGetProcAddress_v2('cuModuleGetFunction', &__cuModuleGetFunction, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuModuleGetFunctionCount
            _F_cuGetProcAddress_v2('cuModuleGetFunctionCount', &__cuModuleGetFunctionCount, 12040, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuModuleEnumerateFunctions
            _F_cuGetProcAddress_v2('cuModuleEnumerateFunctions', &__cuModuleEnumerateFunctions, 12040, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuModuleGetGlobal_v2
            _F_cuGetProcAddress_v2('cuModuleGetGlobal', &__cuModuleGetGlobal_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuLinkCreate_v2
            _F_cuGetProcAddress_v2('cuLinkCreate', &__cuLinkCreate_v2, 6050, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuLinkAddData_v2
            _F_cuGetProcAddress_v2('cuLinkAddData', &__cuLinkAddData_v2, 6050, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuLinkAddFile_v2
            _F_cuGetProcAddress_v2('cuLinkAddFile', &__cuLinkAddFile_v2, 6050, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuLinkComplete
            _F_cuGetProcAddress_v2('cuLinkComplete', &__cuLinkComplete, 5050, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuLinkDestroy
            _F_cuGetProcAddress_v2('cuLinkDestroy', &__cuLinkDestroy, 5050, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuModuleGetTexRef
            _F_cuGetProcAddress_v2('cuModuleGetTexRef', &__cuModuleGetTexRef, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuModuleGetSurfRef
            _F_cuGetProcAddress_v2('cuModuleGetSurfRef', &__cuModuleGetSurfRef, 3000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuLibraryLoadData
            _F_cuGetProcAddress_v2('cuLibraryLoadData', &__cuLibraryLoadData, 12000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuLibraryLoadFromFile
            _F_cuGetProcAddress_v2('cuLibraryLoadFromFile', &__cuLibraryLoadFromFile, 12000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuLibraryUnload
            _F_cuGetProcAddress_v2('cuLibraryUnload', &__cuLibraryUnload, 12000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuLibraryGetKernel
            _F_cuGetProcAddress_v2('cuLibraryGetKernel', &__cuLibraryGetKernel, 12000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuLibraryGetKernelCount
            _F_cuGetProcAddress_v2('cuLibraryGetKernelCount', &__cuLibraryGetKernelCount, 12040, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuLibraryEnumerateKernels
            _F_cuGetProcAddress_v2('cuLibraryEnumerateKernels', &__cuLibraryEnumerateKernels, 12040, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuLibraryGetModule
            _F_cuGetProcAddress_v2('cuLibraryGetModule', &__cuLibraryGetModule, 12000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuKernelGetFunction
            _F_cuGetProcAddress_v2('cuKernelGetFunction', &__cuKernelGetFunction, 12000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuKernelGetLibrary
            _F_cuGetProcAddress_v2('cuKernelGetLibrary', &__cuKernelGetLibrary, 12050, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuLibraryGetGlobal
            _F_cuGetProcAddress_v2('cuLibraryGetGlobal', &__cuLibraryGetGlobal, 12000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuLibraryGetManaged
            _F_cuGetProcAddress_v2('cuLibraryGetManaged', &__cuLibraryGetManaged, 12000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuLibraryGetUnifiedFunction
            _F_cuGetProcAddress_v2('cuLibraryGetUnifiedFunction', &__cuLibraryGetUnifiedFunction, 12000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuKernelGetAttribute
            _F_cuGetProcAddress_v2('cuKernelGetAttribute', &__cuKernelGetAttribute, 12000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuKernelSetAttribute
            _F_cuGetProcAddress_v2('cuKernelSetAttribute', &__cuKernelSetAttribute, 12000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuKernelSetCacheConfig
            _F_cuGetProcAddress_v2('cuKernelSetCacheConfig', &__cuKernelSetCacheConfig, 12000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuKernelGetName
            _F_cuGetProcAddress_v2('cuKernelGetName', &__cuKernelGetName, 12030, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuKernelGetParamInfo
            _F_cuGetProcAddress_v2('cuKernelGetParamInfo', &__cuKernelGetParamInfo, 12040, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemGetInfo_v2
            _F_cuGetProcAddress_v2('cuMemGetInfo', &__cuMemGetInfo_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemAlloc_v2
            _F_cuGetProcAddress_v2('cuMemAlloc', &__cuMemAlloc_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemAllocPitch_v2
            _F_cuGetProcAddress_v2('cuMemAllocPitch', &__cuMemAllocPitch_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemFree_v2
            _F_cuGetProcAddress_v2('cuMemFree', &__cuMemFree_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemGetAddressRange_v2
            _F_cuGetProcAddress_v2('cuMemGetAddressRange', &__cuMemGetAddressRange_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemAllocHost_v2
            _F_cuGetProcAddress_v2('cuMemAllocHost', &__cuMemAllocHost_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemFreeHost
            _F_cuGetProcAddress_v2('cuMemFreeHost', &__cuMemFreeHost, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemHostAlloc
            _F_cuGetProcAddress_v2('cuMemHostAlloc', &__cuMemHostAlloc, 2020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemHostGetDevicePointer_v2
            _F_cuGetProcAddress_v2('cuMemHostGetDevicePointer', &__cuMemHostGetDevicePointer_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemHostGetFlags
            _F_cuGetProcAddress_v2('cuMemHostGetFlags', &__cuMemHostGetFlags, 2030, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemAllocManaged
            _F_cuGetProcAddress_v2('cuMemAllocManaged', &__cuMemAllocManaged, 6000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuDeviceRegisterAsyncNotification
            _F_cuGetProcAddress_v2('cuDeviceRegisterAsyncNotification', &__cuDeviceRegisterAsyncNotification, 12040, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuDeviceUnregisterAsyncNotification
            _F_cuGetProcAddress_v2('cuDeviceUnregisterAsyncNotification', &__cuDeviceUnregisterAsyncNotification, 12040, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuDeviceGetByPCIBusId
            _F_cuGetProcAddress_v2('cuDeviceGetByPCIBusId', &__cuDeviceGetByPCIBusId, 4010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuDeviceGetPCIBusId
            _F_cuGetProcAddress_v2('cuDeviceGetPCIBusId', &__cuDeviceGetPCIBusId, 4010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuIpcGetEventHandle
            _F_cuGetProcAddress_v2('cuIpcGetEventHandle', &__cuIpcGetEventHandle, 4010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuIpcOpenEventHandle
            _F_cuGetProcAddress_v2('cuIpcOpenEventHandle', &__cuIpcOpenEventHandle, 4010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuIpcGetMemHandle
            _F_cuGetProcAddress_v2('cuIpcGetMemHandle', &__cuIpcGetMemHandle, 4010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuIpcOpenMemHandle_v2
            _F_cuGetProcAddress_v2('cuIpcOpenMemHandle', &__cuIpcOpenMemHandle_v2, 11000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuIpcCloseMemHandle
            _F_cuGetProcAddress_v2('cuIpcCloseMemHandle', &__cuIpcCloseMemHandle, 4010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemHostRegister_v2
            _F_cuGetProcAddress_v2('cuMemHostRegister', &__cuMemHostRegister_v2, 6050, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemHostUnregister
            _F_cuGetProcAddress_v2('cuMemHostUnregister', &__cuMemHostUnregister, 4000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuArrayCreate_v2
            _F_cuGetProcAddress_v2('cuArrayCreate', &__cuArrayCreate_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuArrayGetDescriptor_v2
            _F_cuGetProcAddress_v2('cuArrayGetDescriptor', &__cuArrayGetDescriptor_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuArrayGetSparseProperties
            _F_cuGetProcAddress_v2('cuArrayGetSparseProperties', &__cuArrayGetSparseProperties, 11010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMipmappedArrayGetSparseProperties
            _F_cuGetProcAddress_v2('cuMipmappedArrayGetSparseProperties', &__cuMipmappedArrayGetSparseProperties, 11010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuArrayGetMemoryRequirements
            _F_cuGetProcAddress_v2('cuArrayGetMemoryRequirements', &__cuArrayGetMemoryRequirements, 11060, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMipmappedArrayGetMemoryRequirements
            _F_cuGetProcAddress_v2('cuMipmappedArrayGetMemoryRequirements', &__cuMipmappedArrayGetMemoryRequirements, 11060, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuArrayGetPlane
            _F_cuGetProcAddress_v2('cuArrayGetPlane', &__cuArrayGetPlane, 11020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuArrayDestroy
            _F_cuGetProcAddress_v2('cuArrayDestroy', &__cuArrayDestroy, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuArray3DCreate_v2
            _F_cuGetProcAddress_v2('cuArray3DCreate', &__cuArray3DCreate_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuArray3DGetDescriptor_v2
            _F_cuGetProcAddress_v2('cuArray3DGetDescriptor', &__cuArray3DGetDescriptor_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMipmappedArrayCreate
            _F_cuGetProcAddress_v2('cuMipmappedArrayCreate', &__cuMipmappedArrayCreate, 5000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMipmappedArrayGetLevel
            _F_cuGetProcAddress_v2('cuMipmappedArrayGetLevel', &__cuMipmappedArrayGetLevel, 5000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMipmappedArrayDestroy
            _F_cuGetProcAddress_v2('cuMipmappedArrayDestroy', &__cuMipmappedArrayDestroy, 5000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemGetHandleForAddressRange
            _F_cuGetProcAddress_v2('cuMemGetHandleForAddressRange', &__cuMemGetHandleForAddressRange, 11070, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemAddressReserve
            _F_cuGetProcAddress_v2('cuMemAddressReserve', &__cuMemAddressReserve, 10020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemAddressFree
            _F_cuGetProcAddress_v2('cuMemAddressFree', &__cuMemAddressFree, 10020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemCreate
            _F_cuGetProcAddress_v2('cuMemCreate', &__cuMemCreate, 10020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemRelease
            _F_cuGetProcAddress_v2('cuMemRelease', &__cuMemRelease, 10020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemMap
            _F_cuGetProcAddress_v2('cuMemMap', &__cuMemMap, 10020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemUnmap
            _F_cuGetProcAddress_v2('cuMemUnmap', &__cuMemUnmap, 10020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemSetAccess
            _F_cuGetProcAddress_v2('cuMemSetAccess', &__cuMemSetAccess, 10020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemGetAccess
            _F_cuGetProcAddress_v2('cuMemGetAccess', &__cuMemGetAccess, 10020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemExportToShareableHandle
            _F_cuGetProcAddress_v2('cuMemExportToShareableHandle', &__cuMemExportToShareableHandle, 10020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemImportFromShareableHandle
            _F_cuGetProcAddress_v2('cuMemImportFromShareableHandle', &__cuMemImportFromShareableHandle, 10020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemGetAllocationGranularity
            _F_cuGetProcAddress_v2('cuMemGetAllocationGranularity', &__cuMemGetAllocationGranularity, 10020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemGetAllocationPropertiesFromHandle
            _F_cuGetProcAddress_v2('cuMemGetAllocationPropertiesFromHandle', &__cuMemGetAllocationPropertiesFromHandle, 10020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemRetainAllocationHandle
            _F_cuGetProcAddress_v2('cuMemRetainAllocationHandle', &__cuMemRetainAllocationHandle, 11000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemPoolTrimTo
            _F_cuGetProcAddress_v2('cuMemPoolTrimTo', &__cuMemPoolTrimTo, 11020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemPoolSetAttribute
            _F_cuGetProcAddress_v2('cuMemPoolSetAttribute', &__cuMemPoolSetAttribute, 11020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemPoolGetAttribute
            _F_cuGetProcAddress_v2('cuMemPoolGetAttribute', &__cuMemPoolGetAttribute, 11020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemPoolSetAccess
            _F_cuGetProcAddress_v2('cuMemPoolSetAccess', &__cuMemPoolSetAccess, 11020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemPoolGetAccess
            _F_cuGetProcAddress_v2('cuMemPoolGetAccess', &__cuMemPoolGetAccess, 11020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemPoolCreate
            _F_cuGetProcAddress_v2('cuMemPoolCreate', &__cuMemPoolCreate, 11020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemPoolDestroy
            _F_cuGetProcAddress_v2('cuMemPoolDestroy', &__cuMemPoolDestroy, 11020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemPoolExportToShareableHandle
            _F_cuGetProcAddress_v2('cuMemPoolExportToShareableHandle', &__cuMemPoolExportToShareableHandle, 11020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemPoolImportFromShareableHandle
            _F_cuGetProcAddress_v2('cuMemPoolImportFromShareableHandle', &__cuMemPoolImportFromShareableHandle, 11020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemPoolExportPointer
            _F_cuGetProcAddress_v2('cuMemPoolExportPointer', &__cuMemPoolExportPointer, 11020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemPoolImportPointer
            _F_cuGetProcAddress_v2('cuMemPoolImportPointer', &__cuMemPoolImportPointer, 11020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMulticastCreate
            _F_cuGetProcAddress_v2('cuMulticastCreate', &__cuMulticastCreate, 12010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMulticastAddDevice
            _F_cuGetProcAddress_v2('cuMulticastAddDevice', &__cuMulticastAddDevice, 12010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMulticastBindMem
            _F_cuGetProcAddress_v2('cuMulticastBindMem', &__cuMulticastBindMem, 12010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMulticastBindAddr
            _F_cuGetProcAddress_v2('cuMulticastBindAddr', &__cuMulticastBindAddr, 12010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMulticastUnbind
            _F_cuGetProcAddress_v2('cuMulticastUnbind', &__cuMulticastUnbind, 12010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMulticastGetGranularity
            _F_cuGetProcAddress_v2('cuMulticastGetGranularity', &__cuMulticastGetGranularity, 12010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuPointerGetAttribute
            _F_cuGetProcAddress_v2('cuPointerGetAttribute', &__cuPointerGetAttribute, 4000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemAdvise
            _F_cuGetProcAddress_v2('cuMemAdvise', &__cuMemAdvise, 8000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemAdvise_v2
            _F_cuGetProcAddress_v2('cuMemAdvise', &__cuMemAdvise_v2, 12020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemRangeGetAttribute
            _F_cuGetProcAddress_v2('cuMemRangeGetAttribute', &__cuMemRangeGetAttribute, 8000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuMemRangeGetAttributes
            _F_cuGetProcAddress_v2('cuMemRangeGetAttributes', &__cuMemRangeGetAttributes, 8000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuPointerSetAttribute
            _F_cuGetProcAddress_v2('cuPointerSetAttribute', &__cuPointerSetAttribute, 6000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuPointerGetAttributes
            _F_cuGetProcAddress_v2('cuPointerGetAttributes', &__cuPointerGetAttributes, 7000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuStreamCreate
            _F_cuGetProcAddress_v2('cuStreamCreate', &__cuStreamCreate, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuStreamCreateWithPriority
            _F_cuGetProcAddress_v2('cuStreamCreateWithPriority', &__cuStreamCreateWithPriority, 5050, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuThreadExchangeStreamCaptureMode
            _F_cuGetProcAddress_v2('cuThreadExchangeStreamCaptureMode', &__cuThreadExchangeStreamCaptureMode, 10010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuStreamDestroy_v2
            _F_cuGetProcAddress_v2('cuStreamDestroy', &__cuStreamDestroy_v2, 4000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuEventCreate
            _F_cuGetProcAddress_v2('cuEventCreate', &__cuEventCreate, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuEventQuery
            _F_cuGetProcAddress_v2('cuEventQuery', &__cuEventQuery, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuEventSynchronize
            _F_cuGetProcAddress_v2('cuEventSynchronize', &__cuEventSynchronize, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuEventDestroy_v2
            _F_cuGetProcAddress_v2('cuEventDestroy', &__cuEventDestroy_v2, 4000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuEventElapsedTime
            _F_cuGetProcAddress_v2('cuEventElapsedTime', &__cuEventElapsedTime, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuEventElapsedTime_v2
            _F_cuGetProcAddress_v2('cuEventElapsedTime', &__cuEventElapsedTime_v2, 12080, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuImportExternalMemory
            _F_cuGetProcAddress_v2('cuImportExternalMemory', &__cuImportExternalMemory, 10000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuExternalMemoryGetMappedBuffer
            _F_cuGetProcAddress_v2('cuExternalMemoryGetMappedBuffer', &__cuExternalMemoryGetMappedBuffer, 10000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuExternalMemoryGetMappedMipmappedArray
            _F_cuGetProcAddress_v2('cuExternalMemoryGetMappedMipmappedArray', &__cuExternalMemoryGetMappedMipmappedArray, 10000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuDestroyExternalMemory
            _F_cuGetProcAddress_v2('cuDestroyExternalMemory', &__cuDestroyExternalMemory, 10000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuImportExternalSemaphore
            _F_cuGetProcAddress_v2('cuImportExternalSemaphore', &__cuImportExternalSemaphore, 10000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuDestroyExternalSemaphore
            _F_cuGetProcAddress_v2('cuDestroyExternalSemaphore', &__cuDestroyExternalSemaphore, 10000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuFuncGetAttribute
            _F_cuGetProcAddress_v2('cuFuncGetAttribute', &__cuFuncGetAttribute, 2020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuFuncSetAttribute
            _F_cuGetProcAddress_v2('cuFuncSetAttribute', &__cuFuncSetAttribute, 9000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuFuncSetCacheConfig
            _F_cuGetProcAddress_v2('cuFuncSetCacheConfig', &__cuFuncSetCacheConfig, 3000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuFuncGetModule
            _F_cuGetProcAddress_v2('cuFuncGetModule', &__cuFuncGetModule, 11000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuFuncGetName
            _F_cuGetProcAddress_v2('cuFuncGetName', &__cuFuncGetName, 12030, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuFuncGetParamInfo
            _F_cuGetProcAddress_v2('cuFuncGetParamInfo', &__cuFuncGetParamInfo, 12040, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuFuncIsLoaded
            _F_cuGetProcAddress_v2('cuFuncIsLoaded', &__cuFuncIsLoaded, 12040, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuFuncLoad
            _F_cuGetProcAddress_v2('cuFuncLoad', &__cuFuncLoad, 12040, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuLaunchCooperativeKernelMultiDevice
            _F_cuGetProcAddress_v2('cuLaunchCooperativeKernelMultiDevice', &__cuLaunchCooperativeKernelMultiDevice, 9000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuFuncSetBlockShape
            _F_cuGetProcAddress_v2('cuFuncSetBlockShape', &__cuFuncSetBlockShape, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuFuncSetSharedSize
            _F_cuGetProcAddress_v2('cuFuncSetSharedSize', &__cuFuncSetSharedSize, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuParamSetSize
            _F_cuGetProcAddress_v2('cuParamSetSize', &__cuParamSetSize, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuParamSeti
            _F_cuGetProcAddress_v2('cuParamSeti', &__cuParamSeti, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuParamSetf
            _F_cuGetProcAddress_v2('cuParamSetf', &__cuParamSetf, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuParamSetv
            _F_cuGetProcAddress_v2('cuParamSetv', &__cuParamSetv, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuLaunch
            _F_cuGetProcAddress_v2('cuLaunch', &__cuLaunch, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuLaunchGrid
            _F_cuGetProcAddress_v2('cuLaunchGrid', &__cuLaunchGrid, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuLaunchGridAsync
            _F_cuGetProcAddress_v2('cuLaunchGridAsync', &__cuLaunchGridAsync, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuParamSetTexRef
            _F_cuGetProcAddress_v2('cuParamSetTexRef', &__cuParamSetTexRef, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuFuncSetSharedMemConfig
            _F_cuGetProcAddress_v2('cuFuncSetSharedMemConfig', &__cuFuncSetSharedMemConfig, 4020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphCreate
            _F_cuGetProcAddress_v2('cuGraphCreate', &__cuGraphCreate, 10000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphAddKernelNode_v2
            _F_cuGetProcAddress_v2('cuGraphAddKernelNode', &__cuGraphAddKernelNode_v2, 12000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphKernelNodeGetParams_v2
            _F_cuGetProcAddress_v2('cuGraphKernelNodeGetParams', &__cuGraphKernelNodeGetParams_v2, 12000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphKernelNodeSetParams_v2
            _F_cuGetProcAddress_v2('cuGraphKernelNodeSetParams', &__cuGraphKernelNodeSetParams_v2, 12000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphAddMemcpyNode
            _F_cuGetProcAddress_v2('cuGraphAddMemcpyNode', &__cuGraphAddMemcpyNode, 10000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphMemcpyNodeGetParams
            _F_cuGetProcAddress_v2('cuGraphMemcpyNodeGetParams', &__cuGraphMemcpyNodeGetParams, 10000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphMemcpyNodeSetParams
            _F_cuGetProcAddress_v2('cuGraphMemcpyNodeSetParams', &__cuGraphMemcpyNodeSetParams, 10000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphAddMemsetNode
            _F_cuGetProcAddress_v2('cuGraphAddMemsetNode', &__cuGraphAddMemsetNode, 10000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphMemsetNodeGetParams
            _F_cuGetProcAddress_v2('cuGraphMemsetNodeGetParams', &__cuGraphMemsetNodeGetParams, 10000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphMemsetNodeSetParams
            _F_cuGetProcAddress_v2('cuGraphMemsetNodeSetParams', &__cuGraphMemsetNodeSetParams, 10000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphAddHostNode
            _F_cuGetProcAddress_v2('cuGraphAddHostNode', &__cuGraphAddHostNode, 10000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphHostNodeGetParams
            _F_cuGetProcAddress_v2('cuGraphHostNodeGetParams', &__cuGraphHostNodeGetParams, 10000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphHostNodeSetParams
            _F_cuGetProcAddress_v2('cuGraphHostNodeSetParams', &__cuGraphHostNodeSetParams, 10000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphAddChildGraphNode
            _F_cuGetProcAddress_v2('cuGraphAddChildGraphNode', &__cuGraphAddChildGraphNode, 10000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphChildGraphNodeGetGraph
            _F_cuGetProcAddress_v2('cuGraphChildGraphNodeGetGraph', &__cuGraphChildGraphNodeGetGraph, 10000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphAddEmptyNode
            _F_cuGetProcAddress_v2('cuGraphAddEmptyNode', &__cuGraphAddEmptyNode, 10000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphAddEventRecordNode
            _F_cuGetProcAddress_v2('cuGraphAddEventRecordNode', &__cuGraphAddEventRecordNode, 11010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphEventRecordNodeGetEvent
            _F_cuGetProcAddress_v2('cuGraphEventRecordNodeGetEvent', &__cuGraphEventRecordNodeGetEvent, 11010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphEventRecordNodeSetEvent
            _F_cuGetProcAddress_v2('cuGraphEventRecordNodeSetEvent', &__cuGraphEventRecordNodeSetEvent, 11010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphAddEventWaitNode
            _F_cuGetProcAddress_v2('cuGraphAddEventWaitNode', &__cuGraphAddEventWaitNode, 11010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphEventWaitNodeGetEvent
            _F_cuGetProcAddress_v2('cuGraphEventWaitNodeGetEvent', &__cuGraphEventWaitNodeGetEvent, 11010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphEventWaitNodeSetEvent
            _F_cuGetProcAddress_v2('cuGraphEventWaitNodeSetEvent', &__cuGraphEventWaitNodeSetEvent, 11010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphAddExternalSemaphoresSignalNode
            _F_cuGetProcAddress_v2('cuGraphAddExternalSemaphoresSignalNode', &__cuGraphAddExternalSemaphoresSignalNode, 11020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphExternalSemaphoresSignalNodeGetParams
            _F_cuGetProcAddress_v2('cuGraphExternalSemaphoresSignalNodeGetParams', &__cuGraphExternalSemaphoresSignalNodeGetParams, 11020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphExternalSemaphoresSignalNodeSetParams
            _F_cuGetProcAddress_v2('cuGraphExternalSemaphoresSignalNodeSetParams', &__cuGraphExternalSemaphoresSignalNodeSetParams, 11020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphAddExternalSemaphoresWaitNode
            _F_cuGetProcAddress_v2('cuGraphAddExternalSemaphoresWaitNode', &__cuGraphAddExternalSemaphoresWaitNode, 11020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphExternalSemaphoresWaitNodeGetParams
            _F_cuGetProcAddress_v2('cuGraphExternalSemaphoresWaitNodeGetParams', &__cuGraphExternalSemaphoresWaitNodeGetParams, 11020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphExternalSemaphoresWaitNodeSetParams
            _F_cuGetProcAddress_v2('cuGraphExternalSemaphoresWaitNodeSetParams', &__cuGraphExternalSemaphoresWaitNodeSetParams, 11020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphAddBatchMemOpNode
            _F_cuGetProcAddress_v2('cuGraphAddBatchMemOpNode', &__cuGraphAddBatchMemOpNode, 11070, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphBatchMemOpNodeGetParams
            _F_cuGetProcAddress_v2('cuGraphBatchMemOpNodeGetParams', &__cuGraphBatchMemOpNodeGetParams, 11070, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphBatchMemOpNodeSetParams
            _F_cuGetProcAddress_v2('cuGraphBatchMemOpNodeSetParams', &__cuGraphBatchMemOpNodeSetParams, 11070, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphExecBatchMemOpNodeSetParams
            _F_cuGetProcAddress_v2('cuGraphExecBatchMemOpNodeSetParams', &__cuGraphExecBatchMemOpNodeSetParams, 11070, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphAddMemAllocNode
            _F_cuGetProcAddress_v2('cuGraphAddMemAllocNode', &__cuGraphAddMemAllocNode, 11040, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphMemAllocNodeGetParams
            _F_cuGetProcAddress_v2('cuGraphMemAllocNodeGetParams', &__cuGraphMemAllocNodeGetParams, 11040, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphAddMemFreeNode
            _F_cuGetProcAddress_v2('cuGraphAddMemFreeNode', &__cuGraphAddMemFreeNode, 11040, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphMemFreeNodeGetParams
            _F_cuGetProcAddress_v2('cuGraphMemFreeNodeGetParams', &__cuGraphMemFreeNodeGetParams, 11040, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuDeviceGraphMemTrim
            _F_cuGetProcAddress_v2('cuDeviceGraphMemTrim', &__cuDeviceGraphMemTrim, 11040, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuDeviceGetGraphMemAttribute
            _F_cuGetProcAddress_v2('cuDeviceGetGraphMemAttribute', &__cuDeviceGetGraphMemAttribute, 11040, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuDeviceSetGraphMemAttribute
            _F_cuGetProcAddress_v2('cuDeviceSetGraphMemAttribute', &__cuDeviceSetGraphMemAttribute, 11040, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphClone
            _F_cuGetProcAddress_v2('cuGraphClone', &__cuGraphClone, 10000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphNodeFindInClone
            _F_cuGetProcAddress_v2('cuGraphNodeFindInClone', &__cuGraphNodeFindInClone, 10000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphNodeGetType
            _F_cuGetProcAddress_v2('cuGraphNodeGetType', &__cuGraphNodeGetType, 10000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphGetNodes
            _F_cuGetProcAddress_v2('cuGraphGetNodes', &__cuGraphGetNodes, 10000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphGetRootNodes
            _F_cuGetProcAddress_v2('cuGraphGetRootNodes', &__cuGraphGetRootNodes, 10000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphGetEdges
            _F_cuGetProcAddress_v2('cuGraphGetEdges', &__cuGraphGetEdges, 10000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphGetEdges_v2
            _F_cuGetProcAddress_v2('cuGraphGetEdges', &__cuGraphGetEdges_v2, 12030, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphNodeGetDependencies
            _F_cuGetProcAddress_v2('cuGraphNodeGetDependencies', &__cuGraphNodeGetDependencies, 10000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphNodeGetDependencies_v2
            _F_cuGetProcAddress_v2('cuGraphNodeGetDependencies', &__cuGraphNodeGetDependencies_v2, 12030, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphNodeGetDependentNodes
            _F_cuGetProcAddress_v2('cuGraphNodeGetDependentNodes', &__cuGraphNodeGetDependentNodes, 10000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphNodeGetDependentNodes_v2
            _F_cuGetProcAddress_v2('cuGraphNodeGetDependentNodes', &__cuGraphNodeGetDependentNodes_v2, 12030, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphAddDependencies
            _F_cuGetProcAddress_v2('cuGraphAddDependencies', &__cuGraphAddDependencies, 10000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphAddDependencies_v2
            _F_cuGetProcAddress_v2('cuGraphAddDependencies', &__cuGraphAddDependencies_v2, 12030, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphRemoveDependencies
            _F_cuGetProcAddress_v2('cuGraphRemoveDependencies', &__cuGraphRemoveDependencies, 10000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphRemoveDependencies_v2
            _F_cuGetProcAddress_v2('cuGraphRemoveDependencies', &__cuGraphRemoveDependencies_v2, 12030, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphDestroyNode
            _F_cuGetProcAddress_v2('cuGraphDestroyNode', &__cuGraphDestroyNode, 10000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphInstantiateWithFlags
            _F_cuGetProcAddress_v2('cuGraphInstantiateWithFlags', &__cuGraphInstantiateWithFlags, 11040, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphExecGetFlags
            _F_cuGetProcAddress_v2('cuGraphExecGetFlags', &__cuGraphExecGetFlags, 12000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphExecKernelNodeSetParams_v2
            _F_cuGetProcAddress_v2('cuGraphExecKernelNodeSetParams', &__cuGraphExecKernelNodeSetParams_v2, 12000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphExecMemcpyNodeSetParams
            _F_cuGetProcAddress_v2('cuGraphExecMemcpyNodeSetParams', &__cuGraphExecMemcpyNodeSetParams, 10020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphExecMemsetNodeSetParams
            _F_cuGetProcAddress_v2('cuGraphExecMemsetNodeSetParams', &__cuGraphExecMemsetNodeSetParams, 10020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphExecHostNodeSetParams
            _F_cuGetProcAddress_v2('cuGraphExecHostNodeSetParams', &__cuGraphExecHostNodeSetParams, 10020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphExecChildGraphNodeSetParams
            _F_cuGetProcAddress_v2('cuGraphExecChildGraphNodeSetParams', &__cuGraphExecChildGraphNodeSetParams, 11010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphExecEventRecordNodeSetEvent
            _F_cuGetProcAddress_v2('cuGraphExecEventRecordNodeSetEvent', &__cuGraphExecEventRecordNodeSetEvent, 11010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphExecEventWaitNodeSetEvent
            _F_cuGetProcAddress_v2('cuGraphExecEventWaitNodeSetEvent', &__cuGraphExecEventWaitNodeSetEvent, 11010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphExecExternalSemaphoresSignalNodeSetParams
            _F_cuGetProcAddress_v2('cuGraphExecExternalSemaphoresSignalNodeSetParams', &__cuGraphExecExternalSemaphoresSignalNodeSetParams, 11020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphExecExternalSemaphoresWaitNodeSetParams
            _F_cuGetProcAddress_v2('cuGraphExecExternalSemaphoresWaitNodeSetParams', &__cuGraphExecExternalSemaphoresWaitNodeSetParams, 11020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphNodeSetEnabled
            _F_cuGetProcAddress_v2('cuGraphNodeSetEnabled', &__cuGraphNodeSetEnabled, 11060, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphNodeGetEnabled
            _F_cuGetProcAddress_v2('cuGraphNodeGetEnabled', &__cuGraphNodeGetEnabled, 11060, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphExecDestroy
            _F_cuGetProcAddress_v2('cuGraphExecDestroy', &__cuGraphExecDestroy, 10000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphDestroy
            _F_cuGetProcAddress_v2('cuGraphDestroy', &__cuGraphDestroy, 10000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphExecUpdate_v2
            _F_cuGetProcAddress_v2('cuGraphExecUpdate', &__cuGraphExecUpdate_v2, 12000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphKernelNodeCopyAttributes
            _F_cuGetProcAddress_v2('cuGraphKernelNodeCopyAttributes', &__cuGraphKernelNodeCopyAttributes, 11000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphKernelNodeGetAttribute
            _F_cuGetProcAddress_v2('cuGraphKernelNodeGetAttribute', &__cuGraphKernelNodeGetAttribute, 11000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphKernelNodeSetAttribute
            _F_cuGetProcAddress_v2('cuGraphKernelNodeSetAttribute', &__cuGraphKernelNodeSetAttribute, 11000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphDebugDotPrint
            _F_cuGetProcAddress_v2('cuGraphDebugDotPrint', &__cuGraphDebugDotPrint, 11030, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuUserObjectCreate
            _F_cuGetProcAddress_v2('cuUserObjectCreate', &__cuUserObjectCreate, 11030, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuUserObjectRetain
            _F_cuGetProcAddress_v2('cuUserObjectRetain', &__cuUserObjectRetain, 11030, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuUserObjectRelease
            _F_cuGetProcAddress_v2('cuUserObjectRelease', &__cuUserObjectRelease, 11030, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphRetainUserObject
            _F_cuGetProcAddress_v2('cuGraphRetainUserObject', &__cuGraphRetainUserObject, 11030, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphReleaseUserObject
            _F_cuGetProcAddress_v2('cuGraphReleaseUserObject', &__cuGraphReleaseUserObject, 11030, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphAddNode
            _F_cuGetProcAddress_v2('cuGraphAddNode', &__cuGraphAddNode, 12020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphAddNode_v2
            _F_cuGetProcAddress_v2('cuGraphAddNode', &__cuGraphAddNode_v2, 12030, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphNodeSetParams
            _F_cuGetProcAddress_v2('cuGraphNodeSetParams', &__cuGraphNodeSetParams, 12020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphExecNodeSetParams
            _F_cuGetProcAddress_v2('cuGraphExecNodeSetParams', &__cuGraphExecNodeSetParams, 12020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphConditionalHandleCreate
            _F_cuGetProcAddress_v2('cuGraphConditionalHandleCreate', &__cuGraphConditionalHandleCreate, 12030, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuOccupancyMaxActiveBlocksPerMultiprocessor
            _F_cuGetProcAddress_v2('cuOccupancyMaxActiveBlocksPerMultiprocessor', &__cuOccupancyMaxActiveBlocksPerMultiprocessor, 6050, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuOccupancyMaxActiveBlocksPerMultiprocessorWithFlags
            _F_cuGetProcAddress_v2('cuOccupancyMaxActiveBlocksPerMultiprocessorWithFlags', &__cuOccupancyMaxActiveBlocksPerMultiprocessorWithFlags, 7000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuOccupancyMaxPotentialBlockSize
            _F_cuGetProcAddress_v2('cuOccupancyMaxPotentialBlockSize', &__cuOccupancyMaxPotentialBlockSize, 6050, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuOccupancyMaxPotentialBlockSizeWithFlags
            _F_cuGetProcAddress_v2('cuOccupancyMaxPotentialBlockSizeWithFlags', &__cuOccupancyMaxPotentialBlockSizeWithFlags, 7000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuOccupancyAvailableDynamicSMemPerBlock
            _F_cuGetProcAddress_v2('cuOccupancyAvailableDynamicSMemPerBlock', &__cuOccupancyAvailableDynamicSMemPerBlock, 10020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuOccupancyMaxPotentialClusterSize
            _F_cuGetProcAddress_v2('cuOccupancyMaxPotentialClusterSize', &__cuOccupancyMaxPotentialClusterSize, 11070, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuOccupancyMaxActiveClusters
            _F_cuGetProcAddress_v2('cuOccupancyMaxActiveClusters', &__cuOccupancyMaxActiveClusters, 11070, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuTexRefSetArray
            _F_cuGetProcAddress_v2('cuTexRefSetArray', &__cuTexRefSetArray, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuTexRefSetMipmappedArray
            _F_cuGetProcAddress_v2('cuTexRefSetMipmappedArray', &__cuTexRefSetMipmappedArray, 5000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuTexRefSetAddress_v2
            _F_cuGetProcAddress_v2('cuTexRefSetAddress', &__cuTexRefSetAddress_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuTexRefSetAddress2D_v3
            _F_cuGetProcAddress_v2('cuTexRefSetAddress2D', &__cuTexRefSetAddress2D_v3, 4010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuTexRefSetFormat
            _F_cuGetProcAddress_v2('cuTexRefSetFormat', &__cuTexRefSetFormat, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuTexRefSetAddressMode
            _F_cuGetProcAddress_v2('cuTexRefSetAddressMode', &__cuTexRefSetAddressMode, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuTexRefSetFilterMode
            _F_cuGetProcAddress_v2('cuTexRefSetFilterMode', &__cuTexRefSetFilterMode, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuTexRefSetMipmapFilterMode
            _F_cuGetProcAddress_v2('cuTexRefSetMipmapFilterMode', &__cuTexRefSetMipmapFilterMode, 5000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuTexRefSetMipmapLevelBias
            _F_cuGetProcAddress_v2('cuTexRefSetMipmapLevelBias', &__cuTexRefSetMipmapLevelBias, 5000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuTexRefSetMipmapLevelClamp
            _F_cuGetProcAddress_v2('cuTexRefSetMipmapLevelClamp', &__cuTexRefSetMipmapLevelClamp, 5000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuTexRefSetMaxAnisotropy
            _F_cuGetProcAddress_v2('cuTexRefSetMaxAnisotropy', &__cuTexRefSetMaxAnisotropy, 5000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuTexRefSetBorderColor
            _F_cuGetProcAddress_v2('cuTexRefSetBorderColor', &__cuTexRefSetBorderColor, 8000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuTexRefSetFlags
            _F_cuGetProcAddress_v2('cuTexRefSetFlags', &__cuTexRefSetFlags, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuTexRefGetAddress_v2
            _F_cuGetProcAddress_v2('cuTexRefGetAddress', &__cuTexRefGetAddress_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuTexRefGetArray
            _F_cuGetProcAddress_v2('cuTexRefGetArray', &__cuTexRefGetArray, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuTexRefGetMipmappedArray
            _F_cuGetProcAddress_v2('cuTexRefGetMipmappedArray', &__cuTexRefGetMipmappedArray, 5000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuTexRefGetAddressMode
            _F_cuGetProcAddress_v2('cuTexRefGetAddressMode', &__cuTexRefGetAddressMode, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuTexRefGetFilterMode
            _F_cuGetProcAddress_v2('cuTexRefGetFilterMode', &__cuTexRefGetFilterMode, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuTexRefGetFormat
            _F_cuGetProcAddress_v2('cuTexRefGetFormat', &__cuTexRefGetFormat, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuTexRefGetMipmapFilterMode
            _F_cuGetProcAddress_v2('cuTexRefGetMipmapFilterMode', &__cuTexRefGetMipmapFilterMode, 5000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuTexRefGetMipmapLevelBias
            _F_cuGetProcAddress_v2('cuTexRefGetMipmapLevelBias', &__cuTexRefGetMipmapLevelBias, 5000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuTexRefGetMipmapLevelClamp
            _F_cuGetProcAddress_v2('cuTexRefGetMipmapLevelClamp', &__cuTexRefGetMipmapLevelClamp, 5000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuTexRefGetMaxAnisotropy
            _F_cuGetProcAddress_v2('cuTexRefGetMaxAnisotropy', &__cuTexRefGetMaxAnisotropy, 5000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuTexRefGetBorderColor
            _F_cuGetProcAddress_v2('cuTexRefGetBorderColor', &__cuTexRefGetBorderColor, 8000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuTexRefGetFlags
            _F_cuGetProcAddress_v2('cuTexRefGetFlags', &__cuTexRefGetFlags, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuTexRefCreate
            _F_cuGetProcAddress_v2('cuTexRefCreate', &__cuTexRefCreate, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuTexRefDestroy
            _F_cuGetProcAddress_v2('cuTexRefDestroy', &__cuTexRefDestroy, 2000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuSurfRefSetArray
            _F_cuGetProcAddress_v2('cuSurfRefSetArray', &__cuSurfRefSetArray, 3000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuSurfRefGetArray
            _F_cuGetProcAddress_v2('cuSurfRefGetArray', &__cuSurfRefGetArray, 3000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuTexObjectCreate
            _F_cuGetProcAddress_v2('cuTexObjectCreate', &__cuTexObjectCreate, 5000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuTexObjectDestroy
            _F_cuGetProcAddress_v2('cuTexObjectDestroy', &__cuTexObjectDestroy, 5000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuTexObjectGetResourceDesc
            _F_cuGetProcAddress_v2('cuTexObjectGetResourceDesc', &__cuTexObjectGetResourceDesc, 5000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuTexObjectGetTextureDesc
            _F_cuGetProcAddress_v2('cuTexObjectGetTextureDesc', &__cuTexObjectGetTextureDesc, 5000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuTexObjectGetResourceViewDesc
            _F_cuGetProcAddress_v2('cuTexObjectGetResourceViewDesc', &__cuTexObjectGetResourceViewDesc, 5000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuSurfObjectCreate
            _F_cuGetProcAddress_v2('cuSurfObjectCreate', &__cuSurfObjectCreate, 5000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuSurfObjectDestroy
            _F_cuGetProcAddress_v2('cuSurfObjectDestroy', &__cuSurfObjectDestroy, 5000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuSurfObjectGetResourceDesc
            _F_cuGetProcAddress_v2('cuSurfObjectGetResourceDesc', &__cuSurfObjectGetResourceDesc, 5000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuTensorMapEncodeTiled
            _F_cuGetProcAddress_v2('cuTensorMapEncodeTiled', &__cuTensorMapEncodeTiled, 12000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuTensorMapEncodeIm2col
            _F_cuGetProcAddress_v2('cuTensorMapEncodeIm2col', &__cuTensorMapEncodeIm2col, 12000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuTensorMapEncodeIm2colWide
            _F_cuGetProcAddress_v2('cuTensorMapEncodeIm2colWide', &__cuTensorMapEncodeIm2colWide, 12080, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuTensorMapReplaceAddress
            _F_cuGetProcAddress_v2('cuTensorMapReplaceAddress', &__cuTensorMapReplaceAddress, 12000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuDeviceCanAccessPeer
            _F_cuGetProcAddress_v2('cuDeviceCanAccessPeer', &__cuDeviceCanAccessPeer, 4000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCtxEnablePeerAccess
            _F_cuGetProcAddress_v2('cuCtxEnablePeerAccess', &__cuCtxEnablePeerAccess, 4000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCtxDisablePeerAccess
            _F_cuGetProcAddress_v2('cuCtxDisablePeerAccess', &__cuCtxDisablePeerAccess, 4000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuDeviceGetP2PAttribute
            _F_cuGetProcAddress_v2('cuDeviceGetP2PAttribute', &__cuDeviceGetP2PAttribute, 8000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphicsUnregisterResource
            _F_cuGetProcAddress_v2('cuGraphicsUnregisterResource', &__cuGraphicsUnregisterResource, 3000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphicsSubResourceGetMappedArray
            _F_cuGetProcAddress_v2('cuGraphicsSubResourceGetMappedArray', &__cuGraphicsSubResourceGetMappedArray, 3000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphicsResourceGetMappedMipmappedArray
            _F_cuGetProcAddress_v2('cuGraphicsResourceGetMappedMipmappedArray', &__cuGraphicsResourceGetMappedMipmappedArray, 5000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphicsResourceGetMappedPointer_v2
            _F_cuGetProcAddress_v2('cuGraphicsResourceGetMappedPointer', &__cuGraphicsResourceGetMappedPointer_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphicsResourceSetMapFlags_v2
            _F_cuGetProcAddress_v2('cuGraphicsResourceSetMapFlags', &__cuGraphicsResourceSetMapFlags_v2, 6050, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGetProcAddress_v2
            _F_cuGetProcAddress_v2('cuGetProcAddress', &__cuGetProcAddress_v2, 12000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCoredumpGetAttribute
            _F_cuGetProcAddress_v2('cuCoredumpGetAttribute', &__cuCoredumpGetAttribute, 12010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCoredumpGetAttributeGlobal
            _F_cuGetProcAddress_v2('cuCoredumpGetAttributeGlobal', &__cuCoredumpGetAttributeGlobal, 12010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCoredumpSetAttribute
            _F_cuGetProcAddress_v2('cuCoredumpSetAttribute', &__cuCoredumpSetAttribute, 12010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCoredumpSetAttributeGlobal
            _F_cuGetProcAddress_v2('cuCoredumpSetAttributeGlobal', &__cuCoredumpSetAttributeGlobal, 12010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGetExportTable
            _F_cuGetProcAddress_v2('cuGetExportTable', &__cuGetExportTable, 3000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGreenCtxCreate
            _F_cuGetProcAddress_v2('cuGreenCtxCreate', &__cuGreenCtxCreate, 12040, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGreenCtxDestroy
            _F_cuGetProcAddress_v2('cuGreenCtxDestroy', &__cuGreenCtxDestroy, 12040, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCtxFromGreenCtx
            _F_cuGetProcAddress_v2('cuCtxFromGreenCtx', &__cuCtxFromGreenCtx, 12040, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuDeviceGetDevResource
            _F_cuGetProcAddress_v2('cuDeviceGetDevResource', &__cuDeviceGetDevResource, 12040, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCtxGetDevResource
            _F_cuGetProcAddress_v2('cuCtxGetDevResource', &__cuCtxGetDevResource, 12040, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGreenCtxGetDevResource
            _F_cuGetProcAddress_v2('cuGreenCtxGetDevResource', &__cuGreenCtxGetDevResource, 12040, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuDevSmResourceSplitByCount
            _F_cuGetProcAddress_v2('cuDevSmResourceSplitByCount', &__cuDevSmResourceSplitByCount, 12040, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuDevResourceGenerateDesc
            _F_cuGetProcAddress_v2('cuDevResourceGenerateDesc', &__cuDevResourceGenerateDesc, 12040, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGreenCtxRecordEvent
            _F_cuGetProcAddress_v2('cuGreenCtxRecordEvent', &__cuGreenCtxRecordEvent, 12040, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGreenCtxWaitEvent
            _F_cuGetProcAddress_v2('cuGreenCtxWaitEvent', &__cuGreenCtxWaitEvent, 12040, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuStreamGetGreenCtx
            _F_cuGetProcAddress_v2('cuStreamGetGreenCtx', &__cuStreamGetGreenCtx, 12040, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGreenCtxStreamCreate
            _F_cuGetProcAddress_v2('cuGreenCtxStreamCreate', &__cuGreenCtxStreamCreate, 12050, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuLogsRegisterCallback
            _F_cuGetProcAddress_v2('cuLogsRegisterCallback', &__cuLogsRegisterCallback, 12080, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuLogsUnregisterCallback
            _F_cuGetProcAddress_v2('cuLogsUnregisterCallback', &__cuLogsUnregisterCallback, 12080, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuLogsCurrent
            _F_cuGetProcAddress_v2('cuLogsCurrent', &__cuLogsCurrent, 12080, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuLogsDumpToFile
            _F_cuGetProcAddress_v2('cuLogsDumpToFile', &__cuLogsDumpToFile, 12080, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuLogsDumpToMemory
            _F_cuGetProcAddress_v2('cuLogsDumpToMemory', &__cuLogsDumpToMemory, 12080, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCheckpointProcessGetRestoreThreadId
            _F_cuGetProcAddress_v2('cuCheckpointProcessGetRestoreThreadId', &__cuCheckpointProcessGetRestoreThreadId, 12080, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCheckpointProcessGetState
            _F_cuGetProcAddress_v2('cuCheckpointProcessGetState', &__cuCheckpointProcessGetState, 12080, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCheckpointProcessLock
            _F_cuGetProcAddress_v2('cuCheckpointProcessLock', &__cuCheckpointProcessLock, 12080, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCheckpointProcessCheckpoint
            _F_cuGetProcAddress_v2('cuCheckpointProcessCheckpoint', &__cuCheckpointProcessCheckpoint, 12080, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCheckpointProcessRestore
            _F_cuGetProcAddress_v2('cuCheckpointProcessRestore', &__cuCheckpointProcessRestore, 12080, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuCheckpointProcessUnlock
            _F_cuGetProcAddress_v2('cuCheckpointProcessUnlock', &__cuCheckpointProcessUnlock, 12080, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuProfilerStart
            _F_cuGetProcAddress_v2('cuProfilerStart', &__cuProfilerStart, 4000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuProfilerStop
            _F_cuGetProcAddress_v2('cuProfilerStop', &__cuProfilerStop, 4000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphicsEGLRegisterImage
            _F_cuGetProcAddress_v2('cuGraphicsEGLRegisterImage', &__cuGraphicsEGLRegisterImage, 7000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuEGLStreamConsumerConnect
            _F_cuGetProcAddress_v2('cuEGLStreamConsumerConnect', &__cuEGLStreamConsumerConnect, 7000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuEGLStreamConsumerConnectWithFlags
            _F_cuGetProcAddress_v2('cuEGLStreamConsumerConnectWithFlags', &__cuEGLStreamConsumerConnectWithFlags, 8000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuEGLStreamConsumerDisconnect
            _F_cuGetProcAddress_v2('cuEGLStreamConsumerDisconnect', &__cuEGLStreamConsumerDisconnect, 7000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuEGLStreamConsumerAcquireFrame
            _F_cuGetProcAddress_v2('cuEGLStreamConsumerAcquireFrame', &__cuEGLStreamConsumerAcquireFrame, 7000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuEGLStreamConsumerReleaseFrame
            _F_cuGetProcAddress_v2('cuEGLStreamConsumerReleaseFrame', &__cuEGLStreamConsumerReleaseFrame, 7000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuEGLStreamProducerConnect
            _F_cuGetProcAddress_v2('cuEGLStreamProducerConnect', &__cuEGLStreamProducerConnect, 7000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuEGLStreamProducerDisconnect
            _F_cuGetProcAddress_v2('cuEGLStreamProducerDisconnect', &__cuEGLStreamProducerDisconnect, 7000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuEGLStreamProducerPresentFrame
            _F_cuGetProcAddress_v2('cuEGLStreamProducerPresentFrame', &__cuEGLStreamProducerPresentFrame, 7000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuEGLStreamProducerReturnFrame
            _F_cuGetProcAddress_v2('cuEGLStreamProducerReturnFrame', &__cuEGLStreamProducerReturnFrame, 7000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphicsResourceGetMappedEglFrame
            _F_cuGetProcAddress_v2('cuGraphicsResourceGetMappedEglFrame', &__cuGraphicsResourceGetMappedEglFrame, 7000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuEventCreateFromEGLSync
            _F_cuGetProcAddress_v2('cuEventCreateFromEGLSync', &__cuEventCreateFromEGLSync, 9000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphicsGLRegisterBuffer
            _F_cuGetProcAddress_v2('cuGraphicsGLRegisterBuffer', &__cuGraphicsGLRegisterBuffer, 3000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphicsGLRegisterImage
            _F_cuGetProcAddress_v2('cuGraphicsGLRegisterImage', &__cuGraphicsGLRegisterImage, 3000, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGLGetDevices_v2
            _F_cuGetProcAddress_v2('cuGLGetDevices', &__cuGLGetDevices_v2, 6050, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuVDPAUGetDevice
            _F_cuGetProcAddress_v2('cuVDPAUGetDevice', &__cuVDPAUGetDevice, 3010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuVDPAUCtxCreate_v2
            _F_cuGetProcAddress_v2('cuVDPAUCtxCreate', &__cuVDPAUCtxCreate_v2, 3020, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphicsVDPAURegisterVideoSurface
            _F_cuGetProcAddress_v2('cuGraphicsVDPAURegisterVideoSurface', &__cuGraphicsVDPAURegisterVideoSurface, 3010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            global __cuGraphicsVDPAURegisterOutputSurface
            _F_cuGetProcAddress_v2('cuGraphicsVDPAURegisterOutputSurface', &__cuGraphicsVDPAURegisterOutputSurface, 3010, CU_GET_PROC_ADDRESS_DEFAULT, NULL)
            __cuPythonInit = True
            return 0

        # Load using dlsym
        if usePTDS:
            # Get all PTDS version of functions
            pass
            global __cuMemcpy
            __cuMemcpy = dlfcn.dlsym(handle, 'cuMemcpy_ptds')
            global __cuMemcpyPeer
            __cuMemcpyPeer = dlfcn.dlsym(handle, 'cuMemcpyPeer_ptds')
            global __cuMemcpyHtoD_v2
            __cuMemcpyHtoD_v2 = dlfcn.dlsym(handle, 'cuMemcpyHtoD_v2_ptds')
            global __cuMemcpyDtoH_v2
            __cuMemcpyDtoH_v2 = dlfcn.dlsym(handle, 'cuMemcpyDtoH_v2_ptds')
            global __cuMemcpyDtoD_v2
            __cuMemcpyDtoD_v2 = dlfcn.dlsym(handle, 'cuMemcpyDtoD_v2_ptds')
            global __cuMemcpyDtoA_v2
            __cuMemcpyDtoA_v2 = dlfcn.dlsym(handle, 'cuMemcpyDtoA_v2_ptds')
            global __cuMemcpyAtoD_v2
            __cuMemcpyAtoD_v2 = dlfcn.dlsym(handle, 'cuMemcpyAtoD_v2_ptds')
            global __cuMemcpyHtoA_v2
            __cuMemcpyHtoA_v2 = dlfcn.dlsym(handle, 'cuMemcpyHtoA_v2_ptds')
            global __cuMemcpyAtoH_v2
            __cuMemcpyAtoH_v2 = dlfcn.dlsym(handle, 'cuMemcpyAtoH_v2_ptds')
            global __cuMemcpyAtoA_v2
            __cuMemcpyAtoA_v2 = dlfcn.dlsym(handle, 'cuMemcpyAtoA_v2_ptds')
            global __cuMemcpy2D_v2
            __cuMemcpy2D_v2 = dlfcn.dlsym(handle, 'cuMemcpy2D_v2_ptds')
            global __cuMemcpy2DUnaligned_v2
            __cuMemcpy2DUnaligned_v2 = dlfcn.dlsym(handle, 'cuMemcpy2DUnaligned_v2_ptds')
            global __cuMemcpy3D_v2
            __cuMemcpy3D_v2 = dlfcn.dlsym(handle, 'cuMemcpy3D_v2_ptds')
            global __cuMemcpy3DPeer
            __cuMemcpy3DPeer = dlfcn.dlsym(handle, 'cuMemcpy3DPeer_ptds')
            global __cuMemcpyAsync
            __cuMemcpyAsync = dlfcn.dlsym(handle, 'cuMemcpyAsync_ptsz')
            global __cuMemcpyPeerAsync
            __cuMemcpyPeerAsync = dlfcn.dlsym(handle, 'cuMemcpyPeerAsync_ptsz')
            global __cuMemcpyHtoDAsync_v2
            __cuMemcpyHtoDAsync_v2 = dlfcn.dlsym(handle, 'cuMemcpyHtoDAsync_v2_ptsz')
            global __cuMemcpyDtoHAsync_v2
            __cuMemcpyDtoHAsync_v2 = dlfcn.dlsym(handle, 'cuMemcpyDtoHAsync_v2_ptsz')
            global __cuMemcpyDtoDAsync_v2
            __cuMemcpyDtoDAsync_v2 = dlfcn.dlsym(handle, 'cuMemcpyDtoDAsync_v2_ptsz')
            global __cuMemcpyHtoAAsync_v2
            __cuMemcpyHtoAAsync_v2 = dlfcn.dlsym(handle, 'cuMemcpyHtoAAsync_v2_ptsz')
            global __cuMemcpyAtoHAsync_v2
            __cuMemcpyAtoHAsync_v2 = dlfcn.dlsym(handle, 'cuMemcpyAtoHAsync_v2_ptsz')
            global __cuMemcpy2DAsync_v2
            __cuMemcpy2DAsync_v2 = dlfcn.dlsym(handle, 'cuMemcpy2DAsync_v2_ptsz')
            global __cuMemcpy3DAsync_v2
            __cuMemcpy3DAsync_v2 = dlfcn.dlsym(handle, 'cuMemcpy3DAsync_v2_ptsz')
            global __cuMemcpy3DPeerAsync
            __cuMemcpy3DPeerAsync = dlfcn.dlsym(handle, 'cuMemcpy3DPeerAsync_ptsz')
            global __cuMemcpyBatchAsync
            __cuMemcpyBatchAsync = dlfcn.dlsym(handle, 'cuMemcpyBatchAsync_ptsz')
            global __cuMemcpy3DBatchAsync
            __cuMemcpy3DBatchAsync = dlfcn.dlsym(handle, 'cuMemcpy3DBatchAsync_ptsz')
            global __cuMemsetD8_v2
            __cuMemsetD8_v2 = dlfcn.dlsym(handle, 'cuMemsetD8_v2_ptds')
            global __cuMemsetD16_v2
            __cuMemsetD16_v2 = dlfcn.dlsym(handle, 'cuMemsetD16_v2_ptds')
            global __cuMemsetD32_v2
            __cuMemsetD32_v2 = dlfcn.dlsym(handle, 'cuMemsetD32_v2_ptds')
            global __cuMemsetD2D8_v2
            __cuMemsetD2D8_v2 = dlfcn.dlsym(handle, 'cuMemsetD2D8_v2_ptds')
            global __cuMemsetD2D16_v2
            __cuMemsetD2D16_v2 = dlfcn.dlsym(handle, 'cuMemsetD2D16_v2_ptds')
            global __cuMemsetD2D32_v2
            __cuMemsetD2D32_v2 = dlfcn.dlsym(handle, 'cuMemsetD2D32_v2_ptds')
            global __cuMemsetD8Async
            __cuMemsetD8Async = dlfcn.dlsym(handle, 'cuMemsetD8Async_ptsz')
            global __cuMemsetD16Async
            __cuMemsetD16Async = dlfcn.dlsym(handle, 'cuMemsetD16Async_ptsz')
            global __cuMemsetD32Async
            __cuMemsetD32Async = dlfcn.dlsym(handle, 'cuMemsetD32Async_ptsz')
            global __cuMemsetD2D8Async
            __cuMemsetD2D8Async = dlfcn.dlsym(handle, 'cuMemsetD2D8Async_ptsz')
            global __cuMemsetD2D16Async
            __cuMemsetD2D16Async = dlfcn.dlsym(handle, 'cuMemsetD2D16Async_ptsz')
            global __cuMemsetD2D32Async
            __cuMemsetD2D32Async = dlfcn.dlsym(handle, 'cuMemsetD2D32Async_ptsz')
            global __cuMemBatchDecompressAsync
            __cuMemBatchDecompressAsync = dlfcn.dlsym(handle, 'cuMemBatchDecompressAsync_ptsz')
            global __cuMemMapArrayAsync
            __cuMemMapArrayAsync = dlfcn.dlsym(handle, 'cuMemMapArrayAsync_ptsz')
            global __cuMemFreeAsync
            __cuMemFreeAsync = dlfcn.dlsym(handle, 'cuMemFreeAsync_ptsz')
            global __cuMemAllocAsync
            __cuMemAllocAsync = dlfcn.dlsym(handle, 'cuMemAllocAsync_ptsz')
            global __cuMemAllocFromPoolAsync
            __cuMemAllocFromPoolAsync = dlfcn.dlsym(handle, 'cuMemAllocFromPoolAsync_ptsz')
            global __cuMemPrefetchAsync
            __cuMemPrefetchAsync = dlfcn.dlsym(handle, 'cuMemPrefetchAsync_ptsz')
            global __cuMemPrefetchAsync_v2
            __cuMemPrefetchAsync_v2 = dlfcn.dlsym(handle, 'cuMemPrefetchAsync_v2_ptsz')
            global __cuStreamGetPriority
            __cuStreamGetPriority = dlfcn.dlsym(handle, 'cuStreamGetPriority_ptsz')
            global __cuStreamGetDevice
            __cuStreamGetDevice = dlfcn.dlsym(handle, 'cuStreamGetDevice_ptsz')
            global __cuStreamGetFlags
            __cuStreamGetFlags = dlfcn.dlsym(handle, 'cuStreamGetFlags_ptsz')
            global __cuStreamGetId
            __cuStreamGetId = dlfcn.dlsym(handle, 'cuStreamGetId_ptsz')
            global __cuStreamGetCtx
            __cuStreamGetCtx = dlfcn.dlsym(handle, 'cuStreamGetCtx_ptsz')
            global __cuStreamGetCtx_v2
            __cuStreamGetCtx_v2 = dlfcn.dlsym(handle, 'cuStreamGetCtx_v2_ptsz')
            global __cuStreamWaitEvent
            __cuStreamWaitEvent = dlfcn.dlsym(handle, 'cuStreamWaitEvent_ptsz')
            global __cuStreamAddCallback
            __cuStreamAddCallback = dlfcn.dlsym(handle, 'cuStreamAddCallback_ptsz')
            global __cuStreamBeginCapture_v2
            __cuStreamBeginCapture_v2 = dlfcn.dlsym(handle, 'cuStreamBeginCapture_v2_ptsz')
            global __cuStreamBeginCaptureToGraph
            __cuStreamBeginCaptureToGraph = dlfcn.dlsym(handle, 'cuStreamBeginCaptureToGraph_ptsz')
            global __cuStreamEndCapture
            __cuStreamEndCapture = dlfcn.dlsym(handle, 'cuStreamEndCapture_ptsz')
            global __cuStreamIsCapturing
            __cuStreamIsCapturing = dlfcn.dlsym(handle, 'cuStreamIsCapturing_ptsz')
            global __cuStreamGetCaptureInfo_v2
            __cuStreamGetCaptureInfo_v2 = dlfcn.dlsym(handle, 'cuStreamGetCaptureInfo_v2_ptsz')
            global __cuStreamGetCaptureInfo_v3
            __cuStreamGetCaptureInfo_v3 = dlfcn.dlsym(handle, 'cuStreamGetCaptureInfo_v3_ptsz')
            global __cuStreamUpdateCaptureDependencies
            __cuStreamUpdateCaptureDependencies = dlfcn.dlsym(handle, 'cuStreamUpdateCaptureDependencies_ptsz')
            global __cuStreamUpdateCaptureDependencies_v2
            __cuStreamUpdateCaptureDependencies_v2 = dlfcn.dlsym(handle, 'cuStreamUpdateCaptureDependencies_v2_ptsz')
            global __cuStreamAttachMemAsync
            __cuStreamAttachMemAsync = dlfcn.dlsym(handle, 'cuStreamAttachMemAsync_ptsz')
            global __cuStreamQuery
            __cuStreamQuery = dlfcn.dlsym(handle, 'cuStreamQuery_ptsz')
            global __cuStreamSynchronize
            __cuStreamSynchronize = dlfcn.dlsym(handle, 'cuStreamSynchronize_ptsz')
            global __cuStreamCopyAttributes
            __cuStreamCopyAttributes = dlfcn.dlsym(handle, 'cuStreamCopyAttributes_ptsz')
            global __cuStreamGetAttribute
            __cuStreamGetAttribute = dlfcn.dlsym(handle, 'cuStreamGetAttribute_ptsz')
            global __cuStreamSetAttribute
            __cuStreamSetAttribute = dlfcn.dlsym(handle, 'cuStreamSetAttribute_ptsz')
            global __cuEventRecord
            __cuEventRecord = dlfcn.dlsym(handle, 'cuEventRecord_ptsz')
            global __cuEventRecordWithFlags
            __cuEventRecordWithFlags = dlfcn.dlsym(handle, 'cuEventRecordWithFlags_ptsz')
            global __cuSignalExternalSemaphoresAsync
            __cuSignalExternalSemaphoresAsync = dlfcn.dlsym(handle, 'cuSignalExternalSemaphoresAsync_ptsz')
            global __cuWaitExternalSemaphoresAsync
            __cuWaitExternalSemaphoresAsync = dlfcn.dlsym(handle, 'cuWaitExternalSemaphoresAsync_ptsz')
            global __cuStreamWaitValue32_v2
            __cuStreamWaitValue32_v2 = dlfcn.dlsym(handle, 'cuStreamWaitValue32_v2_ptsz')
            global __cuStreamWaitValue64_v2
            __cuStreamWaitValue64_v2 = dlfcn.dlsym(handle, 'cuStreamWaitValue64_v2_ptsz')
            global __cuStreamWriteValue32_v2
            __cuStreamWriteValue32_v2 = dlfcn.dlsym(handle, 'cuStreamWriteValue32_v2_ptsz')
            global __cuStreamWriteValue64_v2
            __cuStreamWriteValue64_v2 = dlfcn.dlsym(handle, 'cuStreamWriteValue64_v2_ptsz')
            global __cuStreamBatchMemOp_v2
            __cuStreamBatchMemOp_v2 = dlfcn.dlsym(handle, 'cuStreamBatchMemOp_v2_ptsz')
            global __cuLaunchKernel
            __cuLaunchKernel = dlfcn.dlsym(handle, 'cuLaunchKernel_ptsz')
            global __cuLaunchKernelEx
            __cuLaunchKernelEx = dlfcn.dlsym(handle, 'cuLaunchKernelEx_ptsz')
            global __cuLaunchCooperativeKernel
            __cuLaunchCooperativeKernel = dlfcn.dlsym(handle, 'cuLaunchCooperativeKernel_ptsz')
            global __cuLaunchHostFunc
            __cuLaunchHostFunc = dlfcn.dlsym(handle, 'cuLaunchHostFunc_ptsz')
            global __cuGraphInstantiateWithParams
            __cuGraphInstantiateWithParams = dlfcn.dlsym(handle, 'cuGraphInstantiateWithParams_ptsz')
            global __cuGraphUpload
            __cuGraphUpload = dlfcn.dlsym(handle, 'cuGraphUpload_ptsz')
            global __cuGraphLaunch
            __cuGraphLaunch = dlfcn.dlsym(handle, 'cuGraphLaunch_ptsz')
            global __cuGraphicsMapResources
            __cuGraphicsMapResources = dlfcn.dlsym(handle, 'cuGraphicsMapResources_ptsz')
            global __cuGraphicsUnmapResources
            __cuGraphicsUnmapResources = dlfcn.dlsym(handle, 'cuGraphicsUnmapResources_ptsz')
        else:
            # Else get the regular version
            pass
            global __cuMemcpy
            __cuMemcpy = dlfcn.dlsym(handle, 'cuMemcpy')
            global __cuMemcpyPeer
            __cuMemcpyPeer = dlfcn.dlsym(handle, 'cuMemcpyPeer')
            global __cuMemcpyHtoD_v2
            __cuMemcpyHtoD_v2 = dlfcn.dlsym(handle, 'cuMemcpyHtoD_v2')
            global __cuMemcpyDtoH_v2
            __cuMemcpyDtoH_v2 = dlfcn.dlsym(handle, 'cuMemcpyDtoH_v2')
            global __cuMemcpyDtoD_v2
            __cuMemcpyDtoD_v2 = dlfcn.dlsym(handle, 'cuMemcpyDtoD_v2')
            global __cuMemcpyDtoA_v2
            __cuMemcpyDtoA_v2 = dlfcn.dlsym(handle, 'cuMemcpyDtoA_v2')
            global __cuMemcpyAtoD_v2
            __cuMemcpyAtoD_v2 = dlfcn.dlsym(handle, 'cuMemcpyAtoD_v2')
            global __cuMemcpyHtoA_v2
            __cuMemcpyHtoA_v2 = dlfcn.dlsym(handle, 'cuMemcpyHtoA_v2')
            global __cuMemcpyAtoH_v2
            __cuMemcpyAtoH_v2 = dlfcn.dlsym(handle, 'cuMemcpyAtoH_v2')
            global __cuMemcpyAtoA_v2
            __cuMemcpyAtoA_v2 = dlfcn.dlsym(handle, 'cuMemcpyAtoA_v2')
            global __cuMemcpy2D_v2
            __cuMemcpy2D_v2 = dlfcn.dlsym(handle, 'cuMemcpy2D_v2')
            global __cuMemcpy2DUnaligned_v2
            __cuMemcpy2DUnaligned_v2 = dlfcn.dlsym(handle, 'cuMemcpy2DUnaligned_v2')
            global __cuMemcpy3D_v2
            __cuMemcpy3D_v2 = dlfcn.dlsym(handle, 'cuMemcpy3D_v2')
            global __cuMemcpy3DPeer
            __cuMemcpy3DPeer = dlfcn.dlsym(handle, 'cuMemcpy3DPeer')
            global __cuMemcpyAsync
            __cuMemcpyAsync = dlfcn.dlsym(handle, 'cuMemcpyAsync')
            global __cuMemcpyPeerAsync
            __cuMemcpyPeerAsync = dlfcn.dlsym(handle, 'cuMemcpyPeerAsync')
            global __cuMemcpyHtoDAsync_v2
            __cuMemcpyHtoDAsync_v2 = dlfcn.dlsym(handle, 'cuMemcpyHtoDAsync_v2')
            global __cuMemcpyDtoHAsync_v2
            __cuMemcpyDtoHAsync_v2 = dlfcn.dlsym(handle, 'cuMemcpyDtoHAsync_v2')
            global __cuMemcpyDtoDAsync_v2
            __cuMemcpyDtoDAsync_v2 = dlfcn.dlsym(handle, 'cuMemcpyDtoDAsync_v2')
            global __cuMemcpyHtoAAsync_v2
            __cuMemcpyHtoAAsync_v2 = dlfcn.dlsym(handle, 'cuMemcpyHtoAAsync_v2')
            global __cuMemcpyAtoHAsync_v2
            __cuMemcpyAtoHAsync_v2 = dlfcn.dlsym(handle, 'cuMemcpyAtoHAsync_v2')
            global __cuMemcpy2DAsync_v2
            __cuMemcpy2DAsync_v2 = dlfcn.dlsym(handle, 'cuMemcpy2DAsync_v2')
            global __cuMemcpy3DAsync_v2
            __cuMemcpy3DAsync_v2 = dlfcn.dlsym(handle, 'cuMemcpy3DAsync_v2')
            global __cuMemcpy3DPeerAsync
            __cuMemcpy3DPeerAsync = dlfcn.dlsym(handle, 'cuMemcpy3DPeerAsync')
            global __cuMemcpyBatchAsync
            __cuMemcpyBatchAsync = dlfcn.dlsym(handle, 'cuMemcpyBatchAsync')
            global __cuMemcpy3DBatchAsync
            __cuMemcpy3DBatchAsync = dlfcn.dlsym(handle, 'cuMemcpy3DBatchAsync')
            global __cuMemsetD8_v2
            __cuMemsetD8_v2 = dlfcn.dlsym(handle, 'cuMemsetD8_v2')
            global __cuMemsetD16_v2
            __cuMemsetD16_v2 = dlfcn.dlsym(handle, 'cuMemsetD16_v2')
            global __cuMemsetD32_v2
            __cuMemsetD32_v2 = dlfcn.dlsym(handle, 'cuMemsetD32_v2')
            global __cuMemsetD2D8_v2
            __cuMemsetD2D8_v2 = dlfcn.dlsym(handle, 'cuMemsetD2D8_v2')
            global __cuMemsetD2D16_v2
            __cuMemsetD2D16_v2 = dlfcn.dlsym(handle, 'cuMemsetD2D16_v2')
            global __cuMemsetD2D32_v2
            __cuMemsetD2D32_v2 = dlfcn.dlsym(handle, 'cuMemsetD2D32_v2')
            global __cuMemsetD8Async
            __cuMemsetD8Async = dlfcn.dlsym(handle, 'cuMemsetD8Async')
            global __cuMemsetD16Async
            __cuMemsetD16Async = dlfcn.dlsym(handle, 'cuMemsetD16Async')
            global __cuMemsetD32Async
            __cuMemsetD32Async = dlfcn.dlsym(handle, 'cuMemsetD32Async')
            global __cuMemsetD2D8Async
            __cuMemsetD2D8Async = dlfcn.dlsym(handle, 'cuMemsetD2D8Async')
            global __cuMemsetD2D16Async
            __cuMemsetD2D16Async = dlfcn.dlsym(handle, 'cuMemsetD2D16Async')
            global __cuMemsetD2D32Async
            __cuMemsetD2D32Async = dlfcn.dlsym(handle, 'cuMemsetD2D32Async')
            global __cuMemBatchDecompressAsync
            __cuMemBatchDecompressAsync = dlfcn.dlsym(handle, 'cuMemBatchDecompressAsync')
            global __cuMemMapArrayAsync
            __cuMemMapArrayAsync = dlfcn.dlsym(handle, 'cuMemMapArrayAsync')
            global __cuMemFreeAsync
            __cuMemFreeAsync = dlfcn.dlsym(handle, 'cuMemFreeAsync')
            global __cuMemAllocAsync
            __cuMemAllocAsync = dlfcn.dlsym(handle, 'cuMemAllocAsync')
            global __cuMemAllocFromPoolAsync
            __cuMemAllocFromPoolAsync = dlfcn.dlsym(handle, 'cuMemAllocFromPoolAsync')
            global __cuMemPrefetchAsync
            __cuMemPrefetchAsync = dlfcn.dlsym(handle, 'cuMemPrefetchAsync')
            global __cuMemPrefetchAsync_v2
            __cuMemPrefetchAsync_v2 = dlfcn.dlsym(handle, 'cuMemPrefetchAsync_v2')
            global __cuStreamGetPriority
            __cuStreamGetPriority = dlfcn.dlsym(handle, 'cuStreamGetPriority')
            global __cuStreamGetDevice
            __cuStreamGetDevice = dlfcn.dlsym(handle, 'cuStreamGetDevice')
            global __cuStreamGetFlags
            __cuStreamGetFlags = dlfcn.dlsym(handle, 'cuStreamGetFlags')
            global __cuStreamGetId
            __cuStreamGetId = dlfcn.dlsym(handle, 'cuStreamGetId')
            global __cuStreamGetCtx
            __cuStreamGetCtx = dlfcn.dlsym(handle, 'cuStreamGetCtx')
            global __cuStreamGetCtx_v2
            __cuStreamGetCtx_v2 = dlfcn.dlsym(handle, 'cuStreamGetCtx_v2')
            global __cuStreamWaitEvent
            __cuStreamWaitEvent = dlfcn.dlsym(handle, 'cuStreamWaitEvent')
            global __cuStreamAddCallback
            __cuStreamAddCallback = dlfcn.dlsym(handle, 'cuStreamAddCallback')
            global __cuStreamBeginCapture_v2
            __cuStreamBeginCapture_v2 = dlfcn.dlsym(handle, 'cuStreamBeginCapture_v2')
            global __cuStreamBeginCaptureToGraph
            __cuStreamBeginCaptureToGraph = dlfcn.dlsym(handle, 'cuStreamBeginCaptureToGraph')
            global __cuStreamEndCapture
            __cuStreamEndCapture = dlfcn.dlsym(handle, 'cuStreamEndCapture')
            global __cuStreamIsCapturing
            __cuStreamIsCapturing = dlfcn.dlsym(handle, 'cuStreamIsCapturing')
            global __cuStreamGetCaptureInfo_v2
            __cuStreamGetCaptureInfo_v2 = dlfcn.dlsym(handle, 'cuStreamGetCaptureInfo_v2')
            global __cuStreamGetCaptureInfo_v3
            __cuStreamGetCaptureInfo_v3 = dlfcn.dlsym(handle, 'cuStreamGetCaptureInfo_v3')
            global __cuStreamUpdateCaptureDependencies
            __cuStreamUpdateCaptureDependencies = dlfcn.dlsym(handle, 'cuStreamUpdateCaptureDependencies')
            global __cuStreamUpdateCaptureDependencies_v2
            __cuStreamUpdateCaptureDependencies_v2 = dlfcn.dlsym(handle, 'cuStreamUpdateCaptureDependencies_v2')
            global __cuStreamAttachMemAsync
            __cuStreamAttachMemAsync = dlfcn.dlsym(handle, 'cuStreamAttachMemAsync')
            global __cuStreamQuery
            __cuStreamQuery = dlfcn.dlsym(handle, 'cuStreamQuery')
            global __cuStreamSynchronize
            __cuStreamSynchronize = dlfcn.dlsym(handle, 'cuStreamSynchronize')
            global __cuStreamCopyAttributes
            __cuStreamCopyAttributes = dlfcn.dlsym(handle, 'cuStreamCopyAttributes')
            global __cuStreamGetAttribute
            __cuStreamGetAttribute = dlfcn.dlsym(handle, 'cuStreamGetAttribute')
            global __cuStreamSetAttribute
            __cuStreamSetAttribute = dlfcn.dlsym(handle, 'cuStreamSetAttribute')
            global __cuEventRecord
            __cuEventRecord = dlfcn.dlsym(handle, 'cuEventRecord')
            global __cuEventRecordWithFlags
            __cuEventRecordWithFlags = dlfcn.dlsym(handle, 'cuEventRecordWithFlags')
            global __cuSignalExternalSemaphoresAsync
            __cuSignalExternalSemaphoresAsync = dlfcn.dlsym(handle, 'cuSignalExternalSemaphoresAsync')
            global __cuWaitExternalSemaphoresAsync
            __cuWaitExternalSemaphoresAsync = dlfcn.dlsym(handle, 'cuWaitExternalSemaphoresAsync')
            global __cuStreamWaitValue32_v2
            __cuStreamWaitValue32_v2 = dlfcn.dlsym(handle, 'cuStreamWaitValue32_v2')
            global __cuStreamWaitValue64_v2
            __cuStreamWaitValue64_v2 = dlfcn.dlsym(handle, 'cuStreamWaitValue64_v2')
            global __cuStreamWriteValue32_v2
            __cuStreamWriteValue32_v2 = dlfcn.dlsym(handle, 'cuStreamWriteValue32_v2')
            global __cuStreamWriteValue64_v2
            __cuStreamWriteValue64_v2 = dlfcn.dlsym(handle, 'cuStreamWriteValue64_v2')
            global __cuStreamBatchMemOp_v2
            __cuStreamBatchMemOp_v2 = dlfcn.dlsym(handle, 'cuStreamBatchMemOp_v2')
            global __cuLaunchKernel
            __cuLaunchKernel = dlfcn.dlsym(handle, 'cuLaunchKernel')
            global __cuLaunchKernelEx
            __cuLaunchKernelEx = dlfcn.dlsym(handle, 'cuLaunchKernelEx')
            global __cuLaunchCooperativeKernel
            __cuLaunchCooperativeKernel = dlfcn.dlsym(handle, 'cuLaunchCooperativeKernel')
            global __cuLaunchHostFunc
            __cuLaunchHostFunc = dlfcn.dlsym(handle, 'cuLaunchHostFunc')
            global __cuGraphInstantiateWithParams
            __cuGraphInstantiateWithParams = dlfcn.dlsym(handle, 'cuGraphInstantiateWithParams')
            global __cuGraphUpload
            __cuGraphUpload = dlfcn.dlsym(handle, 'cuGraphUpload')
            global __cuGraphLaunch
            __cuGraphLaunch = dlfcn.dlsym(handle, 'cuGraphLaunch')
            global __cuGraphicsMapResources
            __cuGraphicsMapResources = dlfcn.dlsym(handle, 'cuGraphicsMapResources')
            global __cuGraphicsUnmapResources
            __cuGraphicsUnmapResources = dlfcn.dlsym(handle, 'cuGraphicsUnmapResources')
        # Get remaining functions
        global __cuGetErrorString
        __cuGetErrorString = dlfcn.dlsym(handle, 'cuGetErrorString')
        global __cuGetErrorName
        __cuGetErrorName = dlfcn.dlsym(handle, 'cuGetErrorName')
        global __cuInit
        __cuInit = dlfcn.dlsym(handle, 'cuInit')
        global __cuDriverGetVersion
        __cuDriverGetVersion = dlfcn.dlsym(handle, 'cuDriverGetVersion')
        global __cuDeviceGet
        __cuDeviceGet = dlfcn.dlsym(handle, 'cuDeviceGet')
        global __cuDeviceGetCount
        __cuDeviceGetCount = dlfcn.dlsym(handle, 'cuDeviceGetCount')
        global __cuDeviceGetName
        __cuDeviceGetName = dlfcn.dlsym(handle, 'cuDeviceGetName')
        global __cuDeviceGetUuid
        __cuDeviceGetUuid = dlfcn.dlsym(handle, 'cuDeviceGetUuid')
        global __cuDeviceGetUuid_v2
        __cuDeviceGetUuid_v2 = dlfcn.dlsym(handle, 'cuDeviceGetUuid_v2')
        global __cuDeviceGetLuid
        __cuDeviceGetLuid = dlfcn.dlsym(handle, 'cuDeviceGetLuid')
        global __cuDeviceTotalMem_v2
        __cuDeviceTotalMem_v2 = dlfcn.dlsym(handle, 'cuDeviceTotalMem_v2')
        global __cuDeviceGetTexture1DLinearMaxWidth
        __cuDeviceGetTexture1DLinearMaxWidth = dlfcn.dlsym(handle, 'cuDeviceGetTexture1DLinearMaxWidth')
        global __cuDeviceGetAttribute
        __cuDeviceGetAttribute = dlfcn.dlsym(handle, 'cuDeviceGetAttribute')
        global __cuDeviceGetNvSciSyncAttributes
        __cuDeviceGetNvSciSyncAttributes = dlfcn.dlsym(handle, 'cuDeviceGetNvSciSyncAttributes')
        global __cuDeviceSetMemPool
        __cuDeviceSetMemPool = dlfcn.dlsym(handle, 'cuDeviceSetMemPool')
        global __cuDeviceGetMemPool
        __cuDeviceGetMemPool = dlfcn.dlsym(handle, 'cuDeviceGetMemPool')
        global __cuDeviceGetDefaultMemPool
        __cuDeviceGetDefaultMemPool = dlfcn.dlsym(handle, 'cuDeviceGetDefaultMemPool')
        global __cuDeviceGetExecAffinitySupport
        __cuDeviceGetExecAffinitySupport = dlfcn.dlsym(handle, 'cuDeviceGetExecAffinitySupport')
        global __cuFlushGPUDirectRDMAWrites
        __cuFlushGPUDirectRDMAWrites = dlfcn.dlsym(handle, 'cuFlushGPUDirectRDMAWrites')
        global __cuDeviceGetProperties
        __cuDeviceGetProperties = dlfcn.dlsym(handle, 'cuDeviceGetProperties')
        global __cuDeviceComputeCapability
        __cuDeviceComputeCapability = dlfcn.dlsym(handle, 'cuDeviceComputeCapability')
        global __cuDevicePrimaryCtxRetain
        __cuDevicePrimaryCtxRetain = dlfcn.dlsym(handle, 'cuDevicePrimaryCtxRetain')
        global __cuDevicePrimaryCtxRelease_v2
        __cuDevicePrimaryCtxRelease_v2 = dlfcn.dlsym(handle, 'cuDevicePrimaryCtxRelease_v2')
        global __cuDevicePrimaryCtxSetFlags_v2
        __cuDevicePrimaryCtxSetFlags_v2 = dlfcn.dlsym(handle, 'cuDevicePrimaryCtxSetFlags_v2')
        global __cuDevicePrimaryCtxGetState
        __cuDevicePrimaryCtxGetState = dlfcn.dlsym(handle, 'cuDevicePrimaryCtxGetState')
        global __cuDevicePrimaryCtxReset_v2
        __cuDevicePrimaryCtxReset_v2 = dlfcn.dlsym(handle, 'cuDevicePrimaryCtxReset_v2')
        global __cuCtxCreate_v2
        __cuCtxCreate_v2 = dlfcn.dlsym(handle, 'cuCtxCreate_v2')
        global __cuCtxCreate_v3
        __cuCtxCreate_v3 = dlfcn.dlsym(handle, 'cuCtxCreate_v3')
        global __cuCtxCreate_v4
        __cuCtxCreate_v4 = dlfcn.dlsym(handle, 'cuCtxCreate_v4')
        global __cuCtxDestroy_v2
        __cuCtxDestroy_v2 = dlfcn.dlsym(handle, 'cuCtxDestroy_v2')
        global __cuCtxPushCurrent_v2
        __cuCtxPushCurrent_v2 = dlfcn.dlsym(handle, 'cuCtxPushCurrent_v2')
        global __cuCtxPopCurrent_v2
        __cuCtxPopCurrent_v2 = dlfcn.dlsym(handle, 'cuCtxPopCurrent_v2')
        global __cuCtxSetCurrent
        __cuCtxSetCurrent = dlfcn.dlsym(handle, 'cuCtxSetCurrent')
        global __cuCtxGetCurrent
        __cuCtxGetCurrent = dlfcn.dlsym(handle, 'cuCtxGetCurrent')
        global __cuCtxGetDevice
        __cuCtxGetDevice = dlfcn.dlsym(handle, 'cuCtxGetDevice')
        global __cuCtxGetFlags
        __cuCtxGetFlags = dlfcn.dlsym(handle, 'cuCtxGetFlags')
        global __cuCtxSetFlags
        __cuCtxSetFlags = dlfcn.dlsym(handle, 'cuCtxSetFlags')
        global __cuCtxGetId
        __cuCtxGetId = dlfcn.dlsym(handle, 'cuCtxGetId')
        global __cuCtxSynchronize
        __cuCtxSynchronize = dlfcn.dlsym(handle, 'cuCtxSynchronize')
        global __cuCtxSetLimit
        __cuCtxSetLimit = dlfcn.dlsym(handle, 'cuCtxSetLimit')
        global __cuCtxGetLimit
        __cuCtxGetLimit = dlfcn.dlsym(handle, 'cuCtxGetLimit')
        global __cuCtxGetCacheConfig
        __cuCtxGetCacheConfig = dlfcn.dlsym(handle, 'cuCtxGetCacheConfig')
        global __cuCtxSetCacheConfig
        __cuCtxSetCacheConfig = dlfcn.dlsym(handle, 'cuCtxSetCacheConfig')
        global __cuCtxGetApiVersion
        __cuCtxGetApiVersion = dlfcn.dlsym(handle, 'cuCtxGetApiVersion')
        global __cuCtxGetStreamPriorityRange
        __cuCtxGetStreamPriorityRange = dlfcn.dlsym(handle, 'cuCtxGetStreamPriorityRange')
        global __cuCtxResetPersistingL2Cache
        __cuCtxResetPersistingL2Cache = dlfcn.dlsym(handle, 'cuCtxResetPersistingL2Cache')
        global __cuCtxGetExecAffinity
        __cuCtxGetExecAffinity = dlfcn.dlsym(handle, 'cuCtxGetExecAffinity')
        global __cuCtxRecordEvent
        __cuCtxRecordEvent = dlfcn.dlsym(handle, 'cuCtxRecordEvent')
        global __cuCtxWaitEvent
        __cuCtxWaitEvent = dlfcn.dlsym(handle, 'cuCtxWaitEvent')
        global __cuCtxAttach
        __cuCtxAttach = dlfcn.dlsym(handle, 'cuCtxAttach')
        global __cuCtxDetach
        __cuCtxDetach = dlfcn.dlsym(handle, 'cuCtxDetach')
        global __cuCtxGetSharedMemConfig
        __cuCtxGetSharedMemConfig = dlfcn.dlsym(handle, 'cuCtxGetSharedMemConfig')
        global __cuCtxSetSharedMemConfig
        __cuCtxSetSharedMemConfig = dlfcn.dlsym(handle, 'cuCtxSetSharedMemConfig')
        global __cuModuleLoad
        __cuModuleLoad = dlfcn.dlsym(handle, 'cuModuleLoad')
        global __cuModuleLoadData
        __cuModuleLoadData = dlfcn.dlsym(handle, 'cuModuleLoadData')
        global __cuModuleLoadDataEx
        __cuModuleLoadDataEx = dlfcn.dlsym(handle, 'cuModuleLoadDataEx')
        global __cuModuleLoadFatBinary
        __cuModuleLoadFatBinary = dlfcn.dlsym(handle, 'cuModuleLoadFatBinary')
        global __cuModuleUnload
        __cuModuleUnload = dlfcn.dlsym(handle, 'cuModuleUnload')
        global __cuModuleGetLoadingMode
        __cuModuleGetLoadingMode = dlfcn.dlsym(handle, 'cuModuleGetLoadingMode')
        global __cuModuleGetFunction
        __cuModuleGetFunction = dlfcn.dlsym(handle, 'cuModuleGetFunction')
        global __cuModuleGetFunctionCount
        __cuModuleGetFunctionCount = dlfcn.dlsym(handle, 'cuModuleGetFunctionCount')
        global __cuModuleEnumerateFunctions
        __cuModuleEnumerateFunctions = dlfcn.dlsym(handle, 'cuModuleEnumerateFunctions')
        global __cuModuleGetGlobal_v2
        __cuModuleGetGlobal_v2 = dlfcn.dlsym(handle, 'cuModuleGetGlobal_v2')
        global __cuLinkCreate_v2
        __cuLinkCreate_v2 = dlfcn.dlsym(handle, 'cuLinkCreate_v2')
        global __cuLinkAddData_v2
        __cuLinkAddData_v2 = dlfcn.dlsym(handle, 'cuLinkAddData_v2')
        global __cuLinkAddFile_v2
        __cuLinkAddFile_v2 = dlfcn.dlsym(handle, 'cuLinkAddFile_v2')
        global __cuLinkComplete
        __cuLinkComplete = dlfcn.dlsym(handle, 'cuLinkComplete')
        global __cuLinkDestroy
        __cuLinkDestroy = dlfcn.dlsym(handle, 'cuLinkDestroy')
        global __cuModuleGetTexRef
        __cuModuleGetTexRef = dlfcn.dlsym(handle, 'cuModuleGetTexRef')
        global __cuModuleGetSurfRef
        __cuModuleGetSurfRef = dlfcn.dlsym(handle, 'cuModuleGetSurfRef')
        global __cuLibraryLoadData
        __cuLibraryLoadData = dlfcn.dlsym(handle, 'cuLibraryLoadData')
        global __cuLibraryLoadFromFile
        __cuLibraryLoadFromFile = dlfcn.dlsym(handle, 'cuLibraryLoadFromFile')
        global __cuLibraryUnload
        __cuLibraryUnload = dlfcn.dlsym(handle, 'cuLibraryUnload')
        global __cuLibraryGetKernel
        __cuLibraryGetKernel = dlfcn.dlsym(handle, 'cuLibraryGetKernel')
        global __cuLibraryGetKernelCount
        __cuLibraryGetKernelCount = dlfcn.dlsym(handle, 'cuLibraryGetKernelCount')
        global __cuLibraryEnumerateKernels
        __cuLibraryEnumerateKernels = dlfcn.dlsym(handle, 'cuLibraryEnumerateKernels')
        global __cuLibraryGetModule
        __cuLibraryGetModule = dlfcn.dlsym(handle, 'cuLibraryGetModule')
        global __cuKernelGetFunction
        __cuKernelGetFunction = dlfcn.dlsym(handle, 'cuKernelGetFunction')
        global __cuKernelGetLibrary
        __cuKernelGetLibrary = dlfcn.dlsym(handle, 'cuKernelGetLibrary')
        global __cuLibraryGetGlobal
        __cuLibraryGetGlobal = dlfcn.dlsym(handle, 'cuLibraryGetGlobal')
        global __cuLibraryGetManaged
        __cuLibraryGetManaged = dlfcn.dlsym(handle, 'cuLibraryGetManaged')
        global __cuLibraryGetUnifiedFunction
        __cuLibraryGetUnifiedFunction = dlfcn.dlsym(handle, 'cuLibraryGetUnifiedFunction')
        global __cuKernelGetAttribute
        __cuKernelGetAttribute = dlfcn.dlsym(handle, 'cuKernelGetAttribute')
        global __cuKernelSetAttribute
        __cuKernelSetAttribute = dlfcn.dlsym(handle, 'cuKernelSetAttribute')
        global __cuKernelSetCacheConfig
        __cuKernelSetCacheConfig = dlfcn.dlsym(handle, 'cuKernelSetCacheConfig')
        global __cuKernelGetName
        __cuKernelGetName = dlfcn.dlsym(handle, 'cuKernelGetName')
        global __cuKernelGetParamInfo
        __cuKernelGetParamInfo = dlfcn.dlsym(handle, 'cuKernelGetParamInfo')
        global __cuMemGetInfo_v2
        __cuMemGetInfo_v2 = dlfcn.dlsym(handle, 'cuMemGetInfo_v2')
        global __cuMemAlloc_v2
        __cuMemAlloc_v2 = dlfcn.dlsym(handle, 'cuMemAlloc_v2')
        global __cuMemAllocPitch_v2
        __cuMemAllocPitch_v2 = dlfcn.dlsym(handle, 'cuMemAllocPitch_v2')
        global __cuMemFree_v2
        __cuMemFree_v2 = dlfcn.dlsym(handle, 'cuMemFree_v2')
        global __cuMemGetAddressRange_v2
        __cuMemGetAddressRange_v2 = dlfcn.dlsym(handle, 'cuMemGetAddressRange_v2')
        global __cuMemAllocHost_v2
        __cuMemAllocHost_v2 = dlfcn.dlsym(handle, 'cuMemAllocHost_v2')
        global __cuMemFreeHost
        __cuMemFreeHost = dlfcn.dlsym(handle, 'cuMemFreeHost')
        global __cuMemHostAlloc
        __cuMemHostAlloc = dlfcn.dlsym(handle, 'cuMemHostAlloc')
        global __cuMemHostGetDevicePointer_v2
        __cuMemHostGetDevicePointer_v2 = dlfcn.dlsym(handle, 'cuMemHostGetDevicePointer_v2')
        global __cuMemHostGetFlags
        __cuMemHostGetFlags = dlfcn.dlsym(handle, 'cuMemHostGetFlags')
        global __cuMemAllocManaged
        __cuMemAllocManaged = dlfcn.dlsym(handle, 'cuMemAllocManaged')
        global __cuDeviceRegisterAsyncNotification
        __cuDeviceRegisterAsyncNotification = dlfcn.dlsym(handle, 'cuDeviceRegisterAsyncNotification')
        global __cuDeviceUnregisterAsyncNotification
        __cuDeviceUnregisterAsyncNotification = dlfcn.dlsym(handle, 'cuDeviceUnregisterAsyncNotification')
        global __cuDeviceGetByPCIBusId
        __cuDeviceGetByPCIBusId = dlfcn.dlsym(handle, 'cuDeviceGetByPCIBusId')
        global __cuDeviceGetPCIBusId
        __cuDeviceGetPCIBusId = dlfcn.dlsym(handle, 'cuDeviceGetPCIBusId')
        global __cuIpcGetEventHandle
        __cuIpcGetEventHandle = dlfcn.dlsym(handle, 'cuIpcGetEventHandle')
        global __cuIpcOpenEventHandle
        __cuIpcOpenEventHandle = dlfcn.dlsym(handle, 'cuIpcOpenEventHandle')
        global __cuIpcGetMemHandle
        __cuIpcGetMemHandle = dlfcn.dlsym(handle, 'cuIpcGetMemHandle')
        global __cuIpcOpenMemHandle_v2
        __cuIpcOpenMemHandle_v2 = dlfcn.dlsym(handle, 'cuIpcOpenMemHandle_v2')
        global __cuIpcCloseMemHandle
        __cuIpcCloseMemHandle = dlfcn.dlsym(handle, 'cuIpcCloseMemHandle')
        global __cuMemHostRegister_v2
        __cuMemHostRegister_v2 = dlfcn.dlsym(handle, 'cuMemHostRegister_v2')
        global __cuMemHostUnregister
        __cuMemHostUnregister = dlfcn.dlsym(handle, 'cuMemHostUnregister')
        global __cuArrayCreate_v2
        __cuArrayCreate_v2 = dlfcn.dlsym(handle, 'cuArrayCreate_v2')
        global __cuArrayGetDescriptor_v2
        __cuArrayGetDescriptor_v2 = dlfcn.dlsym(handle, 'cuArrayGetDescriptor_v2')
        global __cuArrayGetSparseProperties
        __cuArrayGetSparseProperties = dlfcn.dlsym(handle, 'cuArrayGetSparseProperties')
        global __cuMipmappedArrayGetSparseProperties
        __cuMipmappedArrayGetSparseProperties = dlfcn.dlsym(handle, 'cuMipmappedArrayGetSparseProperties')
        global __cuArrayGetMemoryRequirements
        __cuArrayGetMemoryRequirements = dlfcn.dlsym(handle, 'cuArrayGetMemoryRequirements')
        global __cuMipmappedArrayGetMemoryRequirements
        __cuMipmappedArrayGetMemoryRequirements = dlfcn.dlsym(handle, 'cuMipmappedArrayGetMemoryRequirements')
        global __cuArrayGetPlane
        __cuArrayGetPlane = dlfcn.dlsym(handle, 'cuArrayGetPlane')
        global __cuArrayDestroy
        __cuArrayDestroy = dlfcn.dlsym(handle, 'cuArrayDestroy')
        global __cuArray3DCreate_v2
        __cuArray3DCreate_v2 = dlfcn.dlsym(handle, 'cuArray3DCreate_v2')
        global __cuArray3DGetDescriptor_v2
        __cuArray3DGetDescriptor_v2 = dlfcn.dlsym(handle, 'cuArray3DGetDescriptor_v2')
        global __cuMipmappedArrayCreate
        __cuMipmappedArrayCreate = dlfcn.dlsym(handle, 'cuMipmappedArrayCreate')
        global __cuMipmappedArrayGetLevel
        __cuMipmappedArrayGetLevel = dlfcn.dlsym(handle, 'cuMipmappedArrayGetLevel')
        global __cuMipmappedArrayDestroy
        __cuMipmappedArrayDestroy = dlfcn.dlsym(handle, 'cuMipmappedArrayDestroy')
        global __cuMemGetHandleForAddressRange
        __cuMemGetHandleForAddressRange = dlfcn.dlsym(handle, 'cuMemGetHandleForAddressRange')
        global __cuMemAddressReserve
        __cuMemAddressReserve = dlfcn.dlsym(handle, 'cuMemAddressReserve')
        global __cuMemAddressFree
        __cuMemAddressFree = dlfcn.dlsym(handle, 'cuMemAddressFree')
        global __cuMemCreate
        __cuMemCreate = dlfcn.dlsym(handle, 'cuMemCreate')
        global __cuMemRelease
        __cuMemRelease = dlfcn.dlsym(handle, 'cuMemRelease')
        global __cuMemMap
        __cuMemMap = dlfcn.dlsym(handle, 'cuMemMap')
        global __cuMemUnmap
        __cuMemUnmap = dlfcn.dlsym(handle, 'cuMemUnmap')
        global __cuMemSetAccess
        __cuMemSetAccess = dlfcn.dlsym(handle, 'cuMemSetAccess')
        global __cuMemGetAccess
        __cuMemGetAccess = dlfcn.dlsym(handle, 'cuMemGetAccess')
        global __cuMemExportToShareableHandle
        __cuMemExportToShareableHandle = dlfcn.dlsym(handle, 'cuMemExportToShareableHandle')
        global __cuMemImportFromShareableHandle
        __cuMemImportFromShareableHandle = dlfcn.dlsym(handle, 'cuMemImportFromShareableHandle')
        global __cuMemGetAllocationGranularity
        __cuMemGetAllocationGranularity = dlfcn.dlsym(handle, 'cuMemGetAllocationGranularity')
        global __cuMemGetAllocationPropertiesFromHandle
        __cuMemGetAllocationPropertiesFromHandle = dlfcn.dlsym(handle, 'cuMemGetAllocationPropertiesFromHandle')
        global __cuMemRetainAllocationHandle
        __cuMemRetainAllocationHandle = dlfcn.dlsym(handle, 'cuMemRetainAllocationHandle')
        global __cuMemPoolTrimTo
        __cuMemPoolTrimTo = dlfcn.dlsym(handle, 'cuMemPoolTrimTo')
        global __cuMemPoolSetAttribute
        __cuMemPoolSetAttribute = dlfcn.dlsym(handle, 'cuMemPoolSetAttribute')
        global __cuMemPoolGetAttribute
        __cuMemPoolGetAttribute = dlfcn.dlsym(handle, 'cuMemPoolGetAttribute')
        global __cuMemPoolSetAccess
        __cuMemPoolSetAccess = dlfcn.dlsym(handle, 'cuMemPoolSetAccess')
        global __cuMemPoolGetAccess
        __cuMemPoolGetAccess = dlfcn.dlsym(handle, 'cuMemPoolGetAccess')
        global __cuMemPoolCreate
        __cuMemPoolCreate = dlfcn.dlsym(handle, 'cuMemPoolCreate')
        global __cuMemPoolDestroy
        __cuMemPoolDestroy = dlfcn.dlsym(handle, 'cuMemPoolDestroy')
        global __cuMemPoolExportToShareableHandle
        __cuMemPoolExportToShareableHandle = dlfcn.dlsym(handle, 'cuMemPoolExportToShareableHandle')
        global __cuMemPoolImportFromShareableHandle
        __cuMemPoolImportFromShareableHandle = dlfcn.dlsym(handle, 'cuMemPoolImportFromShareableHandle')
        global __cuMemPoolExportPointer
        __cuMemPoolExportPointer = dlfcn.dlsym(handle, 'cuMemPoolExportPointer')
        global __cuMemPoolImportPointer
        __cuMemPoolImportPointer = dlfcn.dlsym(handle, 'cuMemPoolImportPointer')
        global __cuMulticastCreate
        __cuMulticastCreate = dlfcn.dlsym(handle, 'cuMulticastCreate')
        global __cuMulticastAddDevice
        __cuMulticastAddDevice = dlfcn.dlsym(handle, 'cuMulticastAddDevice')
        global __cuMulticastBindMem
        __cuMulticastBindMem = dlfcn.dlsym(handle, 'cuMulticastBindMem')
        global __cuMulticastBindAddr
        __cuMulticastBindAddr = dlfcn.dlsym(handle, 'cuMulticastBindAddr')
        global __cuMulticastUnbind
        __cuMulticastUnbind = dlfcn.dlsym(handle, 'cuMulticastUnbind')
        global __cuMulticastGetGranularity
        __cuMulticastGetGranularity = dlfcn.dlsym(handle, 'cuMulticastGetGranularity')
        global __cuPointerGetAttribute
        __cuPointerGetAttribute = dlfcn.dlsym(handle, 'cuPointerGetAttribute')
        global __cuMemAdvise
        __cuMemAdvise = dlfcn.dlsym(handle, 'cuMemAdvise')
        global __cuMemAdvise_v2
        __cuMemAdvise_v2 = dlfcn.dlsym(handle, 'cuMemAdvise_v2')
        global __cuMemRangeGetAttribute
        __cuMemRangeGetAttribute = dlfcn.dlsym(handle, 'cuMemRangeGetAttribute')
        global __cuMemRangeGetAttributes
        __cuMemRangeGetAttributes = dlfcn.dlsym(handle, 'cuMemRangeGetAttributes')
        global __cuPointerSetAttribute
        __cuPointerSetAttribute = dlfcn.dlsym(handle, 'cuPointerSetAttribute')
        global __cuPointerGetAttributes
        __cuPointerGetAttributes = dlfcn.dlsym(handle, 'cuPointerGetAttributes')
        global __cuStreamCreate
        __cuStreamCreate = dlfcn.dlsym(handle, 'cuStreamCreate')
        global __cuStreamCreateWithPriority
        __cuStreamCreateWithPriority = dlfcn.dlsym(handle, 'cuStreamCreateWithPriority')
        global __cuThreadExchangeStreamCaptureMode
        __cuThreadExchangeStreamCaptureMode = dlfcn.dlsym(handle, 'cuThreadExchangeStreamCaptureMode')
        global __cuStreamDestroy_v2
        __cuStreamDestroy_v2 = dlfcn.dlsym(handle, 'cuStreamDestroy_v2')
        global __cuEventCreate
        __cuEventCreate = dlfcn.dlsym(handle, 'cuEventCreate')
        global __cuEventQuery
        __cuEventQuery = dlfcn.dlsym(handle, 'cuEventQuery')
        global __cuEventSynchronize
        __cuEventSynchronize = dlfcn.dlsym(handle, 'cuEventSynchronize')
        global __cuEventDestroy_v2
        __cuEventDestroy_v2 = dlfcn.dlsym(handle, 'cuEventDestroy_v2')
        global __cuEventElapsedTime
        __cuEventElapsedTime = dlfcn.dlsym(handle, 'cuEventElapsedTime')
        global __cuEventElapsedTime_v2
        __cuEventElapsedTime_v2 = dlfcn.dlsym(handle, 'cuEventElapsedTime_v2')
        global __cuImportExternalMemory
        __cuImportExternalMemory = dlfcn.dlsym(handle, 'cuImportExternalMemory')
        global __cuExternalMemoryGetMappedBuffer
        __cuExternalMemoryGetMappedBuffer = dlfcn.dlsym(handle, 'cuExternalMemoryGetMappedBuffer')
        global __cuExternalMemoryGetMappedMipmappedArray
        __cuExternalMemoryGetMappedMipmappedArray = dlfcn.dlsym(handle, 'cuExternalMemoryGetMappedMipmappedArray')
        global __cuDestroyExternalMemory
        __cuDestroyExternalMemory = dlfcn.dlsym(handle, 'cuDestroyExternalMemory')
        global __cuImportExternalSemaphore
        __cuImportExternalSemaphore = dlfcn.dlsym(handle, 'cuImportExternalSemaphore')
        global __cuDestroyExternalSemaphore
        __cuDestroyExternalSemaphore = dlfcn.dlsym(handle, 'cuDestroyExternalSemaphore')
        global __cuFuncGetAttribute
        __cuFuncGetAttribute = dlfcn.dlsym(handle, 'cuFuncGetAttribute')
        global __cuFuncSetAttribute
        __cuFuncSetAttribute = dlfcn.dlsym(handle, 'cuFuncSetAttribute')
        global __cuFuncSetCacheConfig
        __cuFuncSetCacheConfig = dlfcn.dlsym(handle, 'cuFuncSetCacheConfig')
        global __cuFuncGetModule
        __cuFuncGetModule = dlfcn.dlsym(handle, 'cuFuncGetModule')
        global __cuFuncGetName
        __cuFuncGetName = dlfcn.dlsym(handle, 'cuFuncGetName')
        global __cuFuncGetParamInfo
        __cuFuncGetParamInfo = dlfcn.dlsym(handle, 'cuFuncGetParamInfo')
        global __cuFuncIsLoaded
        __cuFuncIsLoaded = dlfcn.dlsym(handle, 'cuFuncIsLoaded')
        global __cuFuncLoad
        __cuFuncLoad = dlfcn.dlsym(handle, 'cuFuncLoad')
        global __cuLaunchCooperativeKernelMultiDevice
        __cuLaunchCooperativeKernelMultiDevice = dlfcn.dlsym(handle, 'cuLaunchCooperativeKernelMultiDevice')
        global __cuFuncSetBlockShape
        __cuFuncSetBlockShape = dlfcn.dlsym(handle, 'cuFuncSetBlockShape')
        global __cuFuncSetSharedSize
        __cuFuncSetSharedSize = dlfcn.dlsym(handle, 'cuFuncSetSharedSize')
        global __cuParamSetSize
        __cuParamSetSize = dlfcn.dlsym(handle, 'cuParamSetSize')
        global __cuParamSeti
        __cuParamSeti = dlfcn.dlsym(handle, 'cuParamSeti')
        global __cuParamSetf
        __cuParamSetf = dlfcn.dlsym(handle, 'cuParamSetf')
        global __cuParamSetv
        __cuParamSetv = dlfcn.dlsym(handle, 'cuParamSetv')
        global __cuLaunch
        __cuLaunch = dlfcn.dlsym(handle, 'cuLaunch')
        global __cuLaunchGrid
        __cuLaunchGrid = dlfcn.dlsym(handle, 'cuLaunchGrid')
        global __cuLaunchGridAsync
        __cuLaunchGridAsync = dlfcn.dlsym(handle, 'cuLaunchGridAsync')
        global __cuParamSetTexRef
        __cuParamSetTexRef = dlfcn.dlsym(handle, 'cuParamSetTexRef')
        global __cuFuncSetSharedMemConfig
        __cuFuncSetSharedMemConfig = dlfcn.dlsym(handle, 'cuFuncSetSharedMemConfig')
        global __cuGraphCreate
        __cuGraphCreate = dlfcn.dlsym(handle, 'cuGraphCreate')
        global __cuGraphAddKernelNode_v2
        __cuGraphAddKernelNode_v2 = dlfcn.dlsym(handle, 'cuGraphAddKernelNode_v2')
        global __cuGraphKernelNodeGetParams_v2
        __cuGraphKernelNodeGetParams_v2 = dlfcn.dlsym(handle, 'cuGraphKernelNodeGetParams_v2')
        global __cuGraphKernelNodeSetParams_v2
        __cuGraphKernelNodeSetParams_v2 = dlfcn.dlsym(handle, 'cuGraphKernelNodeSetParams_v2')
        global __cuGraphAddMemcpyNode
        __cuGraphAddMemcpyNode = dlfcn.dlsym(handle, 'cuGraphAddMemcpyNode')
        global __cuGraphMemcpyNodeGetParams
        __cuGraphMemcpyNodeGetParams = dlfcn.dlsym(handle, 'cuGraphMemcpyNodeGetParams')
        global __cuGraphMemcpyNodeSetParams
        __cuGraphMemcpyNodeSetParams = dlfcn.dlsym(handle, 'cuGraphMemcpyNodeSetParams')
        global __cuGraphAddMemsetNode
        __cuGraphAddMemsetNode = dlfcn.dlsym(handle, 'cuGraphAddMemsetNode')
        global __cuGraphMemsetNodeGetParams
        __cuGraphMemsetNodeGetParams = dlfcn.dlsym(handle, 'cuGraphMemsetNodeGetParams')
        global __cuGraphMemsetNodeSetParams
        __cuGraphMemsetNodeSetParams = dlfcn.dlsym(handle, 'cuGraphMemsetNodeSetParams')
        global __cuGraphAddHostNode
        __cuGraphAddHostNode = dlfcn.dlsym(handle, 'cuGraphAddHostNode')
        global __cuGraphHostNodeGetParams
        __cuGraphHostNodeGetParams = dlfcn.dlsym(handle, 'cuGraphHostNodeGetParams')
        global __cuGraphHostNodeSetParams
        __cuGraphHostNodeSetParams = dlfcn.dlsym(handle, 'cuGraphHostNodeSetParams')
        global __cuGraphAddChildGraphNode
        __cuGraphAddChildGraphNode = dlfcn.dlsym(handle, 'cuGraphAddChildGraphNode')
        global __cuGraphChildGraphNodeGetGraph
        __cuGraphChildGraphNodeGetGraph = dlfcn.dlsym(handle, 'cuGraphChildGraphNodeGetGraph')
        global __cuGraphAddEmptyNode
        __cuGraphAddEmptyNode = dlfcn.dlsym(handle, 'cuGraphAddEmptyNode')
        global __cuGraphAddEventRecordNode
        __cuGraphAddEventRecordNode = dlfcn.dlsym(handle, 'cuGraphAddEventRecordNode')
        global __cuGraphEventRecordNodeGetEvent
        __cuGraphEventRecordNodeGetEvent = dlfcn.dlsym(handle, 'cuGraphEventRecordNodeGetEvent')
        global __cuGraphEventRecordNodeSetEvent
        __cuGraphEventRecordNodeSetEvent = dlfcn.dlsym(handle, 'cuGraphEventRecordNodeSetEvent')
        global __cuGraphAddEventWaitNode
        __cuGraphAddEventWaitNode = dlfcn.dlsym(handle, 'cuGraphAddEventWaitNode')
        global __cuGraphEventWaitNodeGetEvent
        __cuGraphEventWaitNodeGetEvent = dlfcn.dlsym(handle, 'cuGraphEventWaitNodeGetEvent')
        global __cuGraphEventWaitNodeSetEvent
        __cuGraphEventWaitNodeSetEvent = dlfcn.dlsym(handle, 'cuGraphEventWaitNodeSetEvent')
        global __cuGraphAddExternalSemaphoresSignalNode
        __cuGraphAddExternalSemaphoresSignalNode = dlfcn.dlsym(handle, 'cuGraphAddExternalSemaphoresSignalNode')
        global __cuGraphExternalSemaphoresSignalNodeGetParams
        __cuGraphExternalSemaphoresSignalNodeGetParams = dlfcn.dlsym(handle, 'cuGraphExternalSemaphoresSignalNodeGetParams')
        global __cuGraphExternalSemaphoresSignalNodeSetParams
        __cuGraphExternalSemaphoresSignalNodeSetParams = dlfcn.dlsym(handle, 'cuGraphExternalSemaphoresSignalNodeSetParams')
        global __cuGraphAddExternalSemaphoresWaitNode
        __cuGraphAddExternalSemaphoresWaitNode = dlfcn.dlsym(handle, 'cuGraphAddExternalSemaphoresWaitNode')
        global __cuGraphExternalSemaphoresWaitNodeGetParams
        __cuGraphExternalSemaphoresWaitNodeGetParams = dlfcn.dlsym(handle, 'cuGraphExternalSemaphoresWaitNodeGetParams')
        global __cuGraphExternalSemaphoresWaitNodeSetParams
        __cuGraphExternalSemaphoresWaitNodeSetParams = dlfcn.dlsym(handle, 'cuGraphExternalSemaphoresWaitNodeSetParams')
        global __cuGraphAddBatchMemOpNode
        __cuGraphAddBatchMemOpNode = dlfcn.dlsym(handle, 'cuGraphAddBatchMemOpNode')
        global __cuGraphBatchMemOpNodeGetParams
        __cuGraphBatchMemOpNodeGetParams = dlfcn.dlsym(handle, 'cuGraphBatchMemOpNodeGetParams')
        global __cuGraphBatchMemOpNodeSetParams
        __cuGraphBatchMemOpNodeSetParams = dlfcn.dlsym(handle, 'cuGraphBatchMemOpNodeSetParams')
        global __cuGraphExecBatchMemOpNodeSetParams
        __cuGraphExecBatchMemOpNodeSetParams = dlfcn.dlsym(handle, 'cuGraphExecBatchMemOpNodeSetParams')
        global __cuGraphAddMemAllocNode
        __cuGraphAddMemAllocNode = dlfcn.dlsym(handle, 'cuGraphAddMemAllocNode')
        global __cuGraphMemAllocNodeGetParams
        __cuGraphMemAllocNodeGetParams = dlfcn.dlsym(handle, 'cuGraphMemAllocNodeGetParams')
        global __cuGraphAddMemFreeNode
        __cuGraphAddMemFreeNode = dlfcn.dlsym(handle, 'cuGraphAddMemFreeNode')
        global __cuGraphMemFreeNodeGetParams
        __cuGraphMemFreeNodeGetParams = dlfcn.dlsym(handle, 'cuGraphMemFreeNodeGetParams')
        global __cuDeviceGraphMemTrim
        __cuDeviceGraphMemTrim = dlfcn.dlsym(handle, 'cuDeviceGraphMemTrim')
        global __cuDeviceGetGraphMemAttribute
        __cuDeviceGetGraphMemAttribute = dlfcn.dlsym(handle, 'cuDeviceGetGraphMemAttribute')
        global __cuDeviceSetGraphMemAttribute
        __cuDeviceSetGraphMemAttribute = dlfcn.dlsym(handle, 'cuDeviceSetGraphMemAttribute')
        global __cuGraphClone
        __cuGraphClone = dlfcn.dlsym(handle, 'cuGraphClone')
        global __cuGraphNodeFindInClone
        __cuGraphNodeFindInClone = dlfcn.dlsym(handle, 'cuGraphNodeFindInClone')
        global __cuGraphNodeGetType
        __cuGraphNodeGetType = dlfcn.dlsym(handle, 'cuGraphNodeGetType')
        global __cuGraphGetNodes
        __cuGraphGetNodes = dlfcn.dlsym(handle, 'cuGraphGetNodes')
        global __cuGraphGetRootNodes
        __cuGraphGetRootNodes = dlfcn.dlsym(handle, 'cuGraphGetRootNodes')
        global __cuGraphGetEdges
        __cuGraphGetEdges = dlfcn.dlsym(handle, 'cuGraphGetEdges')
        global __cuGraphGetEdges_v2
        __cuGraphGetEdges_v2 = dlfcn.dlsym(handle, 'cuGraphGetEdges_v2')
        global __cuGraphNodeGetDependencies
        __cuGraphNodeGetDependencies = dlfcn.dlsym(handle, 'cuGraphNodeGetDependencies')
        global __cuGraphNodeGetDependencies_v2
        __cuGraphNodeGetDependencies_v2 = dlfcn.dlsym(handle, 'cuGraphNodeGetDependencies_v2')
        global __cuGraphNodeGetDependentNodes
        __cuGraphNodeGetDependentNodes = dlfcn.dlsym(handle, 'cuGraphNodeGetDependentNodes')
        global __cuGraphNodeGetDependentNodes_v2
        __cuGraphNodeGetDependentNodes_v2 = dlfcn.dlsym(handle, 'cuGraphNodeGetDependentNodes_v2')
        global __cuGraphAddDependencies
        __cuGraphAddDependencies = dlfcn.dlsym(handle, 'cuGraphAddDependencies')
        global __cuGraphAddDependencies_v2
        __cuGraphAddDependencies_v2 = dlfcn.dlsym(handle, 'cuGraphAddDependencies_v2')
        global __cuGraphRemoveDependencies
        __cuGraphRemoveDependencies = dlfcn.dlsym(handle, 'cuGraphRemoveDependencies')
        global __cuGraphRemoveDependencies_v2
        __cuGraphRemoveDependencies_v2 = dlfcn.dlsym(handle, 'cuGraphRemoveDependencies_v2')
        global __cuGraphDestroyNode
        __cuGraphDestroyNode = dlfcn.dlsym(handle, 'cuGraphDestroyNode')
        global __cuGraphInstantiateWithFlags
        __cuGraphInstantiateWithFlags = dlfcn.dlsym(handle, 'cuGraphInstantiateWithFlags')
        global __cuGraphExecGetFlags
        __cuGraphExecGetFlags = dlfcn.dlsym(handle, 'cuGraphExecGetFlags')
        global __cuGraphExecKernelNodeSetParams_v2
        __cuGraphExecKernelNodeSetParams_v2 = dlfcn.dlsym(handle, 'cuGraphExecKernelNodeSetParams_v2')
        global __cuGraphExecMemcpyNodeSetParams
        __cuGraphExecMemcpyNodeSetParams = dlfcn.dlsym(handle, 'cuGraphExecMemcpyNodeSetParams')
        global __cuGraphExecMemsetNodeSetParams
        __cuGraphExecMemsetNodeSetParams = dlfcn.dlsym(handle, 'cuGraphExecMemsetNodeSetParams')
        global __cuGraphExecHostNodeSetParams
        __cuGraphExecHostNodeSetParams = dlfcn.dlsym(handle, 'cuGraphExecHostNodeSetParams')
        global __cuGraphExecChildGraphNodeSetParams
        __cuGraphExecChildGraphNodeSetParams = dlfcn.dlsym(handle, 'cuGraphExecChildGraphNodeSetParams')
        global __cuGraphExecEventRecordNodeSetEvent
        __cuGraphExecEventRecordNodeSetEvent = dlfcn.dlsym(handle, 'cuGraphExecEventRecordNodeSetEvent')
        global __cuGraphExecEventWaitNodeSetEvent
        __cuGraphExecEventWaitNodeSetEvent = dlfcn.dlsym(handle, 'cuGraphExecEventWaitNodeSetEvent')
        global __cuGraphExecExternalSemaphoresSignalNodeSetParams
        __cuGraphExecExternalSemaphoresSignalNodeSetParams = dlfcn.dlsym(handle, 'cuGraphExecExternalSemaphoresSignalNodeSetParams')
        global __cuGraphExecExternalSemaphoresWaitNodeSetParams
        __cuGraphExecExternalSemaphoresWaitNodeSetParams = dlfcn.dlsym(handle, 'cuGraphExecExternalSemaphoresWaitNodeSetParams')
        global __cuGraphNodeSetEnabled
        __cuGraphNodeSetEnabled = dlfcn.dlsym(handle, 'cuGraphNodeSetEnabled')
        global __cuGraphNodeGetEnabled
        __cuGraphNodeGetEnabled = dlfcn.dlsym(handle, 'cuGraphNodeGetEnabled')
        global __cuGraphExecDestroy
        __cuGraphExecDestroy = dlfcn.dlsym(handle, 'cuGraphExecDestroy')
        global __cuGraphDestroy
        __cuGraphDestroy = dlfcn.dlsym(handle, 'cuGraphDestroy')
        global __cuGraphExecUpdate_v2
        __cuGraphExecUpdate_v2 = dlfcn.dlsym(handle, 'cuGraphExecUpdate_v2')
        global __cuGraphKernelNodeCopyAttributes
        __cuGraphKernelNodeCopyAttributes = dlfcn.dlsym(handle, 'cuGraphKernelNodeCopyAttributes')
        global __cuGraphKernelNodeGetAttribute
        __cuGraphKernelNodeGetAttribute = dlfcn.dlsym(handle, 'cuGraphKernelNodeGetAttribute')
        global __cuGraphKernelNodeSetAttribute
        __cuGraphKernelNodeSetAttribute = dlfcn.dlsym(handle, 'cuGraphKernelNodeSetAttribute')
        global __cuGraphDebugDotPrint
        __cuGraphDebugDotPrint = dlfcn.dlsym(handle, 'cuGraphDebugDotPrint')
        global __cuUserObjectCreate
        __cuUserObjectCreate = dlfcn.dlsym(handle, 'cuUserObjectCreate')
        global __cuUserObjectRetain
        __cuUserObjectRetain = dlfcn.dlsym(handle, 'cuUserObjectRetain')
        global __cuUserObjectRelease
        __cuUserObjectRelease = dlfcn.dlsym(handle, 'cuUserObjectRelease')
        global __cuGraphRetainUserObject
        __cuGraphRetainUserObject = dlfcn.dlsym(handle, 'cuGraphRetainUserObject')
        global __cuGraphReleaseUserObject
        __cuGraphReleaseUserObject = dlfcn.dlsym(handle, 'cuGraphReleaseUserObject')
        global __cuGraphAddNode
        __cuGraphAddNode = dlfcn.dlsym(handle, 'cuGraphAddNode')
        global __cuGraphAddNode_v2
        __cuGraphAddNode_v2 = dlfcn.dlsym(handle, 'cuGraphAddNode_v2')
        global __cuGraphNodeSetParams
        __cuGraphNodeSetParams = dlfcn.dlsym(handle, 'cuGraphNodeSetParams')
        global __cuGraphExecNodeSetParams
        __cuGraphExecNodeSetParams = dlfcn.dlsym(handle, 'cuGraphExecNodeSetParams')
        global __cuGraphConditionalHandleCreate
        __cuGraphConditionalHandleCreate = dlfcn.dlsym(handle, 'cuGraphConditionalHandleCreate')
        global __cuOccupancyMaxActiveBlocksPerMultiprocessor
        __cuOccupancyMaxActiveBlocksPerMultiprocessor = dlfcn.dlsym(handle, 'cuOccupancyMaxActiveBlocksPerMultiprocessor')
        global __cuOccupancyMaxActiveBlocksPerMultiprocessorWithFlags
        __cuOccupancyMaxActiveBlocksPerMultiprocessorWithFlags = dlfcn.dlsym(handle, 'cuOccupancyMaxActiveBlocksPerMultiprocessorWithFlags')
        global __cuOccupancyMaxPotentialBlockSize
        __cuOccupancyMaxPotentialBlockSize = dlfcn.dlsym(handle, 'cuOccupancyMaxPotentialBlockSize')
        global __cuOccupancyMaxPotentialBlockSizeWithFlags
        __cuOccupancyMaxPotentialBlockSizeWithFlags = dlfcn.dlsym(handle, 'cuOccupancyMaxPotentialBlockSizeWithFlags')
        global __cuOccupancyAvailableDynamicSMemPerBlock
        __cuOccupancyAvailableDynamicSMemPerBlock = dlfcn.dlsym(handle, 'cuOccupancyAvailableDynamicSMemPerBlock')
        global __cuOccupancyMaxPotentialClusterSize
        __cuOccupancyMaxPotentialClusterSize = dlfcn.dlsym(handle, 'cuOccupancyMaxPotentialClusterSize')
        global __cuOccupancyMaxActiveClusters
        __cuOccupancyMaxActiveClusters = dlfcn.dlsym(handle, 'cuOccupancyMaxActiveClusters')
        global __cuTexRefSetArray
        __cuTexRefSetArray = dlfcn.dlsym(handle, 'cuTexRefSetArray')
        global __cuTexRefSetMipmappedArray
        __cuTexRefSetMipmappedArray = dlfcn.dlsym(handle, 'cuTexRefSetMipmappedArray')
        global __cuTexRefSetAddress_v2
        __cuTexRefSetAddress_v2 = dlfcn.dlsym(handle, 'cuTexRefSetAddress_v2')
        global __cuTexRefSetAddress2D_v3
        __cuTexRefSetAddress2D_v3 = dlfcn.dlsym(handle, 'cuTexRefSetAddress2D_v3')
        global __cuTexRefSetFormat
        __cuTexRefSetFormat = dlfcn.dlsym(handle, 'cuTexRefSetFormat')
        global __cuTexRefSetAddressMode
        __cuTexRefSetAddressMode = dlfcn.dlsym(handle, 'cuTexRefSetAddressMode')
        global __cuTexRefSetFilterMode
        __cuTexRefSetFilterMode = dlfcn.dlsym(handle, 'cuTexRefSetFilterMode')
        global __cuTexRefSetMipmapFilterMode
        __cuTexRefSetMipmapFilterMode = dlfcn.dlsym(handle, 'cuTexRefSetMipmapFilterMode')
        global __cuTexRefSetMipmapLevelBias
        __cuTexRefSetMipmapLevelBias = dlfcn.dlsym(handle, 'cuTexRefSetMipmapLevelBias')
        global __cuTexRefSetMipmapLevelClamp
        __cuTexRefSetMipmapLevelClamp = dlfcn.dlsym(handle, 'cuTexRefSetMipmapLevelClamp')
        global __cuTexRefSetMaxAnisotropy
        __cuTexRefSetMaxAnisotropy = dlfcn.dlsym(handle, 'cuTexRefSetMaxAnisotropy')
        global __cuTexRefSetBorderColor
        __cuTexRefSetBorderColor = dlfcn.dlsym(handle, 'cuTexRefSetBorderColor')
        global __cuTexRefSetFlags
        __cuTexRefSetFlags = dlfcn.dlsym(handle, 'cuTexRefSetFlags')
        global __cuTexRefGetAddress_v2
        __cuTexRefGetAddress_v2 = dlfcn.dlsym(handle, 'cuTexRefGetAddress_v2')
        global __cuTexRefGetArray
        __cuTexRefGetArray = dlfcn.dlsym(handle, 'cuTexRefGetArray')
        global __cuTexRefGetMipmappedArray
        __cuTexRefGetMipmappedArray = dlfcn.dlsym(handle, 'cuTexRefGetMipmappedArray')
        global __cuTexRefGetAddressMode
        __cuTexRefGetAddressMode = dlfcn.dlsym(handle, 'cuTexRefGetAddressMode')
        global __cuTexRefGetFilterMode
        __cuTexRefGetFilterMode = dlfcn.dlsym(handle, 'cuTexRefGetFilterMode')
        global __cuTexRefGetFormat
        __cuTexRefGetFormat = dlfcn.dlsym(handle, 'cuTexRefGetFormat')
        global __cuTexRefGetMipmapFilterMode
        __cuTexRefGetMipmapFilterMode = dlfcn.dlsym(handle, 'cuTexRefGetMipmapFilterMode')
        global __cuTexRefGetMipmapLevelBias
        __cuTexRefGetMipmapLevelBias = dlfcn.dlsym(handle, 'cuTexRefGetMipmapLevelBias')
        global __cuTexRefGetMipmapLevelClamp
        __cuTexRefGetMipmapLevelClamp = dlfcn.dlsym(handle, 'cuTexRefGetMipmapLevelClamp')
        global __cuTexRefGetMaxAnisotropy
        __cuTexRefGetMaxAnisotropy = dlfcn.dlsym(handle, 'cuTexRefGetMaxAnisotropy')
        global __cuTexRefGetBorderColor
        __cuTexRefGetBorderColor = dlfcn.dlsym(handle, 'cuTexRefGetBorderColor')
        global __cuTexRefGetFlags
        __cuTexRefGetFlags = dlfcn.dlsym(handle, 'cuTexRefGetFlags')
        global __cuTexRefCreate
        __cuTexRefCreate = dlfcn.dlsym(handle, 'cuTexRefCreate')
        global __cuTexRefDestroy
        __cuTexRefDestroy = dlfcn.dlsym(handle, 'cuTexRefDestroy')
        global __cuSurfRefSetArray
        __cuSurfRefSetArray = dlfcn.dlsym(handle, 'cuSurfRefSetArray')
        global __cuSurfRefGetArray
        __cuSurfRefGetArray = dlfcn.dlsym(handle, 'cuSurfRefGetArray')
        global __cuTexObjectCreate
        __cuTexObjectCreate = dlfcn.dlsym(handle, 'cuTexObjectCreate')
        global __cuTexObjectDestroy
        __cuTexObjectDestroy = dlfcn.dlsym(handle, 'cuTexObjectDestroy')
        global __cuTexObjectGetResourceDesc
        __cuTexObjectGetResourceDesc = dlfcn.dlsym(handle, 'cuTexObjectGetResourceDesc')
        global __cuTexObjectGetTextureDesc
        __cuTexObjectGetTextureDesc = dlfcn.dlsym(handle, 'cuTexObjectGetTextureDesc')
        global __cuTexObjectGetResourceViewDesc
        __cuTexObjectGetResourceViewDesc = dlfcn.dlsym(handle, 'cuTexObjectGetResourceViewDesc')
        global __cuSurfObjectCreate
        __cuSurfObjectCreate = dlfcn.dlsym(handle, 'cuSurfObjectCreate')
        global __cuSurfObjectDestroy
        __cuSurfObjectDestroy = dlfcn.dlsym(handle, 'cuSurfObjectDestroy')
        global __cuSurfObjectGetResourceDesc
        __cuSurfObjectGetResourceDesc = dlfcn.dlsym(handle, 'cuSurfObjectGetResourceDesc')
        global __cuTensorMapEncodeTiled
        __cuTensorMapEncodeTiled = dlfcn.dlsym(handle, 'cuTensorMapEncodeTiled')
        global __cuTensorMapEncodeIm2col
        __cuTensorMapEncodeIm2col = dlfcn.dlsym(handle, 'cuTensorMapEncodeIm2col')
        global __cuTensorMapEncodeIm2colWide
        __cuTensorMapEncodeIm2colWide = dlfcn.dlsym(handle, 'cuTensorMapEncodeIm2colWide')
        global __cuTensorMapReplaceAddress
        __cuTensorMapReplaceAddress = dlfcn.dlsym(handle, 'cuTensorMapReplaceAddress')
        global __cuDeviceCanAccessPeer
        __cuDeviceCanAccessPeer = dlfcn.dlsym(handle, 'cuDeviceCanAccessPeer')
        global __cuCtxEnablePeerAccess
        __cuCtxEnablePeerAccess = dlfcn.dlsym(handle, 'cuCtxEnablePeerAccess')
        global __cuCtxDisablePeerAccess
        __cuCtxDisablePeerAccess = dlfcn.dlsym(handle, 'cuCtxDisablePeerAccess')
        global __cuDeviceGetP2PAttribute
        __cuDeviceGetP2PAttribute = dlfcn.dlsym(handle, 'cuDeviceGetP2PAttribute')
        global __cuGraphicsUnregisterResource
        __cuGraphicsUnregisterResource = dlfcn.dlsym(handle, 'cuGraphicsUnregisterResource')
        global __cuGraphicsSubResourceGetMappedArray
        __cuGraphicsSubResourceGetMappedArray = dlfcn.dlsym(handle, 'cuGraphicsSubResourceGetMappedArray')
        global __cuGraphicsResourceGetMappedMipmappedArray
        __cuGraphicsResourceGetMappedMipmappedArray = dlfcn.dlsym(handle, 'cuGraphicsResourceGetMappedMipmappedArray')
        global __cuGraphicsResourceGetMappedPointer_v2
        __cuGraphicsResourceGetMappedPointer_v2 = dlfcn.dlsym(handle, 'cuGraphicsResourceGetMappedPointer_v2')
        global __cuGraphicsResourceSetMapFlags_v2
        __cuGraphicsResourceSetMapFlags_v2 = dlfcn.dlsym(handle, 'cuGraphicsResourceSetMapFlags_v2')
        global __cuGetProcAddress_v2
        __cuGetProcAddress_v2 = dlfcn.dlsym(handle, 'cuGetProcAddress_v2')
        global __cuCoredumpGetAttribute
        __cuCoredumpGetAttribute = dlfcn.dlsym(handle, 'cuCoredumpGetAttribute')
        global __cuCoredumpGetAttributeGlobal
        __cuCoredumpGetAttributeGlobal = dlfcn.dlsym(handle, 'cuCoredumpGetAttributeGlobal')
        global __cuCoredumpSetAttribute
        __cuCoredumpSetAttribute = dlfcn.dlsym(handle, 'cuCoredumpSetAttribute')
        global __cuCoredumpSetAttributeGlobal
        __cuCoredumpSetAttributeGlobal = dlfcn.dlsym(handle, 'cuCoredumpSetAttributeGlobal')
        global __cuGetExportTable
        __cuGetExportTable = dlfcn.dlsym(handle, 'cuGetExportTable')
        global __cuGreenCtxCreate
        __cuGreenCtxCreate = dlfcn.dlsym(handle, 'cuGreenCtxCreate')
        global __cuGreenCtxDestroy
        __cuGreenCtxDestroy = dlfcn.dlsym(handle, 'cuGreenCtxDestroy')
        global __cuCtxFromGreenCtx
        __cuCtxFromGreenCtx = dlfcn.dlsym(handle, 'cuCtxFromGreenCtx')
        global __cuDeviceGetDevResource
        __cuDeviceGetDevResource = dlfcn.dlsym(handle, 'cuDeviceGetDevResource')
        global __cuCtxGetDevResource
        __cuCtxGetDevResource = dlfcn.dlsym(handle, 'cuCtxGetDevResource')
        global __cuGreenCtxGetDevResource
        __cuGreenCtxGetDevResource = dlfcn.dlsym(handle, 'cuGreenCtxGetDevResource')
        global __cuDevSmResourceSplitByCount
        __cuDevSmResourceSplitByCount = dlfcn.dlsym(handle, 'cuDevSmResourceSplitByCount')
        global __cuDevResourceGenerateDesc
        __cuDevResourceGenerateDesc = dlfcn.dlsym(handle, 'cuDevResourceGenerateDesc')
        global __cuGreenCtxRecordEvent
        __cuGreenCtxRecordEvent = dlfcn.dlsym(handle, 'cuGreenCtxRecordEvent')
        global __cuGreenCtxWaitEvent
        __cuGreenCtxWaitEvent = dlfcn.dlsym(handle, 'cuGreenCtxWaitEvent')
        global __cuStreamGetGreenCtx
        __cuStreamGetGreenCtx = dlfcn.dlsym(handle, 'cuStreamGetGreenCtx')
        global __cuGreenCtxStreamCreate
        __cuGreenCtxStreamCreate = dlfcn.dlsym(handle, 'cuGreenCtxStreamCreate')
        global __cuLogsRegisterCallback
        __cuLogsRegisterCallback = dlfcn.dlsym(handle, 'cuLogsRegisterCallback')
        global __cuLogsUnregisterCallback
        __cuLogsUnregisterCallback = dlfcn.dlsym(handle, 'cuLogsUnregisterCallback')
        global __cuLogsCurrent
        __cuLogsCurrent = dlfcn.dlsym(handle, 'cuLogsCurrent')
        global __cuLogsDumpToFile
        __cuLogsDumpToFile = dlfcn.dlsym(handle, 'cuLogsDumpToFile')
        global __cuLogsDumpToMemory
        __cuLogsDumpToMemory = dlfcn.dlsym(handle, 'cuLogsDumpToMemory')
        global __cuCheckpointProcessGetRestoreThreadId
        __cuCheckpointProcessGetRestoreThreadId = dlfcn.dlsym(handle, 'cuCheckpointProcessGetRestoreThreadId')
        global __cuCheckpointProcessGetState
        __cuCheckpointProcessGetState = dlfcn.dlsym(handle, 'cuCheckpointProcessGetState')
        global __cuCheckpointProcessLock
        __cuCheckpointProcessLock = dlfcn.dlsym(handle, 'cuCheckpointProcessLock')
        global __cuCheckpointProcessCheckpoint
        __cuCheckpointProcessCheckpoint = dlfcn.dlsym(handle, 'cuCheckpointProcessCheckpoint')
        global __cuCheckpointProcessRestore
        __cuCheckpointProcessRestore = dlfcn.dlsym(handle, 'cuCheckpointProcessRestore')
        global __cuCheckpointProcessUnlock
        __cuCheckpointProcessUnlock = dlfcn.dlsym(handle, 'cuCheckpointProcessUnlock')
        global __cuProfilerStart
        __cuProfilerStart = dlfcn.dlsym(handle, 'cuProfilerStart')
        global __cuProfilerStop
        __cuProfilerStop = dlfcn.dlsym(handle, 'cuProfilerStop')
        global __cuGraphicsEGLRegisterImage
        __cuGraphicsEGLRegisterImage = dlfcn.dlsym(handle, 'cuGraphicsEGLRegisterImage')
        global __cuEGLStreamConsumerConnect
        __cuEGLStreamConsumerConnect = dlfcn.dlsym(handle, 'cuEGLStreamConsumerConnect')
        global __cuEGLStreamConsumerConnectWithFlags
        __cuEGLStreamConsumerConnectWithFlags = dlfcn.dlsym(handle, 'cuEGLStreamConsumerConnectWithFlags')
        global __cuEGLStreamConsumerDisconnect
        __cuEGLStreamConsumerDisconnect = dlfcn.dlsym(handle, 'cuEGLStreamConsumerDisconnect')
        global __cuEGLStreamConsumerAcquireFrame
        __cuEGLStreamConsumerAcquireFrame = dlfcn.dlsym(handle, 'cuEGLStreamConsumerAcquireFrame')
        global __cuEGLStreamConsumerReleaseFrame
        __cuEGLStreamConsumerReleaseFrame = dlfcn.dlsym(handle, 'cuEGLStreamConsumerReleaseFrame')
        global __cuEGLStreamProducerConnect
        __cuEGLStreamProducerConnect = dlfcn.dlsym(handle, 'cuEGLStreamProducerConnect')
        global __cuEGLStreamProducerDisconnect
        __cuEGLStreamProducerDisconnect = dlfcn.dlsym(handle, 'cuEGLStreamProducerDisconnect')
        global __cuEGLStreamProducerPresentFrame
        __cuEGLStreamProducerPresentFrame = dlfcn.dlsym(handle, 'cuEGLStreamProducerPresentFrame')
        global __cuEGLStreamProducerReturnFrame
        __cuEGLStreamProducerReturnFrame = dlfcn.dlsym(handle, 'cuEGLStreamProducerReturnFrame')
        global __cuGraphicsResourceGetMappedEglFrame
        __cuGraphicsResourceGetMappedEglFrame = dlfcn.dlsym(handle, 'cuGraphicsResourceGetMappedEglFrame')
        global __cuEventCreateFromEGLSync
        __cuEventCreateFromEGLSync = dlfcn.dlsym(handle, 'cuEventCreateFromEGLSync')
        global __cuGraphicsGLRegisterBuffer
        __cuGraphicsGLRegisterBuffer = dlfcn.dlsym(handle, 'cuGraphicsGLRegisterBuffer')
        global __cuGraphicsGLRegisterImage
        __cuGraphicsGLRegisterImage = dlfcn.dlsym(handle, 'cuGraphicsGLRegisterImage')
        global __cuGLGetDevices_v2
        __cuGLGetDevices_v2 = dlfcn.dlsym(handle, 'cuGLGetDevices_v2')
        global __cuVDPAUGetDevice
        __cuVDPAUGetDevice = dlfcn.dlsym(handle, 'cuVDPAUGetDevice')
        global __cuVDPAUCtxCreate_v2
        __cuVDPAUCtxCreate_v2 = dlfcn.dlsym(handle, 'cuVDPAUCtxCreate_v2')
        global __cuGraphicsVDPAURegisterVideoSurface
        __cuGraphicsVDPAURegisterVideoSurface = dlfcn.dlsym(handle, 'cuGraphicsVDPAURegisterVideoSurface')
        global __cuGraphicsVDPAURegisterOutputSurface
        __cuGraphicsVDPAURegisterOutputSurface = dlfcn.dlsym(handle, 'cuGraphicsVDPAURegisterOutputSurface')
        __cuPythonInit = True
        return 0

# Create a very small function to check whether we are init'ed, so the C
# compiler can inline it.
cdef inline int cuPythonInit() except -1 nogil:
    if __cuPythonInit:
        return 0
    return _cuPythonInit()

cdef CUresult _cuGetErrorString(CUresult error, const char** pStr) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGetErrorString
    cuPythonInit()
    if __cuGetErrorString == NULL:
        with gil:
            raise RuntimeError('Function "cuGetErrorString" not found')
    err = (<CUresult (*)(CUresult, const char**) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGetErrorString)(error, pStr)
    return err

cdef CUresult _cuGetErrorName(CUresult error, const char** pStr) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGetErrorName
    cuPythonInit()
    if __cuGetErrorName == NULL:
        with gil:
            raise RuntimeError('Function "cuGetErrorName" not found')
    err = (<CUresult (*)(CUresult, const char**) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGetErrorName)(error, pStr)
    return err

cdef CUresult _cuInit(unsigned int Flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuInit
    cuPythonInit()
    if __cuInit == NULL:
        with gil:
            raise RuntimeError('Function "cuInit" not found')
    err = (<CUresult (*)(unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuInit)(Flags)
    return err

cdef CUresult _cuDriverGetVersion(int* driverVersion) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuDriverGetVersion
    cuPythonInit()
    if __cuDriverGetVersion == NULL:
        with gil:
            raise RuntimeError('Function "cuDriverGetVersion" not found')
    err = (<CUresult (*)(int*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuDriverGetVersion)(driverVersion)
    return err

cdef CUresult _cuDeviceGet(CUdevice* device, int ordinal) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuDeviceGet
    cuPythonInit()
    if __cuDeviceGet == NULL:
        with gil:
            raise RuntimeError('Function "cuDeviceGet" not found')
    err = (<CUresult (*)(CUdevice*, int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuDeviceGet)(device, ordinal)
    return err

cdef CUresult _cuDeviceGetCount(int* count) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuDeviceGetCount
    cuPythonInit()
    if __cuDeviceGetCount == NULL:
        with gil:
            raise RuntimeError('Function "cuDeviceGetCount" not found')
    err = (<CUresult (*)(int*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuDeviceGetCount)(count)
    return err

cdef CUresult _cuDeviceGetName(char* name, int length, CUdevice dev) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuDeviceGetName
    cuPythonInit()
    if __cuDeviceGetName == NULL:
        with gil:
            raise RuntimeError('Function "cuDeviceGetName" not found')
    err = (<CUresult (*)(char*, int, CUdevice) except ?CUDA_ERROR_NOT_FOUND nogil> __cuDeviceGetName)(name, length, dev)
    return err

cdef CUresult _cuDeviceGetUuid(CUuuid* uuid, CUdevice dev) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuDeviceGetUuid
    cuPythonInit()
    if __cuDeviceGetUuid == NULL:
        with gil:
            raise RuntimeError('Function "cuDeviceGetUuid" not found')
    err = (<CUresult (*)(CUuuid*, CUdevice) except ?CUDA_ERROR_NOT_FOUND nogil> __cuDeviceGetUuid)(uuid, dev)
    return err

cdef CUresult _cuDeviceGetUuid_v2(CUuuid* uuid, CUdevice dev) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuDeviceGetUuid_v2
    cuPythonInit()
    if __cuDeviceGetUuid_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuDeviceGetUuid_v2" not found')
    err = (<CUresult (*)(CUuuid*, CUdevice) except ?CUDA_ERROR_NOT_FOUND nogil> __cuDeviceGetUuid_v2)(uuid, dev)
    return err

cdef CUresult _cuDeviceGetLuid(char* luid, unsigned int* deviceNodeMask, CUdevice dev) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuDeviceGetLuid
    cuPythonInit()
    if __cuDeviceGetLuid == NULL:
        with gil:
            raise RuntimeError('Function "cuDeviceGetLuid" not found')
    err = (<CUresult (*)(char*, unsigned int*, CUdevice) except ?CUDA_ERROR_NOT_FOUND nogil> __cuDeviceGetLuid)(luid, deviceNodeMask, dev)
    return err

cdef CUresult _cuDeviceTotalMem_v2(size_t* numbytes, CUdevice dev) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuDeviceTotalMem_v2
    cuPythonInit()
    if __cuDeviceTotalMem_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuDeviceTotalMem_v2" not found')
    err = (<CUresult (*)(size_t*, CUdevice) except ?CUDA_ERROR_NOT_FOUND nogil> __cuDeviceTotalMem_v2)(numbytes, dev)
    return err

cdef CUresult _cuDeviceGetTexture1DLinearMaxWidth(size_t* maxWidthInElements, CUarray_format pformat, unsigned numChannels, CUdevice dev) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuDeviceGetTexture1DLinearMaxWidth
    cuPythonInit()
    if __cuDeviceGetTexture1DLinearMaxWidth == NULL:
        with gil:
            raise RuntimeError('Function "cuDeviceGetTexture1DLinearMaxWidth" not found')
    err = (<CUresult (*)(size_t*, CUarray_format, unsigned, CUdevice) except ?CUDA_ERROR_NOT_FOUND nogil> __cuDeviceGetTexture1DLinearMaxWidth)(maxWidthInElements, pformat, numChannels, dev)
    return err

cdef CUresult _cuDeviceGetAttribute(int* pi, CUdevice_attribute attrib, CUdevice dev) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuDeviceGetAttribute
    cuPythonInit()
    if __cuDeviceGetAttribute == NULL:
        with gil:
            raise RuntimeError('Function "cuDeviceGetAttribute" not found')
    err = (<CUresult (*)(int*, CUdevice_attribute, CUdevice) except ?CUDA_ERROR_NOT_FOUND nogil> __cuDeviceGetAttribute)(pi, attrib, dev)
    return err

cdef CUresult _cuDeviceGetNvSciSyncAttributes(void* nvSciSyncAttrList, CUdevice dev, int flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuDeviceGetNvSciSyncAttributes
    cuPythonInit()
    if __cuDeviceGetNvSciSyncAttributes == NULL:
        with gil:
            raise RuntimeError('Function "cuDeviceGetNvSciSyncAttributes" not found')
    err = (<CUresult (*)(void*, CUdevice, int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuDeviceGetNvSciSyncAttributes)(nvSciSyncAttrList, dev, flags)
    return err

cdef CUresult _cuDeviceSetMemPool(CUdevice dev, CUmemoryPool pool) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuDeviceSetMemPool
    cuPythonInit()
    if __cuDeviceSetMemPool == NULL:
        with gil:
            raise RuntimeError('Function "cuDeviceSetMemPool" not found')
    err = (<CUresult (*)(CUdevice, CUmemoryPool) except ?CUDA_ERROR_NOT_FOUND nogil> __cuDeviceSetMemPool)(dev, pool)
    return err

cdef CUresult _cuDeviceGetMemPool(CUmemoryPool* pool, CUdevice dev) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuDeviceGetMemPool
    cuPythonInit()
    if __cuDeviceGetMemPool == NULL:
        with gil:
            raise RuntimeError('Function "cuDeviceGetMemPool" not found')
    err = (<CUresult (*)(CUmemoryPool*, CUdevice) except ?CUDA_ERROR_NOT_FOUND nogil> __cuDeviceGetMemPool)(pool, dev)
    return err

cdef CUresult _cuDeviceGetDefaultMemPool(CUmemoryPool* pool_out, CUdevice dev) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuDeviceGetDefaultMemPool
    cuPythonInit()
    if __cuDeviceGetDefaultMemPool == NULL:
        with gil:
            raise RuntimeError('Function "cuDeviceGetDefaultMemPool" not found')
    err = (<CUresult (*)(CUmemoryPool*, CUdevice) except ?CUDA_ERROR_NOT_FOUND nogil> __cuDeviceGetDefaultMemPool)(pool_out, dev)
    return err

cdef CUresult _cuDeviceGetExecAffinitySupport(int* pi, CUexecAffinityType typename, CUdevice dev) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuDeviceGetExecAffinitySupport
    cuPythonInit()
    if __cuDeviceGetExecAffinitySupport == NULL:
        with gil:
            raise RuntimeError('Function "cuDeviceGetExecAffinitySupport" not found')
    err = (<CUresult (*)(int*, CUexecAffinityType, CUdevice) except ?CUDA_ERROR_NOT_FOUND nogil> __cuDeviceGetExecAffinitySupport)(pi, typename, dev)
    return err

cdef CUresult _cuFlushGPUDirectRDMAWrites(CUflushGPUDirectRDMAWritesTarget target, CUflushGPUDirectRDMAWritesScope scope) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuFlushGPUDirectRDMAWrites
    cuPythonInit()
    if __cuFlushGPUDirectRDMAWrites == NULL:
        with gil:
            raise RuntimeError('Function "cuFlushGPUDirectRDMAWrites" not found')
    err = (<CUresult (*)(CUflushGPUDirectRDMAWritesTarget, CUflushGPUDirectRDMAWritesScope) except ?CUDA_ERROR_NOT_FOUND nogil> __cuFlushGPUDirectRDMAWrites)(target, scope)
    return err

cdef CUresult _cuDeviceGetProperties(CUdevprop* prop, CUdevice dev) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuDeviceGetProperties
    cuPythonInit()
    if __cuDeviceGetProperties == NULL:
        with gil:
            raise RuntimeError('Function "cuDeviceGetProperties" not found')
    err = (<CUresult (*)(CUdevprop*, CUdevice) except ?CUDA_ERROR_NOT_FOUND nogil> __cuDeviceGetProperties)(prop, dev)
    return err

cdef CUresult _cuDeviceComputeCapability(int* major, int* minor, CUdevice dev) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuDeviceComputeCapability
    cuPythonInit()
    if __cuDeviceComputeCapability == NULL:
        with gil:
            raise RuntimeError('Function "cuDeviceComputeCapability" not found')
    err = (<CUresult (*)(int*, int*, CUdevice) except ?CUDA_ERROR_NOT_FOUND nogil> __cuDeviceComputeCapability)(major, minor, dev)
    return err

cdef CUresult _cuDevicePrimaryCtxRetain(CUcontext* pctx, CUdevice dev) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuDevicePrimaryCtxRetain
    cuPythonInit()
    if __cuDevicePrimaryCtxRetain == NULL:
        with gil:
            raise RuntimeError('Function "cuDevicePrimaryCtxRetain" not found')
    err = (<CUresult (*)(CUcontext*, CUdevice) except ?CUDA_ERROR_NOT_FOUND nogil> __cuDevicePrimaryCtxRetain)(pctx, dev)
    return err

cdef CUresult _cuDevicePrimaryCtxRelease_v2(CUdevice dev) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuDevicePrimaryCtxRelease_v2
    cuPythonInit()
    if __cuDevicePrimaryCtxRelease_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuDevicePrimaryCtxRelease_v2" not found')
    err = (<CUresult (*)(CUdevice) except ?CUDA_ERROR_NOT_FOUND nogil> __cuDevicePrimaryCtxRelease_v2)(dev)
    return err

cdef CUresult _cuDevicePrimaryCtxSetFlags_v2(CUdevice dev, unsigned int flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuDevicePrimaryCtxSetFlags_v2
    cuPythonInit()
    if __cuDevicePrimaryCtxSetFlags_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuDevicePrimaryCtxSetFlags_v2" not found')
    err = (<CUresult (*)(CUdevice, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuDevicePrimaryCtxSetFlags_v2)(dev, flags)
    return err

cdef CUresult _cuDevicePrimaryCtxGetState(CUdevice dev, unsigned int* flags, int* active) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuDevicePrimaryCtxGetState
    cuPythonInit()
    if __cuDevicePrimaryCtxGetState == NULL:
        with gil:
            raise RuntimeError('Function "cuDevicePrimaryCtxGetState" not found')
    err = (<CUresult (*)(CUdevice, unsigned int*, int*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuDevicePrimaryCtxGetState)(dev, flags, active)
    return err

cdef CUresult _cuDevicePrimaryCtxReset_v2(CUdevice dev) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuDevicePrimaryCtxReset_v2
    cuPythonInit()
    if __cuDevicePrimaryCtxReset_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuDevicePrimaryCtxReset_v2" not found')
    err = (<CUresult (*)(CUdevice) except ?CUDA_ERROR_NOT_FOUND nogil> __cuDevicePrimaryCtxReset_v2)(dev)
    return err

cdef CUresult _cuCtxCreate_v2(CUcontext* pctx, unsigned int flags, CUdevice dev) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCtxCreate_v2
    cuPythonInit()
    if __cuCtxCreate_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuCtxCreate_v2" not found')
    err = (<CUresult (*)(CUcontext*, unsigned int, CUdevice) except ?CUDA_ERROR_NOT_FOUND nogil> __cuCtxCreate_v2)(pctx, flags, dev)
    return err

cdef CUresult _cuCtxCreate_v3(CUcontext* pctx, CUexecAffinityParam* paramsArray, int numParams, unsigned int flags, CUdevice dev) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCtxCreate_v3
    cuPythonInit()
    if __cuCtxCreate_v3 == NULL:
        with gil:
            raise RuntimeError('Function "cuCtxCreate_v3" not found')
    err = (<CUresult (*)(CUcontext*, CUexecAffinityParam*, int, unsigned int, CUdevice) except ?CUDA_ERROR_NOT_FOUND nogil> __cuCtxCreate_v3)(pctx, paramsArray, numParams, flags, dev)
    return err

cdef CUresult _cuCtxCreate_v4(CUcontext* pctx, CUctxCreateParams* ctxCreateParams, unsigned int flags, CUdevice dev) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCtxCreate_v4
    cuPythonInit()
    if __cuCtxCreate_v4 == NULL:
        with gil:
            raise RuntimeError('Function "cuCtxCreate_v4" not found')
    err = (<CUresult (*)(CUcontext*, CUctxCreateParams*, unsigned int, CUdevice) except ?CUDA_ERROR_NOT_FOUND nogil> __cuCtxCreate_v4)(pctx, ctxCreateParams, flags, dev)
    return err

cdef CUresult _cuCtxDestroy_v2(CUcontext ctx) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCtxDestroy_v2
    cuPythonInit()
    if __cuCtxDestroy_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuCtxDestroy_v2" not found')
    err = (<CUresult (*)(CUcontext) except ?CUDA_ERROR_NOT_FOUND nogil> __cuCtxDestroy_v2)(ctx)
    return err

cdef CUresult _cuCtxPushCurrent_v2(CUcontext ctx) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCtxPushCurrent_v2
    cuPythonInit()
    if __cuCtxPushCurrent_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuCtxPushCurrent_v2" not found')
    err = (<CUresult (*)(CUcontext) except ?CUDA_ERROR_NOT_FOUND nogil> __cuCtxPushCurrent_v2)(ctx)
    return err

cdef CUresult _cuCtxPopCurrent_v2(CUcontext* pctx) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCtxPopCurrent_v2
    cuPythonInit()
    if __cuCtxPopCurrent_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuCtxPopCurrent_v2" not found')
    err = (<CUresult (*)(CUcontext*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuCtxPopCurrent_v2)(pctx)
    return err

cdef CUresult _cuCtxSetCurrent(CUcontext ctx) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCtxSetCurrent
    cuPythonInit()
    if __cuCtxSetCurrent == NULL:
        with gil:
            raise RuntimeError('Function "cuCtxSetCurrent" not found')
    err = (<CUresult (*)(CUcontext) except ?CUDA_ERROR_NOT_FOUND nogil> __cuCtxSetCurrent)(ctx)
    return err

cdef CUresult _cuCtxGetCurrent(CUcontext* pctx) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCtxGetCurrent
    cuPythonInit()
    if __cuCtxGetCurrent == NULL:
        with gil:
            raise RuntimeError('Function "cuCtxGetCurrent" not found')
    err = (<CUresult (*)(CUcontext*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuCtxGetCurrent)(pctx)
    return err

cdef CUresult _cuCtxGetDevice(CUdevice* device) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCtxGetDevice
    cuPythonInit()
    if __cuCtxGetDevice == NULL:
        with gil:
            raise RuntimeError('Function "cuCtxGetDevice" not found')
    err = (<CUresult (*)(CUdevice*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuCtxGetDevice)(device)
    return err

cdef CUresult _cuCtxGetFlags(unsigned int* flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCtxGetFlags
    cuPythonInit()
    if __cuCtxGetFlags == NULL:
        with gil:
            raise RuntimeError('Function "cuCtxGetFlags" not found')
    err = (<CUresult (*)(unsigned int*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuCtxGetFlags)(flags)
    return err

cdef CUresult _cuCtxSetFlags(unsigned int flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCtxSetFlags
    cuPythonInit()
    if __cuCtxSetFlags == NULL:
        with gil:
            raise RuntimeError('Function "cuCtxSetFlags" not found')
    err = (<CUresult (*)(unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuCtxSetFlags)(flags)
    return err

cdef CUresult _cuCtxGetId(CUcontext ctx, unsigned long long* ctxId) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCtxGetId
    cuPythonInit()
    if __cuCtxGetId == NULL:
        with gil:
            raise RuntimeError('Function "cuCtxGetId" not found')
    err = (<CUresult (*)(CUcontext, unsigned long long*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuCtxGetId)(ctx, ctxId)
    return err

cdef CUresult _cuCtxSynchronize() except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCtxSynchronize
    cuPythonInit()
    if __cuCtxSynchronize == NULL:
        with gil:
            raise RuntimeError('Function "cuCtxSynchronize" not found')
    err = (<CUresult (*)() except ?CUDA_ERROR_NOT_FOUND nogil> __cuCtxSynchronize)()
    return err

cdef CUresult _cuCtxSetLimit(CUlimit limit, size_t value) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCtxSetLimit
    cuPythonInit()
    if __cuCtxSetLimit == NULL:
        with gil:
            raise RuntimeError('Function "cuCtxSetLimit" not found')
    err = (<CUresult (*)(CUlimit, size_t) except ?CUDA_ERROR_NOT_FOUND nogil> __cuCtxSetLimit)(limit, value)
    return err

cdef CUresult _cuCtxGetLimit(size_t* pvalue, CUlimit limit) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCtxGetLimit
    cuPythonInit()
    if __cuCtxGetLimit == NULL:
        with gil:
            raise RuntimeError('Function "cuCtxGetLimit" not found')
    err = (<CUresult (*)(size_t*, CUlimit) except ?CUDA_ERROR_NOT_FOUND nogil> __cuCtxGetLimit)(pvalue, limit)
    return err

cdef CUresult _cuCtxGetCacheConfig(CUfunc_cache* pconfig) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCtxGetCacheConfig
    cuPythonInit()
    if __cuCtxGetCacheConfig == NULL:
        with gil:
            raise RuntimeError('Function "cuCtxGetCacheConfig" not found')
    err = (<CUresult (*)(CUfunc_cache*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuCtxGetCacheConfig)(pconfig)
    return err

cdef CUresult _cuCtxSetCacheConfig(CUfunc_cache config) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCtxSetCacheConfig
    cuPythonInit()
    if __cuCtxSetCacheConfig == NULL:
        with gil:
            raise RuntimeError('Function "cuCtxSetCacheConfig" not found')
    err = (<CUresult (*)(CUfunc_cache) except ?CUDA_ERROR_NOT_FOUND nogil> __cuCtxSetCacheConfig)(config)
    return err

cdef CUresult _cuCtxGetApiVersion(CUcontext ctx, unsigned int* version) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCtxGetApiVersion
    cuPythonInit()
    if __cuCtxGetApiVersion == NULL:
        with gil:
            raise RuntimeError('Function "cuCtxGetApiVersion" not found')
    err = (<CUresult (*)(CUcontext, unsigned int*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuCtxGetApiVersion)(ctx, version)
    return err

cdef CUresult _cuCtxGetStreamPriorityRange(int* leastPriority, int* greatestPriority) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCtxGetStreamPriorityRange
    cuPythonInit()
    if __cuCtxGetStreamPriorityRange == NULL:
        with gil:
            raise RuntimeError('Function "cuCtxGetStreamPriorityRange" not found')
    err = (<CUresult (*)(int*, int*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuCtxGetStreamPriorityRange)(leastPriority, greatestPriority)
    return err

cdef CUresult _cuCtxResetPersistingL2Cache() except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCtxResetPersistingL2Cache
    cuPythonInit()
    if __cuCtxResetPersistingL2Cache == NULL:
        with gil:
            raise RuntimeError('Function "cuCtxResetPersistingL2Cache" not found')
    err = (<CUresult (*)() except ?CUDA_ERROR_NOT_FOUND nogil> __cuCtxResetPersistingL2Cache)()
    return err

cdef CUresult _cuCtxGetExecAffinity(CUexecAffinityParam* pExecAffinity, CUexecAffinityType typename) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCtxGetExecAffinity
    cuPythonInit()
    if __cuCtxGetExecAffinity == NULL:
        with gil:
            raise RuntimeError('Function "cuCtxGetExecAffinity" not found')
    err = (<CUresult (*)(CUexecAffinityParam*, CUexecAffinityType) except ?CUDA_ERROR_NOT_FOUND nogil> __cuCtxGetExecAffinity)(pExecAffinity, typename)
    return err

cdef CUresult _cuCtxRecordEvent(CUcontext hCtx, CUevent hEvent) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCtxRecordEvent
    cuPythonInit()
    if __cuCtxRecordEvent == NULL:
        with gil:
            raise RuntimeError('Function "cuCtxRecordEvent" not found')
    err = (<CUresult (*)(CUcontext, CUevent) except ?CUDA_ERROR_NOT_FOUND nogil> __cuCtxRecordEvent)(hCtx, hEvent)
    return err

cdef CUresult _cuCtxWaitEvent(CUcontext hCtx, CUevent hEvent) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCtxWaitEvent
    cuPythonInit()
    if __cuCtxWaitEvent == NULL:
        with gil:
            raise RuntimeError('Function "cuCtxWaitEvent" not found')
    err = (<CUresult (*)(CUcontext, CUevent) except ?CUDA_ERROR_NOT_FOUND nogil> __cuCtxWaitEvent)(hCtx, hEvent)
    return err

cdef CUresult _cuCtxAttach(CUcontext* pctx, unsigned int flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCtxAttach
    cuPythonInit()
    if __cuCtxAttach == NULL:
        with gil:
            raise RuntimeError('Function "cuCtxAttach" not found')
    err = (<CUresult (*)(CUcontext*, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuCtxAttach)(pctx, flags)
    return err

cdef CUresult _cuCtxDetach(CUcontext ctx) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCtxDetach
    cuPythonInit()
    if __cuCtxDetach == NULL:
        with gil:
            raise RuntimeError('Function "cuCtxDetach" not found')
    err = (<CUresult (*)(CUcontext) except ?CUDA_ERROR_NOT_FOUND nogil> __cuCtxDetach)(ctx)
    return err

cdef CUresult _cuCtxGetSharedMemConfig(CUsharedconfig* pConfig) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCtxGetSharedMemConfig
    cuPythonInit()
    if __cuCtxGetSharedMemConfig == NULL:
        with gil:
            raise RuntimeError('Function "cuCtxGetSharedMemConfig" not found')
    err = (<CUresult (*)(CUsharedconfig*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuCtxGetSharedMemConfig)(pConfig)
    return err

cdef CUresult _cuCtxSetSharedMemConfig(CUsharedconfig config) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCtxSetSharedMemConfig
    cuPythonInit()
    if __cuCtxSetSharedMemConfig == NULL:
        with gil:
            raise RuntimeError('Function "cuCtxSetSharedMemConfig" not found')
    err = (<CUresult (*)(CUsharedconfig) except ?CUDA_ERROR_NOT_FOUND nogil> __cuCtxSetSharedMemConfig)(config)
    return err

cdef CUresult _cuModuleLoad(CUmodule* module, const char* fname) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuModuleLoad
    cuPythonInit()
    if __cuModuleLoad == NULL:
        with gil:
            raise RuntimeError('Function "cuModuleLoad" not found')
    err = (<CUresult (*)(CUmodule*, const char*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuModuleLoad)(module, fname)
    return err

cdef CUresult _cuModuleLoadData(CUmodule* module, const void* image) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuModuleLoadData
    cuPythonInit()
    if __cuModuleLoadData == NULL:
        with gil:
            raise RuntimeError('Function "cuModuleLoadData" not found')
    err = (<CUresult (*)(CUmodule*, const void*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuModuleLoadData)(module, image)
    return err

cdef CUresult _cuModuleLoadDataEx(CUmodule* module, const void* image, unsigned int numOptions, CUjit_option* options, void** optionValues) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuModuleLoadDataEx
    cuPythonInit()
    if __cuModuleLoadDataEx == NULL:
        with gil:
            raise RuntimeError('Function "cuModuleLoadDataEx" not found')
    err = (<CUresult (*)(CUmodule*, const void*, unsigned int, CUjit_option*, void**) except ?CUDA_ERROR_NOT_FOUND nogil> __cuModuleLoadDataEx)(module, image, numOptions, options, optionValues)
    return err

cdef CUresult _cuModuleLoadFatBinary(CUmodule* module, const void* fatCubin) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuModuleLoadFatBinary
    cuPythonInit()
    if __cuModuleLoadFatBinary == NULL:
        with gil:
            raise RuntimeError('Function "cuModuleLoadFatBinary" not found')
    err = (<CUresult (*)(CUmodule*, const void*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuModuleLoadFatBinary)(module, fatCubin)
    return err

cdef CUresult _cuModuleUnload(CUmodule hmod) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuModuleUnload
    cuPythonInit()
    if __cuModuleUnload == NULL:
        with gil:
            raise RuntimeError('Function "cuModuleUnload" not found')
    err = (<CUresult (*)(CUmodule) except ?CUDA_ERROR_NOT_FOUND nogil> __cuModuleUnload)(hmod)
    return err

cdef CUresult _cuModuleGetLoadingMode(CUmoduleLoadingMode* mode) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuModuleGetLoadingMode
    cuPythonInit()
    if __cuModuleGetLoadingMode == NULL:
        with gil:
            raise RuntimeError('Function "cuModuleGetLoadingMode" not found')
    err = (<CUresult (*)(CUmoduleLoadingMode*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuModuleGetLoadingMode)(mode)
    return err

cdef CUresult _cuModuleGetFunction(CUfunction* hfunc, CUmodule hmod, const char* name) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuModuleGetFunction
    cuPythonInit()
    if __cuModuleGetFunction == NULL:
        with gil:
            raise RuntimeError('Function "cuModuleGetFunction" not found')
    err = (<CUresult (*)(CUfunction*, CUmodule, const char*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuModuleGetFunction)(hfunc, hmod, name)
    return err

cdef CUresult _cuModuleGetFunctionCount(unsigned int* count, CUmodule mod) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuModuleGetFunctionCount
    cuPythonInit()
    if __cuModuleGetFunctionCount == NULL:
        with gil:
            raise RuntimeError('Function "cuModuleGetFunctionCount" not found')
    err = (<CUresult (*)(unsigned int*, CUmodule) except ?CUDA_ERROR_NOT_FOUND nogil> __cuModuleGetFunctionCount)(count, mod)
    return err

cdef CUresult _cuModuleEnumerateFunctions(CUfunction* functions, unsigned int numFunctions, CUmodule mod) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuModuleEnumerateFunctions
    cuPythonInit()
    if __cuModuleEnumerateFunctions == NULL:
        with gil:
            raise RuntimeError('Function "cuModuleEnumerateFunctions" not found')
    err = (<CUresult (*)(CUfunction*, unsigned int, CUmodule) except ?CUDA_ERROR_NOT_FOUND nogil> __cuModuleEnumerateFunctions)(functions, numFunctions, mod)
    return err

cdef CUresult _cuModuleGetGlobal_v2(CUdeviceptr* dptr, size_t* numbytes, CUmodule hmod, const char* name) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuModuleGetGlobal_v2
    cuPythonInit()
    if __cuModuleGetGlobal_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuModuleGetGlobal_v2" not found')
    err = (<CUresult (*)(CUdeviceptr*, size_t*, CUmodule, const char*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuModuleGetGlobal_v2)(dptr, numbytes, hmod, name)
    return err

cdef CUresult _cuLinkCreate_v2(unsigned int numOptions, CUjit_option* options, void** optionValues, CUlinkState* stateOut) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuLinkCreate_v2
    cuPythonInit()
    if __cuLinkCreate_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuLinkCreate_v2" not found')
    err = (<CUresult (*)(unsigned int, CUjit_option*, void**, CUlinkState*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuLinkCreate_v2)(numOptions, options, optionValues, stateOut)
    return err

cdef CUresult _cuLinkAddData_v2(CUlinkState state, CUjitInputType typename, void* data, size_t size, const char* name, unsigned int numOptions, CUjit_option* options, void** optionValues) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuLinkAddData_v2
    cuPythonInit()
    if __cuLinkAddData_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuLinkAddData_v2" not found')
    err = (<CUresult (*)(CUlinkState, CUjitInputType, void*, size_t, const char*, unsigned int, CUjit_option*, void**) except ?CUDA_ERROR_NOT_FOUND nogil> __cuLinkAddData_v2)(state, typename, data, size, name, numOptions, options, optionValues)
    return err

cdef CUresult _cuLinkAddFile_v2(CUlinkState state, CUjitInputType typename, const char* path, unsigned int numOptions, CUjit_option* options, void** optionValues) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuLinkAddFile_v2
    cuPythonInit()
    if __cuLinkAddFile_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuLinkAddFile_v2" not found')
    err = (<CUresult (*)(CUlinkState, CUjitInputType, const char*, unsigned int, CUjit_option*, void**) except ?CUDA_ERROR_NOT_FOUND nogil> __cuLinkAddFile_v2)(state, typename, path, numOptions, options, optionValues)
    return err

cdef CUresult _cuLinkComplete(CUlinkState state, void** cubinOut, size_t* sizeOut) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuLinkComplete
    cuPythonInit()
    if __cuLinkComplete == NULL:
        with gil:
            raise RuntimeError('Function "cuLinkComplete" not found')
    err = (<CUresult (*)(CUlinkState, void**, size_t*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuLinkComplete)(state, cubinOut, sizeOut)
    return err

cdef CUresult _cuLinkDestroy(CUlinkState state) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuLinkDestroy
    cuPythonInit()
    if __cuLinkDestroy == NULL:
        with gil:
            raise RuntimeError('Function "cuLinkDestroy" not found')
    err = (<CUresult (*)(CUlinkState) except ?CUDA_ERROR_NOT_FOUND nogil> __cuLinkDestroy)(state)
    return err

cdef CUresult _cuModuleGetTexRef(CUtexref* pTexRef, CUmodule hmod, const char* name) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuModuleGetTexRef
    cuPythonInit()
    if __cuModuleGetTexRef == NULL:
        with gil:
            raise RuntimeError('Function "cuModuleGetTexRef" not found')
    err = (<CUresult (*)(CUtexref*, CUmodule, const char*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuModuleGetTexRef)(pTexRef, hmod, name)
    return err

cdef CUresult _cuModuleGetSurfRef(CUsurfref* pSurfRef, CUmodule hmod, const char* name) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuModuleGetSurfRef
    cuPythonInit()
    if __cuModuleGetSurfRef == NULL:
        with gil:
            raise RuntimeError('Function "cuModuleGetSurfRef" not found')
    err = (<CUresult (*)(CUsurfref*, CUmodule, const char*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuModuleGetSurfRef)(pSurfRef, hmod, name)
    return err

cdef CUresult _cuLibraryLoadData(CUlibrary* library, const void* code, CUjit_option* jitOptions, void** jitOptionsValues, unsigned int numJitOptions, CUlibraryOption* libraryOptions, void** libraryOptionValues, unsigned int numLibraryOptions) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuLibraryLoadData
    cuPythonInit()
    if __cuLibraryLoadData == NULL:
        with gil:
            raise RuntimeError('Function "cuLibraryLoadData" not found')
    err = (<CUresult (*)(CUlibrary*, const void*, CUjit_option*, void**, unsigned int, CUlibraryOption*, void**, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuLibraryLoadData)(library, code, jitOptions, jitOptionsValues, numJitOptions, libraryOptions, libraryOptionValues, numLibraryOptions)
    return err

cdef CUresult _cuLibraryLoadFromFile(CUlibrary* library, const char* fileName, CUjit_option* jitOptions, void** jitOptionsValues, unsigned int numJitOptions, CUlibraryOption* libraryOptions, void** libraryOptionValues, unsigned int numLibraryOptions) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuLibraryLoadFromFile
    cuPythonInit()
    if __cuLibraryLoadFromFile == NULL:
        with gil:
            raise RuntimeError('Function "cuLibraryLoadFromFile" not found')
    err = (<CUresult (*)(CUlibrary*, const char*, CUjit_option*, void**, unsigned int, CUlibraryOption*, void**, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuLibraryLoadFromFile)(library, fileName, jitOptions, jitOptionsValues, numJitOptions, libraryOptions, libraryOptionValues, numLibraryOptions)
    return err

cdef CUresult _cuLibraryUnload(CUlibrary library) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuLibraryUnload
    cuPythonInit()
    if __cuLibraryUnload == NULL:
        with gil:
            raise RuntimeError('Function "cuLibraryUnload" not found')
    err = (<CUresult (*)(CUlibrary) except ?CUDA_ERROR_NOT_FOUND nogil> __cuLibraryUnload)(library)
    return err

cdef CUresult _cuLibraryGetKernel(CUkernel* pKernel, CUlibrary library, const char* name) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuLibraryGetKernel
    cuPythonInit()
    if __cuLibraryGetKernel == NULL:
        with gil:
            raise RuntimeError('Function "cuLibraryGetKernel" not found')
    err = (<CUresult (*)(CUkernel*, CUlibrary, const char*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuLibraryGetKernel)(pKernel, library, name)
    return err

cdef CUresult _cuLibraryGetKernelCount(unsigned int* count, CUlibrary lib) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuLibraryGetKernelCount
    cuPythonInit()
    if __cuLibraryGetKernelCount == NULL:
        with gil:
            raise RuntimeError('Function "cuLibraryGetKernelCount" not found')
    err = (<CUresult (*)(unsigned int*, CUlibrary) except ?CUDA_ERROR_NOT_FOUND nogil> __cuLibraryGetKernelCount)(count, lib)
    return err

cdef CUresult _cuLibraryEnumerateKernels(CUkernel* kernels, unsigned int numKernels, CUlibrary lib) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuLibraryEnumerateKernels
    cuPythonInit()
    if __cuLibraryEnumerateKernels == NULL:
        with gil:
            raise RuntimeError('Function "cuLibraryEnumerateKernels" not found')
    err = (<CUresult (*)(CUkernel*, unsigned int, CUlibrary) except ?CUDA_ERROR_NOT_FOUND nogil> __cuLibraryEnumerateKernels)(kernels, numKernels, lib)
    return err

cdef CUresult _cuLibraryGetModule(CUmodule* pMod, CUlibrary library) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuLibraryGetModule
    cuPythonInit()
    if __cuLibraryGetModule == NULL:
        with gil:
            raise RuntimeError('Function "cuLibraryGetModule" not found')
    err = (<CUresult (*)(CUmodule*, CUlibrary) except ?CUDA_ERROR_NOT_FOUND nogil> __cuLibraryGetModule)(pMod, library)
    return err

cdef CUresult _cuKernelGetFunction(CUfunction* pFunc, CUkernel kernel) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuKernelGetFunction
    cuPythonInit()
    if __cuKernelGetFunction == NULL:
        with gil:
            raise RuntimeError('Function "cuKernelGetFunction" not found')
    err = (<CUresult (*)(CUfunction*, CUkernel) except ?CUDA_ERROR_NOT_FOUND nogil> __cuKernelGetFunction)(pFunc, kernel)
    return err

cdef CUresult _cuKernelGetLibrary(CUlibrary* pLib, CUkernel kernel) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuKernelGetLibrary
    cuPythonInit()
    if __cuKernelGetLibrary == NULL:
        with gil:
            raise RuntimeError('Function "cuKernelGetLibrary" not found')
    err = (<CUresult (*)(CUlibrary*, CUkernel) except ?CUDA_ERROR_NOT_FOUND nogil> __cuKernelGetLibrary)(pLib, kernel)
    return err

cdef CUresult _cuLibraryGetGlobal(CUdeviceptr* dptr, size_t* numbytes, CUlibrary library, const char* name) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuLibraryGetGlobal
    cuPythonInit()
    if __cuLibraryGetGlobal == NULL:
        with gil:
            raise RuntimeError('Function "cuLibraryGetGlobal" not found')
    err = (<CUresult (*)(CUdeviceptr*, size_t*, CUlibrary, const char*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuLibraryGetGlobal)(dptr, numbytes, library, name)
    return err

cdef CUresult _cuLibraryGetManaged(CUdeviceptr* dptr, size_t* numbytes, CUlibrary library, const char* name) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuLibraryGetManaged
    cuPythonInit()
    if __cuLibraryGetManaged == NULL:
        with gil:
            raise RuntimeError('Function "cuLibraryGetManaged" not found')
    err = (<CUresult (*)(CUdeviceptr*, size_t*, CUlibrary, const char*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuLibraryGetManaged)(dptr, numbytes, library, name)
    return err

cdef CUresult _cuLibraryGetUnifiedFunction(void** fptr, CUlibrary library, const char* symbol) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuLibraryGetUnifiedFunction
    cuPythonInit()
    if __cuLibraryGetUnifiedFunction == NULL:
        with gil:
            raise RuntimeError('Function "cuLibraryGetUnifiedFunction" not found')
    err = (<CUresult (*)(void**, CUlibrary, const char*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuLibraryGetUnifiedFunction)(fptr, library, symbol)
    return err

cdef CUresult _cuKernelGetAttribute(int* pi, CUfunction_attribute attrib, CUkernel kernel, CUdevice dev) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuKernelGetAttribute
    cuPythonInit()
    if __cuKernelGetAttribute == NULL:
        with gil:
            raise RuntimeError('Function "cuKernelGetAttribute" not found')
    err = (<CUresult (*)(int*, CUfunction_attribute, CUkernel, CUdevice) except ?CUDA_ERROR_NOT_FOUND nogil> __cuKernelGetAttribute)(pi, attrib, kernel, dev)
    return err

cdef CUresult _cuKernelSetAttribute(CUfunction_attribute attrib, int val, CUkernel kernel, CUdevice dev) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuKernelSetAttribute
    cuPythonInit()
    if __cuKernelSetAttribute == NULL:
        with gil:
            raise RuntimeError('Function "cuKernelSetAttribute" not found')
    err = (<CUresult (*)(CUfunction_attribute, int, CUkernel, CUdevice) except ?CUDA_ERROR_NOT_FOUND nogil> __cuKernelSetAttribute)(attrib, val, kernel, dev)
    return err

cdef CUresult _cuKernelSetCacheConfig(CUkernel kernel, CUfunc_cache config, CUdevice dev) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuKernelSetCacheConfig
    cuPythonInit()
    if __cuKernelSetCacheConfig == NULL:
        with gil:
            raise RuntimeError('Function "cuKernelSetCacheConfig" not found')
    err = (<CUresult (*)(CUkernel, CUfunc_cache, CUdevice) except ?CUDA_ERROR_NOT_FOUND nogil> __cuKernelSetCacheConfig)(kernel, config, dev)
    return err

cdef CUresult _cuKernelGetName(const char** name, CUkernel hfunc) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuKernelGetName
    cuPythonInit()
    if __cuKernelGetName == NULL:
        with gil:
            raise RuntimeError('Function "cuKernelGetName" not found')
    err = (<CUresult (*)(const char**, CUkernel) except ?CUDA_ERROR_NOT_FOUND nogil> __cuKernelGetName)(name, hfunc)
    return err

cdef CUresult _cuKernelGetParamInfo(CUkernel kernel, size_t paramIndex, size_t* paramOffset, size_t* paramSize) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuKernelGetParamInfo
    cuPythonInit()
    if __cuKernelGetParamInfo == NULL:
        with gil:
            raise RuntimeError('Function "cuKernelGetParamInfo" not found')
    err = (<CUresult (*)(CUkernel, size_t, size_t*, size_t*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuKernelGetParamInfo)(kernel, paramIndex, paramOffset, paramSize)
    return err

cdef CUresult _cuMemGetInfo_v2(size_t* free, size_t* total) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemGetInfo_v2
    cuPythonInit()
    if __cuMemGetInfo_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuMemGetInfo_v2" not found')
    err = (<CUresult (*)(size_t*, size_t*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemGetInfo_v2)(free, total)
    return err

cdef CUresult _cuMemAlloc_v2(CUdeviceptr* dptr, size_t bytesize) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemAlloc_v2
    cuPythonInit()
    if __cuMemAlloc_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuMemAlloc_v2" not found')
    err = (<CUresult (*)(CUdeviceptr*, size_t) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemAlloc_v2)(dptr, bytesize)
    return err

cdef CUresult _cuMemAllocPitch_v2(CUdeviceptr* dptr, size_t* pPitch, size_t WidthInBytes, size_t Height, unsigned int ElementSizeBytes) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemAllocPitch_v2
    cuPythonInit()
    if __cuMemAllocPitch_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuMemAllocPitch_v2" not found')
    err = (<CUresult (*)(CUdeviceptr*, size_t*, size_t, size_t, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemAllocPitch_v2)(dptr, pPitch, WidthInBytes, Height, ElementSizeBytes)
    return err

cdef CUresult _cuMemFree_v2(CUdeviceptr dptr) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemFree_v2
    cuPythonInit()
    if __cuMemFree_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuMemFree_v2" not found')
    err = (<CUresult (*)(CUdeviceptr) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemFree_v2)(dptr)
    return err

cdef CUresult _cuMemGetAddressRange_v2(CUdeviceptr* pbase, size_t* psize, CUdeviceptr dptr) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemGetAddressRange_v2
    cuPythonInit()
    if __cuMemGetAddressRange_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuMemGetAddressRange_v2" not found')
    err = (<CUresult (*)(CUdeviceptr*, size_t*, CUdeviceptr) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemGetAddressRange_v2)(pbase, psize, dptr)
    return err

cdef CUresult _cuMemAllocHost_v2(void** pp, size_t bytesize) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemAllocHost_v2
    cuPythonInit()
    if __cuMemAllocHost_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuMemAllocHost_v2" not found')
    err = (<CUresult (*)(void**, size_t) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemAllocHost_v2)(pp, bytesize)
    return err

cdef CUresult _cuMemFreeHost(void* p) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemFreeHost
    cuPythonInit()
    if __cuMemFreeHost == NULL:
        with gil:
            raise RuntimeError('Function "cuMemFreeHost" not found')
    err = (<CUresult (*)(void*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemFreeHost)(p)
    return err

cdef CUresult _cuMemHostAlloc(void** pp, size_t bytesize, unsigned int Flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemHostAlloc
    cuPythonInit()
    if __cuMemHostAlloc == NULL:
        with gil:
            raise RuntimeError('Function "cuMemHostAlloc" not found')
    err = (<CUresult (*)(void**, size_t, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemHostAlloc)(pp, bytesize, Flags)
    return err

cdef CUresult _cuMemHostGetDevicePointer_v2(CUdeviceptr* pdptr, void* p, unsigned int Flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemHostGetDevicePointer_v2
    cuPythonInit()
    if __cuMemHostGetDevicePointer_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuMemHostGetDevicePointer_v2" not found')
    err = (<CUresult (*)(CUdeviceptr*, void*, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemHostGetDevicePointer_v2)(pdptr, p, Flags)
    return err

cdef CUresult _cuMemHostGetFlags(unsigned int* pFlags, void* p) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemHostGetFlags
    cuPythonInit()
    if __cuMemHostGetFlags == NULL:
        with gil:
            raise RuntimeError('Function "cuMemHostGetFlags" not found')
    err = (<CUresult (*)(unsigned int*, void*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemHostGetFlags)(pFlags, p)
    return err

cdef CUresult _cuMemAllocManaged(CUdeviceptr* dptr, size_t bytesize, unsigned int flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemAllocManaged
    cuPythonInit()
    if __cuMemAllocManaged == NULL:
        with gil:
            raise RuntimeError('Function "cuMemAllocManaged" not found')
    err = (<CUresult (*)(CUdeviceptr*, size_t, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemAllocManaged)(dptr, bytesize, flags)
    return err

cdef CUresult _cuDeviceRegisterAsyncNotification(CUdevice device, CUasyncCallback callbackFunc, void* userData, CUasyncCallbackHandle* callback) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuDeviceRegisterAsyncNotification
    cuPythonInit()
    if __cuDeviceRegisterAsyncNotification == NULL:
        with gil:
            raise RuntimeError('Function "cuDeviceRegisterAsyncNotification" not found')
    err = (<CUresult (*)(CUdevice, CUasyncCallback, void*, CUasyncCallbackHandle*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuDeviceRegisterAsyncNotification)(device, callbackFunc, userData, callback)
    return err

cdef CUresult _cuDeviceUnregisterAsyncNotification(CUdevice device, CUasyncCallbackHandle callback) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuDeviceUnregisterAsyncNotification
    cuPythonInit()
    if __cuDeviceUnregisterAsyncNotification == NULL:
        with gil:
            raise RuntimeError('Function "cuDeviceUnregisterAsyncNotification" not found')
    err = (<CUresult (*)(CUdevice, CUasyncCallbackHandle) except ?CUDA_ERROR_NOT_FOUND nogil> __cuDeviceUnregisterAsyncNotification)(device, callback)
    return err

cdef CUresult _cuDeviceGetByPCIBusId(CUdevice* dev, const char* pciBusId) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuDeviceGetByPCIBusId
    cuPythonInit()
    if __cuDeviceGetByPCIBusId == NULL:
        with gil:
            raise RuntimeError('Function "cuDeviceGetByPCIBusId" not found')
    err = (<CUresult (*)(CUdevice*, const char*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuDeviceGetByPCIBusId)(dev, pciBusId)
    return err

cdef CUresult _cuDeviceGetPCIBusId(char* pciBusId, int length, CUdevice dev) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuDeviceGetPCIBusId
    cuPythonInit()
    if __cuDeviceGetPCIBusId == NULL:
        with gil:
            raise RuntimeError('Function "cuDeviceGetPCIBusId" not found')
    err = (<CUresult (*)(char*, int, CUdevice) except ?CUDA_ERROR_NOT_FOUND nogil> __cuDeviceGetPCIBusId)(pciBusId, length, dev)
    return err

cdef CUresult _cuIpcGetEventHandle(CUipcEventHandle* pHandle, CUevent event) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuIpcGetEventHandle
    cuPythonInit()
    if __cuIpcGetEventHandle == NULL:
        with gil:
            raise RuntimeError('Function "cuIpcGetEventHandle" not found')
    err = (<CUresult (*)(CUipcEventHandle*, CUevent) except ?CUDA_ERROR_NOT_FOUND nogil> __cuIpcGetEventHandle)(pHandle, event)
    return err

cdef CUresult _cuIpcOpenEventHandle(CUevent* phEvent, CUipcEventHandle handle) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuIpcOpenEventHandle
    cuPythonInit()
    if __cuIpcOpenEventHandle == NULL:
        with gil:
            raise RuntimeError('Function "cuIpcOpenEventHandle" not found')
    err = (<CUresult (*)(CUevent*, CUipcEventHandle) except ?CUDA_ERROR_NOT_FOUND nogil> __cuIpcOpenEventHandle)(phEvent, handle)
    return err

cdef CUresult _cuIpcGetMemHandle(CUipcMemHandle* pHandle, CUdeviceptr dptr) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuIpcGetMemHandle
    cuPythonInit()
    if __cuIpcGetMemHandle == NULL:
        with gil:
            raise RuntimeError('Function "cuIpcGetMemHandle" not found')
    err = (<CUresult (*)(CUipcMemHandle*, CUdeviceptr) except ?CUDA_ERROR_NOT_FOUND nogil> __cuIpcGetMemHandle)(pHandle, dptr)
    return err

cdef CUresult _cuIpcOpenMemHandle_v2(CUdeviceptr* pdptr, CUipcMemHandle handle, unsigned int Flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuIpcOpenMemHandle_v2
    cuPythonInit()
    if __cuIpcOpenMemHandle_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuIpcOpenMemHandle_v2" not found')
    err = (<CUresult (*)(CUdeviceptr*, CUipcMemHandle, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuIpcOpenMemHandle_v2)(pdptr, handle, Flags)
    return err

cdef CUresult _cuIpcCloseMemHandle(CUdeviceptr dptr) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuIpcCloseMemHandle
    cuPythonInit()
    if __cuIpcCloseMemHandle == NULL:
        with gil:
            raise RuntimeError('Function "cuIpcCloseMemHandle" not found')
    err = (<CUresult (*)(CUdeviceptr) except ?CUDA_ERROR_NOT_FOUND nogil> __cuIpcCloseMemHandle)(dptr)
    return err

cdef CUresult _cuMemHostRegister_v2(void* p, size_t bytesize, unsigned int Flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemHostRegister_v2
    cuPythonInit()
    if __cuMemHostRegister_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuMemHostRegister_v2" not found')
    err = (<CUresult (*)(void*, size_t, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemHostRegister_v2)(p, bytesize, Flags)
    return err

cdef CUresult _cuMemHostUnregister(void* p) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemHostUnregister
    cuPythonInit()
    if __cuMemHostUnregister == NULL:
        with gil:
            raise RuntimeError('Function "cuMemHostUnregister" not found')
    err = (<CUresult (*)(void*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemHostUnregister)(p)
    return err

cdef CUresult _cuMemcpy(CUdeviceptr dst, CUdeviceptr src, size_t ByteCount) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemcpy
    cuPythonInit()
    if __cuMemcpy == NULL:
        with gil:
            raise RuntimeError('Function "cuMemcpy" not found')
    err = (<CUresult (*)(CUdeviceptr, CUdeviceptr, size_t) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemcpy)(dst, src, ByteCount)
    return err

cdef CUresult _cuMemcpyPeer(CUdeviceptr dstDevice, CUcontext dstContext, CUdeviceptr srcDevice, CUcontext srcContext, size_t ByteCount) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemcpyPeer
    cuPythonInit()
    if __cuMemcpyPeer == NULL:
        with gil:
            raise RuntimeError('Function "cuMemcpyPeer" not found')
    err = (<CUresult (*)(CUdeviceptr, CUcontext, CUdeviceptr, CUcontext, size_t) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemcpyPeer)(dstDevice, dstContext, srcDevice, srcContext, ByteCount)
    return err

cdef CUresult _cuMemcpyHtoD_v2(CUdeviceptr dstDevice, const void* srcHost, size_t ByteCount) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemcpyHtoD_v2
    cuPythonInit()
    if __cuMemcpyHtoD_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuMemcpyHtoD_v2" not found')
    err = (<CUresult (*)(CUdeviceptr, const void*, size_t) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemcpyHtoD_v2)(dstDevice, srcHost, ByteCount)
    return err

cdef CUresult _cuMemcpyDtoH_v2(void* dstHost, CUdeviceptr srcDevice, size_t ByteCount) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemcpyDtoH_v2
    cuPythonInit()
    if __cuMemcpyDtoH_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuMemcpyDtoH_v2" not found')
    err = (<CUresult (*)(void*, CUdeviceptr, size_t) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemcpyDtoH_v2)(dstHost, srcDevice, ByteCount)
    return err

cdef CUresult _cuMemcpyDtoD_v2(CUdeviceptr dstDevice, CUdeviceptr srcDevice, size_t ByteCount) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemcpyDtoD_v2
    cuPythonInit()
    if __cuMemcpyDtoD_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuMemcpyDtoD_v2" not found')
    err = (<CUresult (*)(CUdeviceptr, CUdeviceptr, size_t) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemcpyDtoD_v2)(dstDevice, srcDevice, ByteCount)
    return err

cdef CUresult _cuMemcpyDtoA_v2(CUarray dstArray, size_t dstOffset, CUdeviceptr srcDevice, size_t ByteCount) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemcpyDtoA_v2
    cuPythonInit()
    if __cuMemcpyDtoA_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuMemcpyDtoA_v2" not found')
    err = (<CUresult (*)(CUarray, size_t, CUdeviceptr, size_t) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemcpyDtoA_v2)(dstArray, dstOffset, srcDevice, ByteCount)
    return err

cdef CUresult _cuMemcpyAtoD_v2(CUdeviceptr dstDevice, CUarray srcArray, size_t srcOffset, size_t ByteCount) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemcpyAtoD_v2
    cuPythonInit()
    if __cuMemcpyAtoD_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuMemcpyAtoD_v2" not found')
    err = (<CUresult (*)(CUdeviceptr, CUarray, size_t, size_t) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemcpyAtoD_v2)(dstDevice, srcArray, srcOffset, ByteCount)
    return err

cdef CUresult _cuMemcpyHtoA_v2(CUarray dstArray, size_t dstOffset, const void* srcHost, size_t ByteCount) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemcpyHtoA_v2
    cuPythonInit()
    if __cuMemcpyHtoA_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuMemcpyHtoA_v2" not found')
    err = (<CUresult (*)(CUarray, size_t, const void*, size_t) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemcpyHtoA_v2)(dstArray, dstOffset, srcHost, ByteCount)
    return err

cdef CUresult _cuMemcpyAtoH_v2(void* dstHost, CUarray srcArray, size_t srcOffset, size_t ByteCount) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemcpyAtoH_v2
    cuPythonInit()
    if __cuMemcpyAtoH_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuMemcpyAtoH_v2" not found')
    err = (<CUresult (*)(void*, CUarray, size_t, size_t) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemcpyAtoH_v2)(dstHost, srcArray, srcOffset, ByteCount)
    return err

cdef CUresult _cuMemcpyAtoA_v2(CUarray dstArray, size_t dstOffset, CUarray srcArray, size_t srcOffset, size_t ByteCount) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemcpyAtoA_v2
    cuPythonInit()
    if __cuMemcpyAtoA_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuMemcpyAtoA_v2" not found')
    err = (<CUresult (*)(CUarray, size_t, CUarray, size_t, size_t) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemcpyAtoA_v2)(dstArray, dstOffset, srcArray, srcOffset, ByteCount)
    return err

cdef CUresult _cuMemcpy2D_v2(const CUDA_MEMCPY2D* pCopy) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemcpy2D_v2
    cuPythonInit()
    if __cuMemcpy2D_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuMemcpy2D_v2" not found')
    err = (<CUresult (*)(const CUDA_MEMCPY2D*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemcpy2D_v2)(pCopy)
    return err

cdef CUresult _cuMemcpy2DUnaligned_v2(const CUDA_MEMCPY2D* pCopy) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemcpy2DUnaligned_v2
    cuPythonInit()
    if __cuMemcpy2DUnaligned_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuMemcpy2DUnaligned_v2" not found')
    err = (<CUresult (*)(const CUDA_MEMCPY2D*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemcpy2DUnaligned_v2)(pCopy)
    return err

cdef CUresult _cuMemcpy3D_v2(const CUDA_MEMCPY3D* pCopy) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemcpy3D_v2
    cuPythonInit()
    if __cuMemcpy3D_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuMemcpy3D_v2" not found')
    err = (<CUresult (*)(const CUDA_MEMCPY3D*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemcpy3D_v2)(pCopy)
    return err

cdef CUresult _cuMemcpy3DPeer(const CUDA_MEMCPY3D_PEER* pCopy) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemcpy3DPeer
    cuPythonInit()
    if __cuMemcpy3DPeer == NULL:
        with gil:
            raise RuntimeError('Function "cuMemcpy3DPeer" not found')
    err = (<CUresult (*)(const CUDA_MEMCPY3D_PEER*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemcpy3DPeer)(pCopy)
    return err

cdef CUresult _cuMemcpyAsync(CUdeviceptr dst, CUdeviceptr src, size_t ByteCount, CUstream hStream) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemcpyAsync
    cuPythonInit()
    if __cuMemcpyAsync == NULL:
        with gil:
            raise RuntimeError('Function "cuMemcpyAsync" not found')
    err = (<CUresult (*)(CUdeviceptr, CUdeviceptr, size_t, CUstream) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemcpyAsync)(dst, src, ByteCount, hStream)
    return err

cdef CUresult _cuMemcpyPeerAsync(CUdeviceptr dstDevice, CUcontext dstContext, CUdeviceptr srcDevice, CUcontext srcContext, size_t ByteCount, CUstream hStream) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemcpyPeerAsync
    cuPythonInit()
    if __cuMemcpyPeerAsync == NULL:
        with gil:
            raise RuntimeError('Function "cuMemcpyPeerAsync" not found')
    err = (<CUresult (*)(CUdeviceptr, CUcontext, CUdeviceptr, CUcontext, size_t, CUstream) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemcpyPeerAsync)(dstDevice, dstContext, srcDevice, srcContext, ByteCount, hStream)
    return err

cdef CUresult _cuMemcpyHtoDAsync_v2(CUdeviceptr dstDevice, const void* srcHost, size_t ByteCount, CUstream hStream) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemcpyHtoDAsync_v2
    cuPythonInit()
    if __cuMemcpyHtoDAsync_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuMemcpyHtoDAsync_v2" not found')
    err = (<CUresult (*)(CUdeviceptr, const void*, size_t, CUstream) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemcpyHtoDAsync_v2)(dstDevice, srcHost, ByteCount, hStream)
    return err

cdef CUresult _cuMemcpyDtoHAsync_v2(void* dstHost, CUdeviceptr srcDevice, size_t ByteCount, CUstream hStream) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemcpyDtoHAsync_v2
    cuPythonInit()
    if __cuMemcpyDtoHAsync_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuMemcpyDtoHAsync_v2" not found')
    err = (<CUresult (*)(void*, CUdeviceptr, size_t, CUstream) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemcpyDtoHAsync_v2)(dstHost, srcDevice, ByteCount, hStream)
    return err

cdef CUresult _cuMemcpyDtoDAsync_v2(CUdeviceptr dstDevice, CUdeviceptr srcDevice, size_t ByteCount, CUstream hStream) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemcpyDtoDAsync_v2
    cuPythonInit()
    if __cuMemcpyDtoDAsync_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuMemcpyDtoDAsync_v2" not found')
    err = (<CUresult (*)(CUdeviceptr, CUdeviceptr, size_t, CUstream) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemcpyDtoDAsync_v2)(dstDevice, srcDevice, ByteCount, hStream)
    return err

cdef CUresult _cuMemcpyHtoAAsync_v2(CUarray dstArray, size_t dstOffset, const void* srcHost, size_t ByteCount, CUstream hStream) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemcpyHtoAAsync_v2
    cuPythonInit()
    if __cuMemcpyHtoAAsync_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuMemcpyHtoAAsync_v2" not found')
    err = (<CUresult (*)(CUarray, size_t, const void*, size_t, CUstream) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemcpyHtoAAsync_v2)(dstArray, dstOffset, srcHost, ByteCount, hStream)
    return err

cdef CUresult _cuMemcpyAtoHAsync_v2(void* dstHost, CUarray srcArray, size_t srcOffset, size_t ByteCount, CUstream hStream) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemcpyAtoHAsync_v2
    cuPythonInit()
    if __cuMemcpyAtoHAsync_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuMemcpyAtoHAsync_v2" not found')
    err = (<CUresult (*)(void*, CUarray, size_t, size_t, CUstream) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemcpyAtoHAsync_v2)(dstHost, srcArray, srcOffset, ByteCount, hStream)
    return err

cdef CUresult _cuMemcpy2DAsync_v2(const CUDA_MEMCPY2D* pCopy, CUstream hStream) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemcpy2DAsync_v2
    cuPythonInit()
    if __cuMemcpy2DAsync_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuMemcpy2DAsync_v2" not found')
    err = (<CUresult (*)(const CUDA_MEMCPY2D*, CUstream) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemcpy2DAsync_v2)(pCopy, hStream)
    return err

cdef CUresult _cuMemcpy3DAsync_v2(const CUDA_MEMCPY3D* pCopy, CUstream hStream) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemcpy3DAsync_v2
    cuPythonInit()
    if __cuMemcpy3DAsync_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuMemcpy3DAsync_v2" not found')
    err = (<CUresult (*)(const CUDA_MEMCPY3D*, CUstream) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemcpy3DAsync_v2)(pCopy, hStream)
    return err

cdef CUresult _cuMemcpy3DPeerAsync(const CUDA_MEMCPY3D_PEER* pCopy, CUstream hStream) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemcpy3DPeerAsync
    cuPythonInit()
    if __cuMemcpy3DPeerAsync == NULL:
        with gil:
            raise RuntimeError('Function "cuMemcpy3DPeerAsync" not found')
    err = (<CUresult (*)(const CUDA_MEMCPY3D_PEER*, CUstream) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemcpy3DPeerAsync)(pCopy, hStream)
    return err

cdef CUresult _cuMemcpyBatchAsync(CUdeviceptr* dsts, CUdeviceptr* srcs, size_t* sizes, size_t count, CUmemcpyAttributes* attrs, size_t* attrsIdxs, size_t numAttrs, size_t* failIdx, CUstream hStream) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemcpyBatchAsync
    cuPythonInit()
    if __cuMemcpyBatchAsync == NULL:
        with gil:
            raise RuntimeError('Function "cuMemcpyBatchAsync" not found')
    err = (<CUresult (*)(CUdeviceptr*, CUdeviceptr*, size_t*, size_t, CUmemcpyAttributes*, size_t*, size_t, size_t*, CUstream) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemcpyBatchAsync)(dsts, srcs, sizes, count, attrs, attrsIdxs, numAttrs, failIdx, hStream)
    return err

cdef CUresult _cuMemcpy3DBatchAsync(size_t numOps, CUDA_MEMCPY3D_BATCH_OP* opList, size_t* failIdx, unsigned long long flags, CUstream hStream) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemcpy3DBatchAsync
    cuPythonInit()
    if __cuMemcpy3DBatchAsync == NULL:
        with gil:
            raise RuntimeError('Function "cuMemcpy3DBatchAsync" not found')
    err = (<CUresult (*)(size_t, CUDA_MEMCPY3D_BATCH_OP*, size_t*, unsigned long long, CUstream) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemcpy3DBatchAsync)(numOps, opList, failIdx, flags, hStream)
    return err

cdef CUresult _cuMemsetD8_v2(CUdeviceptr dstDevice, unsigned char uc, size_t N) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemsetD8_v2
    cuPythonInit()
    if __cuMemsetD8_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuMemsetD8_v2" not found')
    err = (<CUresult (*)(CUdeviceptr, unsigned char, size_t) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemsetD8_v2)(dstDevice, uc, N)
    return err

cdef CUresult _cuMemsetD16_v2(CUdeviceptr dstDevice, unsigned short us, size_t N) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemsetD16_v2
    cuPythonInit()
    if __cuMemsetD16_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuMemsetD16_v2" not found')
    err = (<CUresult (*)(CUdeviceptr, unsigned short, size_t) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemsetD16_v2)(dstDevice, us, N)
    return err

cdef CUresult _cuMemsetD32_v2(CUdeviceptr dstDevice, unsigned int ui, size_t N) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemsetD32_v2
    cuPythonInit()
    if __cuMemsetD32_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuMemsetD32_v2" not found')
    err = (<CUresult (*)(CUdeviceptr, unsigned int, size_t) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemsetD32_v2)(dstDevice, ui, N)
    return err

cdef CUresult _cuMemsetD2D8_v2(CUdeviceptr dstDevice, size_t dstPitch, unsigned char uc, size_t Width, size_t Height) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemsetD2D8_v2
    cuPythonInit()
    if __cuMemsetD2D8_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuMemsetD2D8_v2" not found')
    err = (<CUresult (*)(CUdeviceptr, size_t, unsigned char, size_t, size_t) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemsetD2D8_v2)(dstDevice, dstPitch, uc, Width, Height)
    return err

cdef CUresult _cuMemsetD2D16_v2(CUdeviceptr dstDevice, size_t dstPitch, unsigned short us, size_t Width, size_t Height) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemsetD2D16_v2
    cuPythonInit()
    if __cuMemsetD2D16_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuMemsetD2D16_v2" not found')
    err = (<CUresult (*)(CUdeviceptr, size_t, unsigned short, size_t, size_t) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemsetD2D16_v2)(dstDevice, dstPitch, us, Width, Height)
    return err

cdef CUresult _cuMemsetD2D32_v2(CUdeviceptr dstDevice, size_t dstPitch, unsigned int ui, size_t Width, size_t Height) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemsetD2D32_v2
    cuPythonInit()
    if __cuMemsetD2D32_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuMemsetD2D32_v2" not found')
    err = (<CUresult (*)(CUdeviceptr, size_t, unsigned int, size_t, size_t) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemsetD2D32_v2)(dstDevice, dstPitch, ui, Width, Height)
    return err

cdef CUresult _cuMemsetD8Async(CUdeviceptr dstDevice, unsigned char uc, size_t N, CUstream hStream) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemsetD8Async
    cuPythonInit()
    if __cuMemsetD8Async == NULL:
        with gil:
            raise RuntimeError('Function "cuMemsetD8Async" not found')
    err = (<CUresult (*)(CUdeviceptr, unsigned char, size_t, CUstream) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemsetD8Async)(dstDevice, uc, N, hStream)
    return err

cdef CUresult _cuMemsetD16Async(CUdeviceptr dstDevice, unsigned short us, size_t N, CUstream hStream) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemsetD16Async
    cuPythonInit()
    if __cuMemsetD16Async == NULL:
        with gil:
            raise RuntimeError('Function "cuMemsetD16Async" not found')
    err = (<CUresult (*)(CUdeviceptr, unsigned short, size_t, CUstream) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemsetD16Async)(dstDevice, us, N, hStream)
    return err

cdef CUresult _cuMemsetD32Async(CUdeviceptr dstDevice, unsigned int ui, size_t N, CUstream hStream) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemsetD32Async
    cuPythonInit()
    if __cuMemsetD32Async == NULL:
        with gil:
            raise RuntimeError('Function "cuMemsetD32Async" not found')
    err = (<CUresult (*)(CUdeviceptr, unsigned int, size_t, CUstream) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemsetD32Async)(dstDevice, ui, N, hStream)
    return err

cdef CUresult _cuMemsetD2D8Async(CUdeviceptr dstDevice, size_t dstPitch, unsigned char uc, size_t Width, size_t Height, CUstream hStream) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemsetD2D8Async
    cuPythonInit()
    if __cuMemsetD2D8Async == NULL:
        with gil:
            raise RuntimeError('Function "cuMemsetD2D8Async" not found')
    err = (<CUresult (*)(CUdeviceptr, size_t, unsigned char, size_t, size_t, CUstream) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemsetD2D8Async)(dstDevice, dstPitch, uc, Width, Height, hStream)
    return err

cdef CUresult _cuMemsetD2D16Async(CUdeviceptr dstDevice, size_t dstPitch, unsigned short us, size_t Width, size_t Height, CUstream hStream) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemsetD2D16Async
    cuPythonInit()
    if __cuMemsetD2D16Async == NULL:
        with gil:
            raise RuntimeError('Function "cuMemsetD2D16Async" not found')
    err = (<CUresult (*)(CUdeviceptr, size_t, unsigned short, size_t, size_t, CUstream) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemsetD2D16Async)(dstDevice, dstPitch, us, Width, Height, hStream)
    return err

cdef CUresult _cuMemsetD2D32Async(CUdeviceptr dstDevice, size_t dstPitch, unsigned int ui, size_t Width, size_t Height, CUstream hStream) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemsetD2D32Async
    cuPythonInit()
    if __cuMemsetD2D32Async == NULL:
        with gil:
            raise RuntimeError('Function "cuMemsetD2D32Async" not found')
    err = (<CUresult (*)(CUdeviceptr, size_t, unsigned int, size_t, size_t, CUstream) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemsetD2D32Async)(dstDevice, dstPitch, ui, Width, Height, hStream)
    return err

cdef CUresult _cuArrayCreate_v2(CUarray* pHandle, const CUDA_ARRAY_DESCRIPTOR* pAllocateArray) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuArrayCreate_v2
    cuPythonInit()
    if __cuArrayCreate_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuArrayCreate_v2" not found')
    err = (<CUresult (*)(CUarray*, const CUDA_ARRAY_DESCRIPTOR*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuArrayCreate_v2)(pHandle, pAllocateArray)
    return err

cdef CUresult _cuArrayGetDescriptor_v2(CUDA_ARRAY_DESCRIPTOR* pArrayDescriptor, CUarray hArray) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuArrayGetDescriptor_v2
    cuPythonInit()
    if __cuArrayGetDescriptor_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuArrayGetDescriptor_v2" not found')
    err = (<CUresult (*)(CUDA_ARRAY_DESCRIPTOR*, CUarray) except ?CUDA_ERROR_NOT_FOUND nogil> __cuArrayGetDescriptor_v2)(pArrayDescriptor, hArray)
    return err

cdef CUresult _cuArrayGetSparseProperties(CUDA_ARRAY_SPARSE_PROPERTIES* sparseProperties, CUarray array) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuArrayGetSparseProperties
    cuPythonInit()
    if __cuArrayGetSparseProperties == NULL:
        with gil:
            raise RuntimeError('Function "cuArrayGetSparseProperties" not found')
    err = (<CUresult (*)(CUDA_ARRAY_SPARSE_PROPERTIES*, CUarray) except ?CUDA_ERROR_NOT_FOUND nogil> __cuArrayGetSparseProperties)(sparseProperties, array)
    return err

cdef CUresult _cuMipmappedArrayGetSparseProperties(CUDA_ARRAY_SPARSE_PROPERTIES* sparseProperties, CUmipmappedArray mipmap) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMipmappedArrayGetSparseProperties
    cuPythonInit()
    if __cuMipmappedArrayGetSparseProperties == NULL:
        with gil:
            raise RuntimeError('Function "cuMipmappedArrayGetSparseProperties" not found')
    err = (<CUresult (*)(CUDA_ARRAY_SPARSE_PROPERTIES*, CUmipmappedArray) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMipmappedArrayGetSparseProperties)(sparseProperties, mipmap)
    return err

cdef CUresult _cuArrayGetMemoryRequirements(CUDA_ARRAY_MEMORY_REQUIREMENTS* memoryRequirements, CUarray array, CUdevice device) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuArrayGetMemoryRequirements
    cuPythonInit()
    if __cuArrayGetMemoryRequirements == NULL:
        with gil:
            raise RuntimeError('Function "cuArrayGetMemoryRequirements" not found')
    err = (<CUresult (*)(CUDA_ARRAY_MEMORY_REQUIREMENTS*, CUarray, CUdevice) except ?CUDA_ERROR_NOT_FOUND nogil> __cuArrayGetMemoryRequirements)(memoryRequirements, array, device)
    return err

cdef CUresult _cuMipmappedArrayGetMemoryRequirements(CUDA_ARRAY_MEMORY_REQUIREMENTS* memoryRequirements, CUmipmappedArray mipmap, CUdevice device) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMipmappedArrayGetMemoryRequirements
    cuPythonInit()
    if __cuMipmappedArrayGetMemoryRequirements == NULL:
        with gil:
            raise RuntimeError('Function "cuMipmappedArrayGetMemoryRequirements" not found')
    err = (<CUresult (*)(CUDA_ARRAY_MEMORY_REQUIREMENTS*, CUmipmappedArray, CUdevice) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMipmappedArrayGetMemoryRequirements)(memoryRequirements, mipmap, device)
    return err

cdef CUresult _cuArrayGetPlane(CUarray* pPlaneArray, CUarray hArray, unsigned int planeIdx) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuArrayGetPlane
    cuPythonInit()
    if __cuArrayGetPlane == NULL:
        with gil:
            raise RuntimeError('Function "cuArrayGetPlane" not found')
    err = (<CUresult (*)(CUarray*, CUarray, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuArrayGetPlane)(pPlaneArray, hArray, planeIdx)
    return err

cdef CUresult _cuArrayDestroy(CUarray hArray) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuArrayDestroy
    cuPythonInit()
    if __cuArrayDestroy == NULL:
        with gil:
            raise RuntimeError('Function "cuArrayDestroy" not found')
    err = (<CUresult (*)(CUarray) except ?CUDA_ERROR_NOT_FOUND nogil> __cuArrayDestroy)(hArray)
    return err

cdef CUresult _cuArray3DCreate_v2(CUarray* pHandle, const CUDA_ARRAY3D_DESCRIPTOR* pAllocateArray) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuArray3DCreate_v2
    cuPythonInit()
    if __cuArray3DCreate_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuArray3DCreate_v2" not found')
    err = (<CUresult (*)(CUarray*, const CUDA_ARRAY3D_DESCRIPTOR*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuArray3DCreate_v2)(pHandle, pAllocateArray)
    return err

cdef CUresult _cuArray3DGetDescriptor_v2(CUDA_ARRAY3D_DESCRIPTOR* pArrayDescriptor, CUarray hArray) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuArray3DGetDescriptor_v2
    cuPythonInit()
    if __cuArray3DGetDescriptor_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuArray3DGetDescriptor_v2" not found')
    err = (<CUresult (*)(CUDA_ARRAY3D_DESCRIPTOR*, CUarray) except ?CUDA_ERROR_NOT_FOUND nogil> __cuArray3DGetDescriptor_v2)(pArrayDescriptor, hArray)
    return err

cdef CUresult _cuMipmappedArrayCreate(CUmipmappedArray* pHandle, const CUDA_ARRAY3D_DESCRIPTOR* pMipmappedArrayDesc, unsigned int numMipmapLevels) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMipmappedArrayCreate
    cuPythonInit()
    if __cuMipmappedArrayCreate == NULL:
        with gil:
            raise RuntimeError('Function "cuMipmappedArrayCreate" not found')
    err = (<CUresult (*)(CUmipmappedArray*, const CUDA_ARRAY3D_DESCRIPTOR*, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMipmappedArrayCreate)(pHandle, pMipmappedArrayDesc, numMipmapLevels)
    return err

cdef CUresult _cuMipmappedArrayGetLevel(CUarray* pLevelArray, CUmipmappedArray hMipmappedArray, unsigned int level) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMipmappedArrayGetLevel
    cuPythonInit()
    if __cuMipmappedArrayGetLevel == NULL:
        with gil:
            raise RuntimeError('Function "cuMipmappedArrayGetLevel" not found')
    err = (<CUresult (*)(CUarray*, CUmipmappedArray, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMipmappedArrayGetLevel)(pLevelArray, hMipmappedArray, level)
    return err

cdef CUresult _cuMipmappedArrayDestroy(CUmipmappedArray hMipmappedArray) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMipmappedArrayDestroy
    cuPythonInit()
    if __cuMipmappedArrayDestroy == NULL:
        with gil:
            raise RuntimeError('Function "cuMipmappedArrayDestroy" not found')
    err = (<CUresult (*)(CUmipmappedArray) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMipmappedArrayDestroy)(hMipmappedArray)
    return err

cdef CUresult _cuMemGetHandleForAddressRange(void* handle, CUdeviceptr dptr, size_t size, CUmemRangeHandleType handleType, unsigned long long flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemGetHandleForAddressRange
    cuPythonInit()
    if __cuMemGetHandleForAddressRange == NULL:
        with gil:
            raise RuntimeError('Function "cuMemGetHandleForAddressRange" not found')
    err = (<CUresult (*)(void*, CUdeviceptr, size_t, CUmemRangeHandleType, unsigned long long) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemGetHandleForAddressRange)(handle, dptr, size, handleType, flags)
    return err

cdef CUresult _cuMemBatchDecompressAsync(CUmemDecompressParams* paramsArray, size_t count, unsigned int flags, size_t* errorIndex, CUstream stream) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemBatchDecompressAsync
    cuPythonInit()
    if __cuMemBatchDecompressAsync == NULL:
        with gil:
            raise RuntimeError('Function "cuMemBatchDecompressAsync" not found')
    err = (<CUresult (*)(CUmemDecompressParams*, size_t, unsigned int, size_t*, CUstream) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemBatchDecompressAsync)(paramsArray, count, flags, errorIndex, stream)
    return err

cdef CUresult _cuMemAddressReserve(CUdeviceptr* ptr, size_t size, size_t alignment, CUdeviceptr addr, unsigned long long flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemAddressReserve
    cuPythonInit()
    if __cuMemAddressReserve == NULL:
        with gil:
            raise RuntimeError('Function "cuMemAddressReserve" not found')
    err = (<CUresult (*)(CUdeviceptr*, size_t, size_t, CUdeviceptr, unsigned long long) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemAddressReserve)(ptr, size, alignment, addr, flags)
    return err

cdef CUresult _cuMemAddressFree(CUdeviceptr ptr, size_t size) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemAddressFree
    cuPythonInit()
    if __cuMemAddressFree == NULL:
        with gil:
            raise RuntimeError('Function "cuMemAddressFree" not found')
    err = (<CUresult (*)(CUdeviceptr, size_t) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemAddressFree)(ptr, size)
    return err

cdef CUresult _cuMemCreate(CUmemGenericAllocationHandle* handle, size_t size, const CUmemAllocationProp* prop, unsigned long long flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemCreate
    cuPythonInit()
    if __cuMemCreate == NULL:
        with gil:
            raise RuntimeError('Function "cuMemCreate" not found')
    err = (<CUresult (*)(CUmemGenericAllocationHandle*, size_t, const CUmemAllocationProp*, unsigned long long) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemCreate)(handle, size, prop, flags)
    return err

cdef CUresult _cuMemRelease(CUmemGenericAllocationHandle handle) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemRelease
    cuPythonInit()
    if __cuMemRelease == NULL:
        with gil:
            raise RuntimeError('Function "cuMemRelease" not found')
    err = (<CUresult (*)(CUmemGenericAllocationHandle) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemRelease)(handle)
    return err

cdef CUresult _cuMemMap(CUdeviceptr ptr, size_t size, size_t offset, CUmemGenericAllocationHandle handle, unsigned long long flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemMap
    cuPythonInit()
    if __cuMemMap == NULL:
        with gil:
            raise RuntimeError('Function "cuMemMap" not found')
    err = (<CUresult (*)(CUdeviceptr, size_t, size_t, CUmemGenericAllocationHandle, unsigned long long) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemMap)(ptr, size, offset, handle, flags)
    return err

cdef CUresult _cuMemMapArrayAsync(CUarrayMapInfo* mapInfoList, unsigned int count, CUstream hStream) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemMapArrayAsync
    cuPythonInit()
    if __cuMemMapArrayAsync == NULL:
        with gil:
            raise RuntimeError('Function "cuMemMapArrayAsync" not found')
    err = (<CUresult (*)(CUarrayMapInfo*, unsigned int, CUstream) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemMapArrayAsync)(mapInfoList, count, hStream)
    return err

cdef CUresult _cuMemUnmap(CUdeviceptr ptr, size_t size) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemUnmap
    cuPythonInit()
    if __cuMemUnmap == NULL:
        with gil:
            raise RuntimeError('Function "cuMemUnmap" not found')
    err = (<CUresult (*)(CUdeviceptr, size_t) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemUnmap)(ptr, size)
    return err

cdef CUresult _cuMemSetAccess(CUdeviceptr ptr, size_t size, const CUmemAccessDesc* desc, size_t count) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemSetAccess
    cuPythonInit()
    if __cuMemSetAccess == NULL:
        with gil:
            raise RuntimeError('Function "cuMemSetAccess" not found')
    err = (<CUresult (*)(CUdeviceptr, size_t, const CUmemAccessDesc*, size_t) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemSetAccess)(ptr, size, desc, count)
    return err

cdef CUresult _cuMemGetAccess(unsigned long long* flags, const CUmemLocation* location, CUdeviceptr ptr) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemGetAccess
    cuPythonInit()
    if __cuMemGetAccess == NULL:
        with gil:
            raise RuntimeError('Function "cuMemGetAccess" not found')
    err = (<CUresult (*)(unsigned long long*, const CUmemLocation*, CUdeviceptr) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemGetAccess)(flags, location, ptr)
    return err

cdef CUresult _cuMemExportToShareableHandle(void* shareableHandle, CUmemGenericAllocationHandle handle, CUmemAllocationHandleType handleType, unsigned long long flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemExportToShareableHandle
    cuPythonInit()
    if __cuMemExportToShareableHandle == NULL:
        with gil:
            raise RuntimeError('Function "cuMemExportToShareableHandle" not found')
    err = (<CUresult (*)(void*, CUmemGenericAllocationHandle, CUmemAllocationHandleType, unsigned long long) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemExportToShareableHandle)(shareableHandle, handle, handleType, flags)
    return err

cdef CUresult _cuMemImportFromShareableHandle(CUmemGenericAllocationHandle* handle, void* osHandle, CUmemAllocationHandleType shHandleType) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemImportFromShareableHandle
    cuPythonInit()
    if __cuMemImportFromShareableHandle == NULL:
        with gil:
            raise RuntimeError('Function "cuMemImportFromShareableHandle" not found')
    err = (<CUresult (*)(CUmemGenericAllocationHandle*, void*, CUmemAllocationHandleType) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemImportFromShareableHandle)(handle, osHandle, shHandleType)
    return err

cdef CUresult _cuMemGetAllocationGranularity(size_t* granularity, const CUmemAllocationProp* prop, CUmemAllocationGranularity_flags option) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemGetAllocationGranularity
    cuPythonInit()
    if __cuMemGetAllocationGranularity == NULL:
        with gil:
            raise RuntimeError('Function "cuMemGetAllocationGranularity" not found')
    err = (<CUresult (*)(size_t*, const CUmemAllocationProp*, CUmemAllocationGranularity_flags) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemGetAllocationGranularity)(granularity, prop, option)
    return err

cdef CUresult _cuMemGetAllocationPropertiesFromHandle(CUmemAllocationProp* prop, CUmemGenericAllocationHandle handle) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemGetAllocationPropertiesFromHandle
    cuPythonInit()
    if __cuMemGetAllocationPropertiesFromHandle == NULL:
        with gil:
            raise RuntimeError('Function "cuMemGetAllocationPropertiesFromHandle" not found')
    err = (<CUresult (*)(CUmemAllocationProp*, CUmemGenericAllocationHandle) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemGetAllocationPropertiesFromHandle)(prop, handle)
    return err

cdef CUresult _cuMemRetainAllocationHandle(CUmemGenericAllocationHandle* handle, void* addr) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemRetainAllocationHandle
    cuPythonInit()
    if __cuMemRetainAllocationHandle == NULL:
        with gil:
            raise RuntimeError('Function "cuMemRetainAllocationHandle" not found')
    err = (<CUresult (*)(CUmemGenericAllocationHandle*, void*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemRetainAllocationHandle)(handle, addr)
    return err

cdef CUresult _cuMemFreeAsync(CUdeviceptr dptr, CUstream hStream) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemFreeAsync
    cuPythonInit()
    if __cuMemFreeAsync == NULL:
        with gil:
            raise RuntimeError('Function "cuMemFreeAsync" not found')
    err = (<CUresult (*)(CUdeviceptr, CUstream) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemFreeAsync)(dptr, hStream)
    return err

cdef CUresult _cuMemAllocAsync(CUdeviceptr* dptr, size_t bytesize, CUstream hStream) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemAllocAsync
    cuPythonInit()
    if __cuMemAllocAsync == NULL:
        with gil:
            raise RuntimeError('Function "cuMemAllocAsync" not found')
    err = (<CUresult (*)(CUdeviceptr*, size_t, CUstream) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemAllocAsync)(dptr, bytesize, hStream)
    return err

cdef CUresult _cuMemPoolTrimTo(CUmemoryPool pool, size_t minBytesToKeep) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemPoolTrimTo
    cuPythonInit()
    if __cuMemPoolTrimTo == NULL:
        with gil:
            raise RuntimeError('Function "cuMemPoolTrimTo" not found')
    err = (<CUresult (*)(CUmemoryPool, size_t) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemPoolTrimTo)(pool, minBytesToKeep)
    return err

cdef CUresult _cuMemPoolSetAttribute(CUmemoryPool pool, CUmemPool_attribute attr, void* value) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemPoolSetAttribute
    cuPythonInit()
    if __cuMemPoolSetAttribute == NULL:
        with gil:
            raise RuntimeError('Function "cuMemPoolSetAttribute" not found')
    err = (<CUresult (*)(CUmemoryPool, CUmemPool_attribute, void*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemPoolSetAttribute)(pool, attr, value)
    return err

cdef CUresult _cuMemPoolGetAttribute(CUmemoryPool pool, CUmemPool_attribute attr, void* value) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemPoolGetAttribute
    cuPythonInit()
    if __cuMemPoolGetAttribute == NULL:
        with gil:
            raise RuntimeError('Function "cuMemPoolGetAttribute" not found')
    err = (<CUresult (*)(CUmemoryPool, CUmemPool_attribute, void*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemPoolGetAttribute)(pool, attr, value)
    return err

cdef CUresult _cuMemPoolSetAccess(CUmemoryPool pool, const CUmemAccessDesc* map, size_t count) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemPoolSetAccess
    cuPythonInit()
    if __cuMemPoolSetAccess == NULL:
        with gil:
            raise RuntimeError('Function "cuMemPoolSetAccess" not found')
    err = (<CUresult (*)(CUmemoryPool, const CUmemAccessDesc*, size_t) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemPoolSetAccess)(pool, map, count)
    return err

cdef CUresult _cuMemPoolGetAccess(CUmemAccess_flags* flags, CUmemoryPool memPool, CUmemLocation* location) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemPoolGetAccess
    cuPythonInit()
    if __cuMemPoolGetAccess == NULL:
        with gil:
            raise RuntimeError('Function "cuMemPoolGetAccess" not found')
    err = (<CUresult (*)(CUmemAccess_flags*, CUmemoryPool, CUmemLocation*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemPoolGetAccess)(flags, memPool, location)
    return err

cdef CUresult _cuMemPoolCreate(CUmemoryPool* pool, const CUmemPoolProps* poolProps) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemPoolCreate
    cuPythonInit()
    if __cuMemPoolCreate == NULL:
        with gil:
            raise RuntimeError('Function "cuMemPoolCreate" not found')
    err = (<CUresult (*)(CUmemoryPool*, const CUmemPoolProps*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemPoolCreate)(pool, poolProps)
    return err

cdef CUresult _cuMemPoolDestroy(CUmemoryPool pool) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemPoolDestroy
    cuPythonInit()
    if __cuMemPoolDestroy == NULL:
        with gil:
            raise RuntimeError('Function "cuMemPoolDestroy" not found')
    err = (<CUresult (*)(CUmemoryPool) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemPoolDestroy)(pool)
    return err

cdef CUresult _cuMemAllocFromPoolAsync(CUdeviceptr* dptr, size_t bytesize, CUmemoryPool pool, CUstream hStream) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemAllocFromPoolAsync
    cuPythonInit()
    if __cuMemAllocFromPoolAsync == NULL:
        with gil:
            raise RuntimeError('Function "cuMemAllocFromPoolAsync" not found')
    err = (<CUresult (*)(CUdeviceptr*, size_t, CUmemoryPool, CUstream) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemAllocFromPoolAsync)(dptr, bytesize, pool, hStream)
    return err

cdef CUresult _cuMemPoolExportToShareableHandle(void* handle_out, CUmemoryPool pool, CUmemAllocationHandleType handleType, unsigned long long flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemPoolExportToShareableHandle
    cuPythonInit()
    if __cuMemPoolExportToShareableHandle == NULL:
        with gil:
            raise RuntimeError('Function "cuMemPoolExportToShareableHandle" not found')
    err = (<CUresult (*)(void*, CUmemoryPool, CUmemAllocationHandleType, unsigned long long) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemPoolExportToShareableHandle)(handle_out, pool, handleType, flags)
    return err

cdef CUresult _cuMemPoolImportFromShareableHandle(CUmemoryPool* pool_out, void* handle, CUmemAllocationHandleType handleType, unsigned long long flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemPoolImportFromShareableHandle
    cuPythonInit()
    if __cuMemPoolImportFromShareableHandle == NULL:
        with gil:
            raise RuntimeError('Function "cuMemPoolImportFromShareableHandle" not found')
    err = (<CUresult (*)(CUmemoryPool*, void*, CUmemAllocationHandleType, unsigned long long) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemPoolImportFromShareableHandle)(pool_out, handle, handleType, flags)
    return err

cdef CUresult _cuMemPoolExportPointer(CUmemPoolPtrExportData* shareData_out, CUdeviceptr ptr) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemPoolExportPointer
    cuPythonInit()
    if __cuMemPoolExportPointer == NULL:
        with gil:
            raise RuntimeError('Function "cuMemPoolExportPointer" not found')
    err = (<CUresult (*)(CUmemPoolPtrExportData*, CUdeviceptr) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemPoolExportPointer)(shareData_out, ptr)
    return err

cdef CUresult _cuMemPoolImportPointer(CUdeviceptr* ptr_out, CUmemoryPool pool, CUmemPoolPtrExportData* shareData) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemPoolImportPointer
    cuPythonInit()
    if __cuMemPoolImportPointer == NULL:
        with gil:
            raise RuntimeError('Function "cuMemPoolImportPointer" not found')
    err = (<CUresult (*)(CUdeviceptr*, CUmemoryPool, CUmemPoolPtrExportData*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemPoolImportPointer)(ptr_out, pool, shareData)
    return err

cdef CUresult _cuMulticastCreate(CUmemGenericAllocationHandle* mcHandle, const CUmulticastObjectProp* prop) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMulticastCreate
    cuPythonInit()
    if __cuMulticastCreate == NULL:
        with gil:
            raise RuntimeError('Function "cuMulticastCreate" not found')
    err = (<CUresult (*)(CUmemGenericAllocationHandle*, const CUmulticastObjectProp*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMulticastCreate)(mcHandle, prop)
    return err

cdef CUresult _cuMulticastAddDevice(CUmemGenericAllocationHandle mcHandle, CUdevice dev) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMulticastAddDevice
    cuPythonInit()
    if __cuMulticastAddDevice == NULL:
        with gil:
            raise RuntimeError('Function "cuMulticastAddDevice" not found')
    err = (<CUresult (*)(CUmemGenericAllocationHandle, CUdevice) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMulticastAddDevice)(mcHandle, dev)
    return err

cdef CUresult _cuMulticastBindMem(CUmemGenericAllocationHandle mcHandle, size_t mcOffset, CUmemGenericAllocationHandle memHandle, size_t memOffset, size_t size, unsigned long long flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMulticastBindMem
    cuPythonInit()
    if __cuMulticastBindMem == NULL:
        with gil:
            raise RuntimeError('Function "cuMulticastBindMem" not found')
    err = (<CUresult (*)(CUmemGenericAllocationHandle, size_t, CUmemGenericAllocationHandle, size_t, size_t, unsigned long long) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMulticastBindMem)(mcHandle, mcOffset, memHandle, memOffset, size, flags)
    return err

cdef CUresult _cuMulticastBindAddr(CUmemGenericAllocationHandle mcHandle, size_t mcOffset, CUdeviceptr memptr, size_t size, unsigned long long flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMulticastBindAddr
    cuPythonInit()
    if __cuMulticastBindAddr == NULL:
        with gil:
            raise RuntimeError('Function "cuMulticastBindAddr" not found')
    err = (<CUresult (*)(CUmemGenericAllocationHandle, size_t, CUdeviceptr, size_t, unsigned long long) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMulticastBindAddr)(mcHandle, mcOffset, memptr, size, flags)
    return err

cdef CUresult _cuMulticastUnbind(CUmemGenericAllocationHandle mcHandle, CUdevice dev, size_t mcOffset, size_t size) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMulticastUnbind
    cuPythonInit()
    if __cuMulticastUnbind == NULL:
        with gil:
            raise RuntimeError('Function "cuMulticastUnbind" not found')
    err = (<CUresult (*)(CUmemGenericAllocationHandle, CUdevice, size_t, size_t) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMulticastUnbind)(mcHandle, dev, mcOffset, size)
    return err

cdef CUresult _cuMulticastGetGranularity(size_t* granularity, const CUmulticastObjectProp* prop, CUmulticastGranularity_flags option) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMulticastGetGranularity
    cuPythonInit()
    if __cuMulticastGetGranularity == NULL:
        with gil:
            raise RuntimeError('Function "cuMulticastGetGranularity" not found')
    err = (<CUresult (*)(size_t*, const CUmulticastObjectProp*, CUmulticastGranularity_flags) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMulticastGetGranularity)(granularity, prop, option)
    return err

cdef CUresult _cuPointerGetAttribute(void* data, CUpointer_attribute attribute, CUdeviceptr ptr) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuPointerGetAttribute
    cuPythonInit()
    if __cuPointerGetAttribute == NULL:
        with gil:
            raise RuntimeError('Function "cuPointerGetAttribute" not found')
    err = (<CUresult (*)(void*, CUpointer_attribute, CUdeviceptr) except ?CUDA_ERROR_NOT_FOUND nogil> __cuPointerGetAttribute)(data, attribute, ptr)
    return err

cdef CUresult _cuMemPrefetchAsync(CUdeviceptr devPtr, size_t count, CUdevice dstDevice, CUstream hStream) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemPrefetchAsync
    cuPythonInit()
    if __cuMemPrefetchAsync == NULL:
        with gil:
            raise RuntimeError('Function "cuMemPrefetchAsync" not found')
    err = (<CUresult (*)(CUdeviceptr, size_t, CUdevice, CUstream) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemPrefetchAsync)(devPtr, count, dstDevice, hStream)
    return err

cdef CUresult _cuMemPrefetchAsync_v2(CUdeviceptr devPtr, size_t count, CUmemLocation location, unsigned int flags, CUstream hStream) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemPrefetchAsync_v2
    cuPythonInit()
    if __cuMemPrefetchAsync_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuMemPrefetchAsync_v2" not found')
    err = (<CUresult (*)(CUdeviceptr, size_t, CUmemLocation, unsigned int, CUstream) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemPrefetchAsync_v2)(devPtr, count, location, flags, hStream)
    return err

cdef CUresult _cuMemAdvise(CUdeviceptr devPtr, size_t count, CUmem_advise advice, CUdevice device) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemAdvise
    cuPythonInit()
    if __cuMemAdvise == NULL:
        with gil:
            raise RuntimeError('Function "cuMemAdvise" not found')
    err = (<CUresult (*)(CUdeviceptr, size_t, CUmem_advise, CUdevice) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemAdvise)(devPtr, count, advice, device)
    return err

cdef CUresult _cuMemAdvise_v2(CUdeviceptr devPtr, size_t count, CUmem_advise advice, CUmemLocation location) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemAdvise_v2
    cuPythonInit()
    if __cuMemAdvise_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuMemAdvise_v2" not found')
    err = (<CUresult (*)(CUdeviceptr, size_t, CUmem_advise, CUmemLocation) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemAdvise_v2)(devPtr, count, advice, location)
    return err

cdef CUresult _cuMemRangeGetAttribute(void* data, size_t dataSize, CUmem_range_attribute attribute, CUdeviceptr devPtr, size_t count) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemRangeGetAttribute
    cuPythonInit()
    if __cuMemRangeGetAttribute == NULL:
        with gil:
            raise RuntimeError('Function "cuMemRangeGetAttribute" not found')
    err = (<CUresult (*)(void*, size_t, CUmem_range_attribute, CUdeviceptr, size_t) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemRangeGetAttribute)(data, dataSize, attribute, devPtr, count)
    return err

cdef CUresult _cuMemRangeGetAttributes(void** data, size_t* dataSizes, CUmem_range_attribute* attributes, size_t numAttributes, CUdeviceptr devPtr, size_t count) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuMemRangeGetAttributes
    cuPythonInit()
    if __cuMemRangeGetAttributes == NULL:
        with gil:
            raise RuntimeError('Function "cuMemRangeGetAttributes" not found')
    err = (<CUresult (*)(void**, size_t*, CUmem_range_attribute*, size_t, CUdeviceptr, size_t) except ?CUDA_ERROR_NOT_FOUND nogil> __cuMemRangeGetAttributes)(data, dataSizes, attributes, numAttributes, devPtr, count)
    return err

cdef CUresult _cuPointerSetAttribute(const void* value, CUpointer_attribute attribute, CUdeviceptr ptr) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuPointerSetAttribute
    cuPythonInit()
    if __cuPointerSetAttribute == NULL:
        with gil:
            raise RuntimeError('Function "cuPointerSetAttribute" not found')
    err = (<CUresult (*)(const void*, CUpointer_attribute, CUdeviceptr) except ?CUDA_ERROR_NOT_FOUND nogil> __cuPointerSetAttribute)(value, attribute, ptr)
    return err

cdef CUresult _cuPointerGetAttributes(unsigned int numAttributes, CUpointer_attribute* attributes, void** data, CUdeviceptr ptr) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuPointerGetAttributes
    cuPythonInit()
    if __cuPointerGetAttributes == NULL:
        with gil:
            raise RuntimeError('Function "cuPointerGetAttributes" not found')
    err = (<CUresult (*)(unsigned int, CUpointer_attribute*, void**, CUdeviceptr) except ?CUDA_ERROR_NOT_FOUND nogil> __cuPointerGetAttributes)(numAttributes, attributes, data, ptr)
    return err

cdef CUresult _cuStreamCreate(CUstream* phStream, unsigned int Flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuStreamCreate
    cuPythonInit()
    if __cuStreamCreate == NULL:
        with gil:
            raise RuntimeError('Function "cuStreamCreate" not found')
    err = (<CUresult (*)(CUstream*, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuStreamCreate)(phStream, Flags)
    return err

cdef CUresult _cuStreamCreateWithPriority(CUstream* phStream, unsigned int flags, int priority) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuStreamCreateWithPriority
    cuPythonInit()
    if __cuStreamCreateWithPriority == NULL:
        with gil:
            raise RuntimeError('Function "cuStreamCreateWithPriority" not found')
    err = (<CUresult (*)(CUstream*, unsigned int, int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuStreamCreateWithPriority)(phStream, flags, priority)
    return err

cdef CUresult _cuStreamGetPriority(CUstream hStream, int* priority) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuStreamGetPriority
    cuPythonInit()
    if __cuStreamGetPriority == NULL:
        with gil:
            raise RuntimeError('Function "cuStreamGetPriority" not found')
    err = (<CUresult (*)(CUstream, int*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuStreamGetPriority)(hStream, priority)
    return err

cdef CUresult _cuStreamGetDevice(CUstream hStream, CUdevice* device) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuStreamGetDevice
    cuPythonInit()
    if __cuStreamGetDevice == NULL:
        with gil:
            raise RuntimeError('Function "cuStreamGetDevice" not found')
    err = (<CUresult (*)(CUstream, CUdevice*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuStreamGetDevice)(hStream, device)
    return err

cdef CUresult _cuStreamGetFlags(CUstream hStream, unsigned int* flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuStreamGetFlags
    cuPythonInit()
    if __cuStreamGetFlags == NULL:
        with gil:
            raise RuntimeError('Function "cuStreamGetFlags" not found')
    err = (<CUresult (*)(CUstream, unsigned int*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuStreamGetFlags)(hStream, flags)
    return err

cdef CUresult _cuStreamGetId(CUstream hStream, unsigned long long* streamId) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuStreamGetId
    cuPythonInit()
    if __cuStreamGetId == NULL:
        with gil:
            raise RuntimeError('Function "cuStreamGetId" not found')
    err = (<CUresult (*)(CUstream, unsigned long long*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuStreamGetId)(hStream, streamId)
    return err

cdef CUresult _cuStreamGetCtx(CUstream hStream, CUcontext* pctx) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuStreamGetCtx
    cuPythonInit()
    if __cuStreamGetCtx == NULL:
        with gil:
            raise RuntimeError('Function "cuStreamGetCtx" not found')
    err = (<CUresult (*)(CUstream, CUcontext*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuStreamGetCtx)(hStream, pctx)
    return err

cdef CUresult _cuStreamGetCtx_v2(CUstream hStream, CUcontext* pCtx, CUgreenCtx* pGreenCtx) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuStreamGetCtx_v2
    cuPythonInit()
    if __cuStreamGetCtx_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuStreamGetCtx_v2" not found')
    err = (<CUresult (*)(CUstream, CUcontext*, CUgreenCtx*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuStreamGetCtx_v2)(hStream, pCtx, pGreenCtx)
    return err

cdef CUresult _cuStreamWaitEvent(CUstream hStream, CUevent hEvent, unsigned int Flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuStreamWaitEvent
    cuPythonInit()
    if __cuStreamWaitEvent == NULL:
        with gil:
            raise RuntimeError('Function "cuStreamWaitEvent" not found')
    err = (<CUresult (*)(CUstream, CUevent, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuStreamWaitEvent)(hStream, hEvent, Flags)
    return err

cdef CUresult _cuStreamAddCallback(CUstream hStream, CUstreamCallback callback, void* userData, unsigned int flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuStreamAddCallback
    cuPythonInit()
    if __cuStreamAddCallback == NULL:
        with gil:
            raise RuntimeError('Function "cuStreamAddCallback" not found')
    err = (<CUresult (*)(CUstream, CUstreamCallback, void*, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuStreamAddCallback)(hStream, callback, userData, flags)
    return err

cdef CUresult _cuStreamBeginCapture_v2(CUstream hStream, CUstreamCaptureMode mode) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuStreamBeginCapture_v2
    cuPythonInit()
    if __cuStreamBeginCapture_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuStreamBeginCapture_v2" not found')
    err = (<CUresult (*)(CUstream, CUstreamCaptureMode) except ?CUDA_ERROR_NOT_FOUND nogil> __cuStreamBeginCapture_v2)(hStream, mode)
    return err

cdef CUresult _cuStreamBeginCaptureToGraph(CUstream hStream, CUgraph hGraph, const CUgraphNode* dependencies, const CUgraphEdgeData* dependencyData, size_t numDependencies, CUstreamCaptureMode mode) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuStreamBeginCaptureToGraph
    cuPythonInit()
    if __cuStreamBeginCaptureToGraph == NULL:
        with gil:
            raise RuntimeError('Function "cuStreamBeginCaptureToGraph" not found')
    err = (<CUresult (*)(CUstream, CUgraph, const CUgraphNode*, const CUgraphEdgeData*, size_t, CUstreamCaptureMode) except ?CUDA_ERROR_NOT_FOUND nogil> __cuStreamBeginCaptureToGraph)(hStream, hGraph, dependencies, dependencyData, numDependencies, mode)
    return err

cdef CUresult _cuThreadExchangeStreamCaptureMode(CUstreamCaptureMode* mode) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuThreadExchangeStreamCaptureMode
    cuPythonInit()
    if __cuThreadExchangeStreamCaptureMode == NULL:
        with gil:
            raise RuntimeError('Function "cuThreadExchangeStreamCaptureMode" not found')
    err = (<CUresult (*)(CUstreamCaptureMode*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuThreadExchangeStreamCaptureMode)(mode)
    return err

cdef CUresult _cuStreamEndCapture(CUstream hStream, CUgraph* phGraph) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuStreamEndCapture
    cuPythonInit()
    if __cuStreamEndCapture == NULL:
        with gil:
            raise RuntimeError('Function "cuStreamEndCapture" not found')
    err = (<CUresult (*)(CUstream, CUgraph*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuStreamEndCapture)(hStream, phGraph)
    return err

cdef CUresult _cuStreamIsCapturing(CUstream hStream, CUstreamCaptureStatus* captureStatus) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuStreamIsCapturing
    cuPythonInit()
    if __cuStreamIsCapturing == NULL:
        with gil:
            raise RuntimeError('Function "cuStreamIsCapturing" not found')
    err = (<CUresult (*)(CUstream, CUstreamCaptureStatus*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuStreamIsCapturing)(hStream, captureStatus)
    return err

cdef CUresult _cuStreamGetCaptureInfo_v2(CUstream hStream, CUstreamCaptureStatus* captureStatus_out, cuuint64_t* id_out, CUgraph* graph_out, const CUgraphNode** dependencies_out, size_t* numDependencies_out) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuStreamGetCaptureInfo_v2
    cuPythonInit()
    if __cuStreamGetCaptureInfo_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuStreamGetCaptureInfo_v2" not found')
    err = (<CUresult (*)(CUstream, CUstreamCaptureStatus*, cuuint64_t*, CUgraph*, const CUgraphNode**, size_t*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuStreamGetCaptureInfo_v2)(hStream, captureStatus_out, id_out, graph_out, dependencies_out, numDependencies_out)
    return err

cdef CUresult _cuStreamGetCaptureInfo_v3(CUstream hStream, CUstreamCaptureStatus* captureStatus_out, cuuint64_t* id_out, CUgraph* graph_out, const CUgraphNode** dependencies_out, const CUgraphEdgeData** edgeData_out, size_t* numDependencies_out) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuStreamGetCaptureInfo_v3
    cuPythonInit()
    if __cuStreamGetCaptureInfo_v3 == NULL:
        with gil:
            raise RuntimeError('Function "cuStreamGetCaptureInfo_v3" not found')
    err = (<CUresult (*)(CUstream, CUstreamCaptureStatus*, cuuint64_t*, CUgraph*, const CUgraphNode**, const CUgraphEdgeData**, size_t*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuStreamGetCaptureInfo_v3)(hStream, captureStatus_out, id_out, graph_out, dependencies_out, edgeData_out, numDependencies_out)
    return err

cdef CUresult _cuStreamUpdateCaptureDependencies(CUstream hStream, CUgraphNode* dependencies, size_t numDependencies, unsigned int flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuStreamUpdateCaptureDependencies
    cuPythonInit()
    if __cuStreamUpdateCaptureDependencies == NULL:
        with gil:
            raise RuntimeError('Function "cuStreamUpdateCaptureDependencies" not found')
    err = (<CUresult (*)(CUstream, CUgraphNode*, size_t, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuStreamUpdateCaptureDependencies)(hStream, dependencies, numDependencies, flags)
    return err

cdef CUresult _cuStreamUpdateCaptureDependencies_v2(CUstream hStream, CUgraphNode* dependencies, const CUgraphEdgeData* dependencyData, size_t numDependencies, unsigned int flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuStreamUpdateCaptureDependencies_v2
    cuPythonInit()
    if __cuStreamUpdateCaptureDependencies_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuStreamUpdateCaptureDependencies_v2" not found')
    err = (<CUresult (*)(CUstream, CUgraphNode*, const CUgraphEdgeData*, size_t, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuStreamUpdateCaptureDependencies_v2)(hStream, dependencies, dependencyData, numDependencies, flags)
    return err

cdef CUresult _cuStreamAttachMemAsync(CUstream hStream, CUdeviceptr dptr, size_t length, unsigned int flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuStreamAttachMemAsync
    cuPythonInit()
    if __cuStreamAttachMemAsync == NULL:
        with gil:
            raise RuntimeError('Function "cuStreamAttachMemAsync" not found')
    err = (<CUresult (*)(CUstream, CUdeviceptr, size_t, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuStreamAttachMemAsync)(hStream, dptr, length, flags)
    return err

cdef CUresult _cuStreamQuery(CUstream hStream) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuStreamQuery
    cuPythonInit()
    if __cuStreamQuery == NULL:
        with gil:
            raise RuntimeError('Function "cuStreamQuery" not found')
    err = (<CUresult (*)(CUstream) except ?CUDA_ERROR_NOT_FOUND nogil> __cuStreamQuery)(hStream)
    return err

cdef CUresult _cuStreamSynchronize(CUstream hStream) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuStreamSynchronize
    cuPythonInit()
    if __cuStreamSynchronize == NULL:
        with gil:
            raise RuntimeError('Function "cuStreamSynchronize" not found')
    err = (<CUresult (*)(CUstream) except ?CUDA_ERROR_NOT_FOUND nogil> __cuStreamSynchronize)(hStream)
    return err

cdef CUresult _cuStreamDestroy_v2(CUstream hStream) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuStreamDestroy_v2
    cuPythonInit()
    if __cuStreamDestroy_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuStreamDestroy_v2" not found')
    err = (<CUresult (*)(CUstream) except ?CUDA_ERROR_NOT_FOUND nogil> __cuStreamDestroy_v2)(hStream)
    return err

cdef CUresult _cuStreamCopyAttributes(CUstream dst, CUstream src) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuStreamCopyAttributes
    cuPythonInit()
    if __cuStreamCopyAttributes == NULL:
        with gil:
            raise RuntimeError('Function "cuStreamCopyAttributes" not found')
    err = (<CUresult (*)(CUstream, CUstream) except ?CUDA_ERROR_NOT_FOUND nogil> __cuStreamCopyAttributes)(dst, src)
    return err

cdef CUresult _cuStreamGetAttribute(CUstream hStream, CUstreamAttrID attr, CUstreamAttrValue* value_out) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuStreamGetAttribute
    cuPythonInit()
    if __cuStreamGetAttribute == NULL:
        with gil:
            raise RuntimeError('Function "cuStreamGetAttribute" not found')
    err = (<CUresult (*)(CUstream, CUstreamAttrID, CUstreamAttrValue*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuStreamGetAttribute)(hStream, attr, value_out)
    return err

cdef CUresult _cuStreamSetAttribute(CUstream hStream, CUstreamAttrID attr, const CUstreamAttrValue* value) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuStreamSetAttribute
    cuPythonInit()
    if __cuStreamSetAttribute == NULL:
        with gil:
            raise RuntimeError('Function "cuStreamSetAttribute" not found')
    err = (<CUresult (*)(CUstream, CUstreamAttrID, const CUstreamAttrValue*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuStreamSetAttribute)(hStream, attr, value)
    return err

cdef CUresult _cuEventCreate(CUevent* phEvent, unsigned int Flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuEventCreate
    cuPythonInit()
    if __cuEventCreate == NULL:
        with gil:
            raise RuntimeError('Function "cuEventCreate" not found')
    err = (<CUresult (*)(CUevent*, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuEventCreate)(phEvent, Flags)
    return err

cdef CUresult _cuEventRecord(CUevent hEvent, CUstream hStream) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuEventRecord
    cuPythonInit()
    if __cuEventRecord == NULL:
        with gil:
            raise RuntimeError('Function "cuEventRecord" not found')
    err = (<CUresult (*)(CUevent, CUstream) except ?CUDA_ERROR_NOT_FOUND nogil> __cuEventRecord)(hEvent, hStream)
    return err

cdef CUresult _cuEventRecordWithFlags(CUevent hEvent, CUstream hStream, unsigned int flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuEventRecordWithFlags
    cuPythonInit()
    if __cuEventRecordWithFlags == NULL:
        with gil:
            raise RuntimeError('Function "cuEventRecordWithFlags" not found')
    err = (<CUresult (*)(CUevent, CUstream, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuEventRecordWithFlags)(hEvent, hStream, flags)
    return err

cdef CUresult _cuEventQuery(CUevent hEvent) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuEventQuery
    cuPythonInit()
    if __cuEventQuery == NULL:
        with gil:
            raise RuntimeError('Function "cuEventQuery" not found')
    err = (<CUresult (*)(CUevent) except ?CUDA_ERROR_NOT_FOUND nogil> __cuEventQuery)(hEvent)
    return err

cdef CUresult _cuEventSynchronize(CUevent hEvent) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuEventSynchronize
    cuPythonInit()
    if __cuEventSynchronize == NULL:
        with gil:
            raise RuntimeError('Function "cuEventSynchronize" not found')
    err = (<CUresult (*)(CUevent) except ?CUDA_ERROR_NOT_FOUND nogil> __cuEventSynchronize)(hEvent)
    return err

cdef CUresult _cuEventDestroy_v2(CUevent hEvent) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuEventDestroy_v2
    cuPythonInit()
    if __cuEventDestroy_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuEventDestroy_v2" not found')
    err = (<CUresult (*)(CUevent) except ?CUDA_ERROR_NOT_FOUND nogil> __cuEventDestroy_v2)(hEvent)
    return err

cdef CUresult _cuEventElapsedTime(float* pMilliseconds, CUevent hStart, CUevent hEnd) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuEventElapsedTime
    cuPythonInit()
    if __cuEventElapsedTime == NULL:
        with gil:
            raise RuntimeError('Function "cuEventElapsedTime" not found')
    err = (<CUresult (*)(float*, CUevent, CUevent) except ?CUDA_ERROR_NOT_FOUND nogil> __cuEventElapsedTime)(pMilliseconds, hStart, hEnd)
    return err

cdef CUresult _cuEventElapsedTime_v2(float* pMilliseconds, CUevent hStart, CUevent hEnd) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuEventElapsedTime_v2
    cuPythonInit()
    if __cuEventElapsedTime_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuEventElapsedTime_v2" not found')
    err = (<CUresult (*)(float*, CUevent, CUevent) except ?CUDA_ERROR_NOT_FOUND nogil> __cuEventElapsedTime_v2)(pMilliseconds, hStart, hEnd)
    return err

cdef CUresult _cuImportExternalMemory(CUexternalMemory* extMem_out, const CUDA_EXTERNAL_MEMORY_HANDLE_DESC* memHandleDesc) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuImportExternalMemory
    cuPythonInit()
    if __cuImportExternalMemory == NULL:
        with gil:
            raise RuntimeError('Function "cuImportExternalMemory" not found')
    err = (<CUresult (*)(CUexternalMemory*, const CUDA_EXTERNAL_MEMORY_HANDLE_DESC*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuImportExternalMemory)(extMem_out, memHandleDesc)
    return err

cdef CUresult _cuExternalMemoryGetMappedBuffer(CUdeviceptr* devPtr, CUexternalMemory extMem, const CUDA_EXTERNAL_MEMORY_BUFFER_DESC* bufferDesc) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuExternalMemoryGetMappedBuffer
    cuPythonInit()
    if __cuExternalMemoryGetMappedBuffer == NULL:
        with gil:
            raise RuntimeError('Function "cuExternalMemoryGetMappedBuffer" not found')
    err = (<CUresult (*)(CUdeviceptr*, CUexternalMemory, const CUDA_EXTERNAL_MEMORY_BUFFER_DESC*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuExternalMemoryGetMappedBuffer)(devPtr, extMem, bufferDesc)
    return err

cdef CUresult _cuExternalMemoryGetMappedMipmappedArray(CUmipmappedArray* mipmap, CUexternalMemory extMem, const CUDA_EXTERNAL_MEMORY_MIPMAPPED_ARRAY_DESC* mipmapDesc) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuExternalMemoryGetMappedMipmappedArray
    cuPythonInit()
    if __cuExternalMemoryGetMappedMipmappedArray == NULL:
        with gil:
            raise RuntimeError('Function "cuExternalMemoryGetMappedMipmappedArray" not found')
    err = (<CUresult (*)(CUmipmappedArray*, CUexternalMemory, const CUDA_EXTERNAL_MEMORY_MIPMAPPED_ARRAY_DESC*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuExternalMemoryGetMappedMipmappedArray)(mipmap, extMem, mipmapDesc)
    return err

cdef CUresult _cuDestroyExternalMemory(CUexternalMemory extMem) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuDestroyExternalMemory
    cuPythonInit()
    if __cuDestroyExternalMemory == NULL:
        with gil:
            raise RuntimeError('Function "cuDestroyExternalMemory" not found')
    err = (<CUresult (*)(CUexternalMemory) except ?CUDA_ERROR_NOT_FOUND nogil> __cuDestroyExternalMemory)(extMem)
    return err

cdef CUresult _cuImportExternalSemaphore(CUexternalSemaphore* extSem_out, const CUDA_EXTERNAL_SEMAPHORE_HANDLE_DESC* semHandleDesc) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuImportExternalSemaphore
    cuPythonInit()
    if __cuImportExternalSemaphore == NULL:
        with gil:
            raise RuntimeError('Function "cuImportExternalSemaphore" not found')
    err = (<CUresult (*)(CUexternalSemaphore*, const CUDA_EXTERNAL_SEMAPHORE_HANDLE_DESC*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuImportExternalSemaphore)(extSem_out, semHandleDesc)
    return err

cdef CUresult _cuSignalExternalSemaphoresAsync(const CUexternalSemaphore* extSemArray, const CUDA_EXTERNAL_SEMAPHORE_SIGNAL_PARAMS* paramsArray, unsigned int numExtSems, CUstream stream) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuSignalExternalSemaphoresAsync
    cuPythonInit()
    if __cuSignalExternalSemaphoresAsync == NULL:
        with gil:
            raise RuntimeError('Function "cuSignalExternalSemaphoresAsync" not found')
    err = (<CUresult (*)(const CUexternalSemaphore*, const CUDA_EXTERNAL_SEMAPHORE_SIGNAL_PARAMS*, unsigned int, CUstream) except ?CUDA_ERROR_NOT_FOUND nogil> __cuSignalExternalSemaphoresAsync)(extSemArray, paramsArray, numExtSems, stream)
    return err

cdef CUresult _cuWaitExternalSemaphoresAsync(const CUexternalSemaphore* extSemArray, const CUDA_EXTERNAL_SEMAPHORE_WAIT_PARAMS* paramsArray, unsigned int numExtSems, CUstream stream) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuWaitExternalSemaphoresAsync
    cuPythonInit()
    if __cuWaitExternalSemaphoresAsync == NULL:
        with gil:
            raise RuntimeError('Function "cuWaitExternalSemaphoresAsync" not found')
    err = (<CUresult (*)(const CUexternalSemaphore*, const CUDA_EXTERNAL_SEMAPHORE_WAIT_PARAMS*, unsigned int, CUstream) except ?CUDA_ERROR_NOT_FOUND nogil> __cuWaitExternalSemaphoresAsync)(extSemArray, paramsArray, numExtSems, stream)
    return err

cdef CUresult _cuDestroyExternalSemaphore(CUexternalSemaphore extSem) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuDestroyExternalSemaphore
    cuPythonInit()
    if __cuDestroyExternalSemaphore == NULL:
        with gil:
            raise RuntimeError('Function "cuDestroyExternalSemaphore" not found')
    err = (<CUresult (*)(CUexternalSemaphore) except ?CUDA_ERROR_NOT_FOUND nogil> __cuDestroyExternalSemaphore)(extSem)
    return err

cdef CUresult _cuStreamWaitValue32_v2(CUstream stream, CUdeviceptr addr, cuuint32_t value, unsigned int flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuStreamWaitValue32_v2
    cuPythonInit()
    if __cuStreamWaitValue32_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuStreamWaitValue32_v2" not found')
    err = (<CUresult (*)(CUstream, CUdeviceptr, cuuint32_t, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuStreamWaitValue32_v2)(stream, addr, value, flags)
    return err

cdef CUresult _cuStreamWaitValue64_v2(CUstream stream, CUdeviceptr addr, cuuint64_t value, unsigned int flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuStreamWaitValue64_v2
    cuPythonInit()
    if __cuStreamWaitValue64_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuStreamWaitValue64_v2" not found')
    err = (<CUresult (*)(CUstream, CUdeviceptr, cuuint64_t, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuStreamWaitValue64_v2)(stream, addr, value, flags)
    return err

cdef CUresult _cuStreamWriteValue32_v2(CUstream stream, CUdeviceptr addr, cuuint32_t value, unsigned int flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuStreamWriteValue32_v2
    cuPythonInit()
    if __cuStreamWriteValue32_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuStreamWriteValue32_v2" not found')
    err = (<CUresult (*)(CUstream, CUdeviceptr, cuuint32_t, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuStreamWriteValue32_v2)(stream, addr, value, flags)
    return err

cdef CUresult _cuStreamWriteValue64_v2(CUstream stream, CUdeviceptr addr, cuuint64_t value, unsigned int flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuStreamWriteValue64_v2
    cuPythonInit()
    if __cuStreamWriteValue64_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuStreamWriteValue64_v2" not found')
    err = (<CUresult (*)(CUstream, CUdeviceptr, cuuint64_t, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuStreamWriteValue64_v2)(stream, addr, value, flags)
    return err

cdef CUresult _cuStreamBatchMemOp_v2(CUstream stream, unsigned int count, CUstreamBatchMemOpParams* paramArray, unsigned int flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuStreamBatchMemOp_v2
    cuPythonInit()
    if __cuStreamBatchMemOp_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuStreamBatchMemOp_v2" not found')
    err = (<CUresult (*)(CUstream, unsigned int, CUstreamBatchMemOpParams*, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuStreamBatchMemOp_v2)(stream, count, paramArray, flags)
    return err

cdef CUresult _cuFuncGetAttribute(int* pi, CUfunction_attribute attrib, CUfunction hfunc) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuFuncGetAttribute
    cuPythonInit()
    if __cuFuncGetAttribute == NULL:
        with gil:
            raise RuntimeError('Function "cuFuncGetAttribute" not found')
    err = (<CUresult (*)(int*, CUfunction_attribute, CUfunction) except ?CUDA_ERROR_NOT_FOUND nogil> __cuFuncGetAttribute)(pi, attrib, hfunc)
    return err

cdef CUresult _cuFuncSetAttribute(CUfunction hfunc, CUfunction_attribute attrib, int value) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuFuncSetAttribute
    cuPythonInit()
    if __cuFuncSetAttribute == NULL:
        with gil:
            raise RuntimeError('Function "cuFuncSetAttribute" not found')
    err = (<CUresult (*)(CUfunction, CUfunction_attribute, int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuFuncSetAttribute)(hfunc, attrib, value)
    return err

cdef CUresult _cuFuncSetCacheConfig(CUfunction hfunc, CUfunc_cache config) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuFuncSetCacheConfig
    cuPythonInit()
    if __cuFuncSetCacheConfig == NULL:
        with gil:
            raise RuntimeError('Function "cuFuncSetCacheConfig" not found')
    err = (<CUresult (*)(CUfunction, CUfunc_cache) except ?CUDA_ERROR_NOT_FOUND nogil> __cuFuncSetCacheConfig)(hfunc, config)
    return err

cdef CUresult _cuFuncGetModule(CUmodule* hmod, CUfunction hfunc) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuFuncGetModule
    cuPythonInit()
    if __cuFuncGetModule == NULL:
        with gil:
            raise RuntimeError('Function "cuFuncGetModule" not found')
    err = (<CUresult (*)(CUmodule*, CUfunction) except ?CUDA_ERROR_NOT_FOUND nogil> __cuFuncGetModule)(hmod, hfunc)
    return err

cdef CUresult _cuFuncGetName(const char** name, CUfunction hfunc) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuFuncGetName
    cuPythonInit()
    if __cuFuncGetName == NULL:
        with gil:
            raise RuntimeError('Function "cuFuncGetName" not found')
    err = (<CUresult (*)(const char**, CUfunction) except ?CUDA_ERROR_NOT_FOUND nogil> __cuFuncGetName)(name, hfunc)
    return err

cdef CUresult _cuFuncGetParamInfo(CUfunction func, size_t paramIndex, size_t* paramOffset, size_t* paramSize) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuFuncGetParamInfo
    cuPythonInit()
    if __cuFuncGetParamInfo == NULL:
        with gil:
            raise RuntimeError('Function "cuFuncGetParamInfo" not found')
    err = (<CUresult (*)(CUfunction, size_t, size_t*, size_t*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuFuncGetParamInfo)(func, paramIndex, paramOffset, paramSize)
    return err

cdef CUresult _cuFuncIsLoaded(CUfunctionLoadingState* state, CUfunction function) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuFuncIsLoaded
    cuPythonInit()
    if __cuFuncIsLoaded == NULL:
        with gil:
            raise RuntimeError('Function "cuFuncIsLoaded" not found')
    err = (<CUresult (*)(CUfunctionLoadingState*, CUfunction) except ?CUDA_ERROR_NOT_FOUND nogil> __cuFuncIsLoaded)(state, function)
    return err

cdef CUresult _cuFuncLoad(CUfunction function) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuFuncLoad
    cuPythonInit()
    if __cuFuncLoad == NULL:
        with gil:
            raise RuntimeError('Function "cuFuncLoad" not found')
    err = (<CUresult (*)(CUfunction) except ?CUDA_ERROR_NOT_FOUND nogil> __cuFuncLoad)(function)
    return err

cdef CUresult _cuLaunchKernel(CUfunction f, unsigned int gridDimX, unsigned int gridDimY, unsigned int gridDimZ, unsigned int blockDimX, unsigned int blockDimY, unsigned int blockDimZ, unsigned int sharedMemBytes, CUstream hStream, void** kernelParams, void** extra) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuLaunchKernel
    cuPythonInit()
    if __cuLaunchKernel == NULL:
        with gil:
            raise RuntimeError('Function "cuLaunchKernel" not found')
    err = (<CUresult (*)(CUfunction, unsigned int, unsigned int, unsigned int, unsigned int, unsigned int, unsigned int, unsigned int, CUstream, void**, void**) except ?CUDA_ERROR_NOT_FOUND nogil> __cuLaunchKernel)(f, gridDimX, gridDimY, gridDimZ, blockDimX, blockDimY, blockDimZ, sharedMemBytes, hStream, kernelParams, extra)
    return err

cdef CUresult _cuLaunchKernelEx(const CUlaunchConfig* config, CUfunction f, void** kernelParams, void** extra) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuLaunchKernelEx
    cuPythonInit()
    if __cuLaunchKernelEx == NULL:
        with gil:
            raise RuntimeError('Function "cuLaunchKernelEx" not found')
    err = (<CUresult (*)(const CUlaunchConfig*, CUfunction, void**, void**) except ?CUDA_ERROR_NOT_FOUND nogil> __cuLaunchKernelEx)(config, f, kernelParams, extra)
    return err

cdef CUresult _cuLaunchCooperativeKernel(CUfunction f, unsigned int gridDimX, unsigned int gridDimY, unsigned int gridDimZ, unsigned int blockDimX, unsigned int blockDimY, unsigned int blockDimZ, unsigned int sharedMemBytes, CUstream hStream, void** kernelParams) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuLaunchCooperativeKernel
    cuPythonInit()
    if __cuLaunchCooperativeKernel == NULL:
        with gil:
            raise RuntimeError('Function "cuLaunchCooperativeKernel" not found')
    err = (<CUresult (*)(CUfunction, unsigned int, unsigned int, unsigned int, unsigned int, unsigned int, unsigned int, unsigned int, CUstream, void**) except ?CUDA_ERROR_NOT_FOUND nogil> __cuLaunchCooperativeKernel)(f, gridDimX, gridDimY, gridDimZ, blockDimX, blockDimY, blockDimZ, sharedMemBytes, hStream, kernelParams)
    return err

cdef CUresult _cuLaunchCooperativeKernelMultiDevice(CUDA_LAUNCH_PARAMS* launchParamsList, unsigned int numDevices, unsigned int flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuLaunchCooperativeKernelMultiDevice
    cuPythonInit()
    if __cuLaunchCooperativeKernelMultiDevice == NULL:
        with gil:
            raise RuntimeError('Function "cuLaunchCooperativeKernelMultiDevice" not found')
    err = (<CUresult (*)(CUDA_LAUNCH_PARAMS*, unsigned int, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuLaunchCooperativeKernelMultiDevice)(launchParamsList, numDevices, flags)
    return err

cdef CUresult _cuLaunchHostFunc(CUstream hStream, CUhostFn fn, void* userData) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuLaunchHostFunc
    cuPythonInit()
    if __cuLaunchHostFunc == NULL:
        with gil:
            raise RuntimeError('Function "cuLaunchHostFunc" not found')
    err = (<CUresult (*)(CUstream, CUhostFn, void*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuLaunchHostFunc)(hStream, fn, userData)
    return err

cdef CUresult _cuFuncSetBlockShape(CUfunction hfunc, int x, int y, int z) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuFuncSetBlockShape
    cuPythonInit()
    if __cuFuncSetBlockShape == NULL:
        with gil:
            raise RuntimeError('Function "cuFuncSetBlockShape" not found')
    err = (<CUresult (*)(CUfunction, int, int, int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuFuncSetBlockShape)(hfunc, x, y, z)
    return err

cdef CUresult _cuFuncSetSharedSize(CUfunction hfunc, unsigned int numbytes) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuFuncSetSharedSize
    cuPythonInit()
    if __cuFuncSetSharedSize == NULL:
        with gil:
            raise RuntimeError('Function "cuFuncSetSharedSize" not found')
    err = (<CUresult (*)(CUfunction, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuFuncSetSharedSize)(hfunc, numbytes)
    return err

cdef CUresult _cuParamSetSize(CUfunction hfunc, unsigned int numbytes) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuParamSetSize
    cuPythonInit()
    if __cuParamSetSize == NULL:
        with gil:
            raise RuntimeError('Function "cuParamSetSize" not found')
    err = (<CUresult (*)(CUfunction, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuParamSetSize)(hfunc, numbytes)
    return err

cdef CUresult _cuParamSeti(CUfunction hfunc, int offset, unsigned int value) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuParamSeti
    cuPythonInit()
    if __cuParamSeti == NULL:
        with gil:
            raise RuntimeError('Function "cuParamSeti" not found')
    err = (<CUresult (*)(CUfunction, int, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuParamSeti)(hfunc, offset, value)
    return err

cdef CUresult _cuParamSetf(CUfunction hfunc, int offset, float value) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuParamSetf
    cuPythonInit()
    if __cuParamSetf == NULL:
        with gil:
            raise RuntimeError('Function "cuParamSetf" not found')
    err = (<CUresult (*)(CUfunction, int, float) except ?CUDA_ERROR_NOT_FOUND nogil> __cuParamSetf)(hfunc, offset, value)
    return err

cdef CUresult _cuParamSetv(CUfunction hfunc, int offset, void* ptr, unsigned int numbytes) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuParamSetv
    cuPythonInit()
    if __cuParamSetv == NULL:
        with gil:
            raise RuntimeError('Function "cuParamSetv" not found')
    err = (<CUresult (*)(CUfunction, int, void*, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuParamSetv)(hfunc, offset, ptr, numbytes)
    return err

cdef CUresult _cuLaunch(CUfunction f) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuLaunch
    cuPythonInit()
    if __cuLaunch == NULL:
        with gil:
            raise RuntimeError('Function "cuLaunch" not found')
    err = (<CUresult (*)(CUfunction) except ?CUDA_ERROR_NOT_FOUND nogil> __cuLaunch)(f)
    return err

cdef CUresult _cuLaunchGrid(CUfunction f, int grid_width, int grid_height) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuLaunchGrid
    cuPythonInit()
    if __cuLaunchGrid == NULL:
        with gil:
            raise RuntimeError('Function "cuLaunchGrid" not found')
    err = (<CUresult (*)(CUfunction, int, int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuLaunchGrid)(f, grid_width, grid_height)
    return err

cdef CUresult _cuLaunchGridAsync(CUfunction f, int grid_width, int grid_height, CUstream hStream) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuLaunchGridAsync
    cuPythonInit()
    if __cuLaunchGridAsync == NULL:
        with gil:
            raise RuntimeError('Function "cuLaunchGridAsync" not found')
    err = (<CUresult (*)(CUfunction, int, int, CUstream) except ?CUDA_ERROR_NOT_FOUND nogil> __cuLaunchGridAsync)(f, grid_width, grid_height, hStream)
    return err

cdef CUresult _cuParamSetTexRef(CUfunction hfunc, int texunit, CUtexref hTexRef) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuParamSetTexRef
    cuPythonInit()
    if __cuParamSetTexRef == NULL:
        with gil:
            raise RuntimeError('Function "cuParamSetTexRef" not found')
    err = (<CUresult (*)(CUfunction, int, CUtexref) except ?CUDA_ERROR_NOT_FOUND nogil> __cuParamSetTexRef)(hfunc, texunit, hTexRef)
    return err

cdef CUresult _cuFuncSetSharedMemConfig(CUfunction hfunc, CUsharedconfig config) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuFuncSetSharedMemConfig
    cuPythonInit()
    if __cuFuncSetSharedMemConfig == NULL:
        with gil:
            raise RuntimeError('Function "cuFuncSetSharedMemConfig" not found')
    err = (<CUresult (*)(CUfunction, CUsharedconfig) except ?CUDA_ERROR_NOT_FOUND nogil> __cuFuncSetSharedMemConfig)(hfunc, config)
    return err

cdef CUresult _cuGraphCreate(CUgraph* phGraph, unsigned int flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphCreate
    cuPythonInit()
    if __cuGraphCreate == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphCreate" not found')
    err = (<CUresult (*)(CUgraph*, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphCreate)(phGraph, flags)
    return err

cdef CUresult _cuGraphAddKernelNode_v2(CUgraphNode* phGraphNode, CUgraph hGraph, const CUgraphNode* dependencies, size_t numDependencies, const CUDA_KERNEL_NODE_PARAMS* nodeParams) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphAddKernelNode_v2
    cuPythonInit()
    if __cuGraphAddKernelNode_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphAddKernelNode_v2" not found')
    err = (<CUresult (*)(CUgraphNode*, CUgraph, const CUgraphNode*, size_t, const CUDA_KERNEL_NODE_PARAMS*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphAddKernelNode_v2)(phGraphNode, hGraph, dependencies, numDependencies, nodeParams)
    return err

cdef CUresult _cuGraphKernelNodeGetParams_v2(CUgraphNode hNode, CUDA_KERNEL_NODE_PARAMS* nodeParams) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphKernelNodeGetParams_v2
    cuPythonInit()
    if __cuGraphKernelNodeGetParams_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphKernelNodeGetParams_v2" not found')
    err = (<CUresult (*)(CUgraphNode, CUDA_KERNEL_NODE_PARAMS*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphKernelNodeGetParams_v2)(hNode, nodeParams)
    return err

cdef CUresult _cuGraphKernelNodeSetParams_v2(CUgraphNode hNode, const CUDA_KERNEL_NODE_PARAMS* nodeParams) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphKernelNodeSetParams_v2
    cuPythonInit()
    if __cuGraphKernelNodeSetParams_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphKernelNodeSetParams_v2" not found')
    err = (<CUresult (*)(CUgraphNode, const CUDA_KERNEL_NODE_PARAMS*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphKernelNodeSetParams_v2)(hNode, nodeParams)
    return err

cdef CUresult _cuGraphAddMemcpyNode(CUgraphNode* phGraphNode, CUgraph hGraph, const CUgraphNode* dependencies, size_t numDependencies, const CUDA_MEMCPY3D* copyParams, CUcontext ctx) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphAddMemcpyNode
    cuPythonInit()
    if __cuGraphAddMemcpyNode == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphAddMemcpyNode" not found')
    err = (<CUresult (*)(CUgraphNode*, CUgraph, const CUgraphNode*, size_t, const CUDA_MEMCPY3D*, CUcontext) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphAddMemcpyNode)(phGraphNode, hGraph, dependencies, numDependencies, copyParams, ctx)
    return err

cdef CUresult _cuGraphMemcpyNodeGetParams(CUgraphNode hNode, CUDA_MEMCPY3D* nodeParams) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphMemcpyNodeGetParams
    cuPythonInit()
    if __cuGraphMemcpyNodeGetParams == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphMemcpyNodeGetParams" not found')
    err = (<CUresult (*)(CUgraphNode, CUDA_MEMCPY3D*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphMemcpyNodeGetParams)(hNode, nodeParams)
    return err

cdef CUresult _cuGraphMemcpyNodeSetParams(CUgraphNode hNode, const CUDA_MEMCPY3D* nodeParams) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphMemcpyNodeSetParams
    cuPythonInit()
    if __cuGraphMemcpyNodeSetParams == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphMemcpyNodeSetParams" not found')
    err = (<CUresult (*)(CUgraphNode, const CUDA_MEMCPY3D*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphMemcpyNodeSetParams)(hNode, nodeParams)
    return err

cdef CUresult _cuGraphAddMemsetNode(CUgraphNode* phGraphNode, CUgraph hGraph, const CUgraphNode* dependencies, size_t numDependencies, const CUDA_MEMSET_NODE_PARAMS* memsetParams, CUcontext ctx) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphAddMemsetNode
    cuPythonInit()
    if __cuGraphAddMemsetNode == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphAddMemsetNode" not found')
    err = (<CUresult (*)(CUgraphNode*, CUgraph, const CUgraphNode*, size_t, const CUDA_MEMSET_NODE_PARAMS*, CUcontext) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphAddMemsetNode)(phGraphNode, hGraph, dependencies, numDependencies, memsetParams, ctx)
    return err

cdef CUresult _cuGraphMemsetNodeGetParams(CUgraphNode hNode, CUDA_MEMSET_NODE_PARAMS* nodeParams) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphMemsetNodeGetParams
    cuPythonInit()
    if __cuGraphMemsetNodeGetParams == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphMemsetNodeGetParams" not found')
    err = (<CUresult (*)(CUgraphNode, CUDA_MEMSET_NODE_PARAMS*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphMemsetNodeGetParams)(hNode, nodeParams)
    return err

cdef CUresult _cuGraphMemsetNodeSetParams(CUgraphNode hNode, const CUDA_MEMSET_NODE_PARAMS* nodeParams) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphMemsetNodeSetParams
    cuPythonInit()
    if __cuGraphMemsetNodeSetParams == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphMemsetNodeSetParams" not found')
    err = (<CUresult (*)(CUgraphNode, const CUDA_MEMSET_NODE_PARAMS*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphMemsetNodeSetParams)(hNode, nodeParams)
    return err

cdef CUresult _cuGraphAddHostNode(CUgraphNode* phGraphNode, CUgraph hGraph, const CUgraphNode* dependencies, size_t numDependencies, const CUDA_HOST_NODE_PARAMS* nodeParams) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphAddHostNode
    cuPythonInit()
    if __cuGraphAddHostNode == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphAddHostNode" not found')
    err = (<CUresult (*)(CUgraphNode*, CUgraph, const CUgraphNode*, size_t, const CUDA_HOST_NODE_PARAMS*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphAddHostNode)(phGraphNode, hGraph, dependencies, numDependencies, nodeParams)
    return err

cdef CUresult _cuGraphHostNodeGetParams(CUgraphNode hNode, CUDA_HOST_NODE_PARAMS* nodeParams) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphHostNodeGetParams
    cuPythonInit()
    if __cuGraphHostNodeGetParams == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphHostNodeGetParams" not found')
    err = (<CUresult (*)(CUgraphNode, CUDA_HOST_NODE_PARAMS*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphHostNodeGetParams)(hNode, nodeParams)
    return err

cdef CUresult _cuGraphHostNodeSetParams(CUgraphNode hNode, const CUDA_HOST_NODE_PARAMS* nodeParams) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphHostNodeSetParams
    cuPythonInit()
    if __cuGraphHostNodeSetParams == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphHostNodeSetParams" not found')
    err = (<CUresult (*)(CUgraphNode, const CUDA_HOST_NODE_PARAMS*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphHostNodeSetParams)(hNode, nodeParams)
    return err

cdef CUresult _cuGraphAddChildGraphNode(CUgraphNode* phGraphNode, CUgraph hGraph, const CUgraphNode* dependencies, size_t numDependencies, CUgraph childGraph) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphAddChildGraphNode
    cuPythonInit()
    if __cuGraphAddChildGraphNode == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphAddChildGraphNode" not found')
    err = (<CUresult (*)(CUgraphNode*, CUgraph, const CUgraphNode*, size_t, CUgraph) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphAddChildGraphNode)(phGraphNode, hGraph, dependencies, numDependencies, childGraph)
    return err

cdef CUresult _cuGraphChildGraphNodeGetGraph(CUgraphNode hNode, CUgraph* phGraph) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphChildGraphNodeGetGraph
    cuPythonInit()
    if __cuGraphChildGraphNodeGetGraph == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphChildGraphNodeGetGraph" not found')
    err = (<CUresult (*)(CUgraphNode, CUgraph*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphChildGraphNodeGetGraph)(hNode, phGraph)
    return err

cdef CUresult _cuGraphAddEmptyNode(CUgraphNode* phGraphNode, CUgraph hGraph, const CUgraphNode* dependencies, size_t numDependencies) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphAddEmptyNode
    cuPythonInit()
    if __cuGraphAddEmptyNode == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphAddEmptyNode" not found')
    err = (<CUresult (*)(CUgraphNode*, CUgraph, const CUgraphNode*, size_t) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphAddEmptyNode)(phGraphNode, hGraph, dependencies, numDependencies)
    return err

cdef CUresult _cuGraphAddEventRecordNode(CUgraphNode* phGraphNode, CUgraph hGraph, const CUgraphNode* dependencies, size_t numDependencies, CUevent event) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphAddEventRecordNode
    cuPythonInit()
    if __cuGraphAddEventRecordNode == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphAddEventRecordNode" not found')
    err = (<CUresult (*)(CUgraphNode*, CUgraph, const CUgraphNode*, size_t, CUevent) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphAddEventRecordNode)(phGraphNode, hGraph, dependencies, numDependencies, event)
    return err

cdef CUresult _cuGraphEventRecordNodeGetEvent(CUgraphNode hNode, CUevent* event_out) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphEventRecordNodeGetEvent
    cuPythonInit()
    if __cuGraphEventRecordNodeGetEvent == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphEventRecordNodeGetEvent" not found')
    err = (<CUresult (*)(CUgraphNode, CUevent*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphEventRecordNodeGetEvent)(hNode, event_out)
    return err

cdef CUresult _cuGraphEventRecordNodeSetEvent(CUgraphNode hNode, CUevent event) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphEventRecordNodeSetEvent
    cuPythonInit()
    if __cuGraphEventRecordNodeSetEvent == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphEventRecordNodeSetEvent" not found')
    err = (<CUresult (*)(CUgraphNode, CUevent) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphEventRecordNodeSetEvent)(hNode, event)
    return err

cdef CUresult _cuGraphAddEventWaitNode(CUgraphNode* phGraphNode, CUgraph hGraph, const CUgraphNode* dependencies, size_t numDependencies, CUevent event) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphAddEventWaitNode
    cuPythonInit()
    if __cuGraphAddEventWaitNode == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphAddEventWaitNode" not found')
    err = (<CUresult (*)(CUgraphNode*, CUgraph, const CUgraphNode*, size_t, CUevent) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphAddEventWaitNode)(phGraphNode, hGraph, dependencies, numDependencies, event)
    return err

cdef CUresult _cuGraphEventWaitNodeGetEvent(CUgraphNode hNode, CUevent* event_out) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphEventWaitNodeGetEvent
    cuPythonInit()
    if __cuGraphEventWaitNodeGetEvent == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphEventWaitNodeGetEvent" not found')
    err = (<CUresult (*)(CUgraphNode, CUevent*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphEventWaitNodeGetEvent)(hNode, event_out)
    return err

cdef CUresult _cuGraphEventWaitNodeSetEvent(CUgraphNode hNode, CUevent event) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphEventWaitNodeSetEvent
    cuPythonInit()
    if __cuGraphEventWaitNodeSetEvent == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphEventWaitNodeSetEvent" not found')
    err = (<CUresult (*)(CUgraphNode, CUevent) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphEventWaitNodeSetEvent)(hNode, event)
    return err

cdef CUresult _cuGraphAddExternalSemaphoresSignalNode(CUgraphNode* phGraphNode, CUgraph hGraph, const CUgraphNode* dependencies, size_t numDependencies, const CUDA_EXT_SEM_SIGNAL_NODE_PARAMS* nodeParams) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphAddExternalSemaphoresSignalNode
    cuPythonInit()
    if __cuGraphAddExternalSemaphoresSignalNode == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphAddExternalSemaphoresSignalNode" not found')
    err = (<CUresult (*)(CUgraphNode*, CUgraph, const CUgraphNode*, size_t, const CUDA_EXT_SEM_SIGNAL_NODE_PARAMS*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphAddExternalSemaphoresSignalNode)(phGraphNode, hGraph, dependencies, numDependencies, nodeParams)
    return err

cdef CUresult _cuGraphExternalSemaphoresSignalNodeGetParams(CUgraphNode hNode, CUDA_EXT_SEM_SIGNAL_NODE_PARAMS* params_out) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphExternalSemaphoresSignalNodeGetParams
    cuPythonInit()
    if __cuGraphExternalSemaphoresSignalNodeGetParams == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphExternalSemaphoresSignalNodeGetParams" not found')
    err = (<CUresult (*)(CUgraphNode, CUDA_EXT_SEM_SIGNAL_NODE_PARAMS*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphExternalSemaphoresSignalNodeGetParams)(hNode, params_out)
    return err

cdef CUresult _cuGraphExternalSemaphoresSignalNodeSetParams(CUgraphNode hNode, const CUDA_EXT_SEM_SIGNAL_NODE_PARAMS* nodeParams) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphExternalSemaphoresSignalNodeSetParams
    cuPythonInit()
    if __cuGraphExternalSemaphoresSignalNodeSetParams == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphExternalSemaphoresSignalNodeSetParams" not found')
    err = (<CUresult (*)(CUgraphNode, const CUDA_EXT_SEM_SIGNAL_NODE_PARAMS*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphExternalSemaphoresSignalNodeSetParams)(hNode, nodeParams)
    return err

cdef CUresult _cuGraphAddExternalSemaphoresWaitNode(CUgraphNode* phGraphNode, CUgraph hGraph, const CUgraphNode* dependencies, size_t numDependencies, const CUDA_EXT_SEM_WAIT_NODE_PARAMS* nodeParams) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphAddExternalSemaphoresWaitNode
    cuPythonInit()
    if __cuGraphAddExternalSemaphoresWaitNode == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphAddExternalSemaphoresWaitNode" not found')
    err = (<CUresult (*)(CUgraphNode*, CUgraph, const CUgraphNode*, size_t, const CUDA_EXT_SEM_WAIT_NODE_PARAMS*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphAddExternalSemaphoresWaitNode)(phGraphNode, hGraph, dependencies, numDependencies, nodeParams)
    return err

cdef CUresult _cuGraphExternalSemaphoresWaitNodeGetParams(CUgraphNode hNode, CUDA_EXT_SEM_WAIT_NODE_PARAMS* params_out) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphExternalSemaphoresWaitNodeGetParams
    cuPythonInit()
    if __cuGraphExternalSemaphoresWaitNodeGetParams == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphExternalSemaphoresWaitNodeGetParams" not found')
    err = (<CUresult (*)(CUgraphNode, CUDA_EXT_SEM_WAIT_NODE_PARAMS*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphExternalSemaphoresWaitNodeGetParams)(hNode, params_out)
    return err

cdef CUresult _cuGraphExternalSemaphoresWaitNodeSetParams(CUgraphNode hNode, const CUDA_EXT_SEM_WAIT_NODE_PARAMS* nodeParams) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphExternalSemaphoresWaitNodeSetParams
    cuPythonInit()
    if __cuGraphExternalSemaphoresWaitNodeSetParams == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphExternalSemaphoresWaitNodeSetParams" not found')
    err = (<CUresult (*)(CUgraphNode, const CUDA_EXT_SEM_WAIT_NODE_PARAMS*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphExternalSemaphoresWaitNodeSetParams)(hNode, nodeParams)
    return err

cdef CUresult _cuGraphAddBatchMemOpNode(CUgraphNode* phGraphNode, CUgraph hGraph, const CUgraphNode* dependencies, size_t numDependencies, const CUDA_BATCH_MEM_OP_NODE_PARAMS* nodeParams) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphAddBatchMemOpNode
    cuPythonInit()
    if __cuGraphAddBatchMemOpNode == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphAddBatchMemOpNode" not found')
    err = (<CUresult (*)(CUgraphNode*, CUgraph, const CUgraphNode*, size_t, const CUDA_BATCH_MEM_OP_NODE_PARAMS*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphAddBatchMemOpNode)(phGraphNode, hGraph, dependencies, numDependencies, nodeParams)
    return err

cdef CUresult _cuGraphBatchMemOpNodeGetParams(CUgraphNode hNode, CUDA_BATCH_MEM_OP_NODE_PARAMS* nodeParams_out) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphBatchMemOpNodeGetParams
    cuPythonInit()
    if __cuGraphBatchMemOpNodeGetParams == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphBatchMemOpNodeGetParams" not found')
    err = (<CUresult (*)(CUgraphNode, CUDA_BATCH_MEM_OP_NODE_PARAMS*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphBatchMemOpNodeGetParams)(hNode, nodeParams_out)
    return err

cdef CUresult _cuGraphBatchMemOpNodeSetParams(CUgraphNode hNode, const CUDA_BATCH_MEM_OP_NODE_PARAMS* nodeParams) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphBatchMemOpNodeSetParams
    cuPythonInit()
    if __cuGraphBatchMemOpNodeSetParams == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphBatchMemOpNodeSetParams" not found')
    err = (<CUresult (*)(CUgraphNode, const CUDA_BATCH_MEM_OP_NODE_PARAMS*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphBatchMemOpNodeSetParams)(hNode, nodeParams)
    return err

cdef CUresult _cuGraphExecBatchMemOpNodeSetParams(CUgraphExec hGraphExec, CUgraphNode hNode, const CUDA_BATCH_MEM_OP_NODE_PARAMS* nodeParams) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphExecBatchMemOpNodeSetParams
    cuPythonInit()
    if __cuGraphExecBatchMemOpNodeSetParams == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphExecBatchMemOpNodeSetParams" not found')
    err = (<CUresult (*)(CUgraphExec, CUgraphNode, const CUDA_BATCH_MEM_OP_NODE_PARAMS*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphExecBatchMemOpNodeSetParams)(hGraphExec, hNode, nodeParams)
    return err

cdef CUresult _cuGraphAddMemAllocNode(CUgraphNode* phGraphNode, CUgraph hGraph, const CUgraphNode* dependencies, size_t numDependencies, CUDA_MEM_ALLOC_NODE_PARAMS* nodeParams) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphAddMemAllocNode
    cuPythonInit()
    if __cuGraphAddMemAllocNode == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphAddMemAllocNode" not found')
    err = (<CUresult (*)(CUgraphNode*, CUgraph, const CUgraphNode*, size_t, CUDA_MEM_ALLOC_NODE_PARAMS*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphAddMemAllocNode)(phGraphNode, hGraph, dependencies, numDependencies, nodeParams)
    return err

cdef CUresult _cuGraphMemAllocNodeGetParams(CUgraphNode hNode, CUDA_MEM_ALLOC_NODE_PARAMS* params_out) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphMemAllocNodeGetParams
    cuPythonInit()
    if __cuGraphMemAllocNodeGetParams == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphMemAllocNodeGetParams" not found')
    err = (<CUresult (*)(CUgraphNode, CUDA_MEM_ALLOC_NODE_PARAMS*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphMemAllocNodeGetParams)(hNode, params_out)
    return err

cdef CUresult _cuGraphAddMemFreeNode(CUgraphNode* phGraphNode, CUgraph hGraph, const CUgraphNode* dependencies, size_t numDependencies, CUdeviceptr dptr) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphAddMemFreeNode
    cuPythonInit()
    if __cuGraphAddMemFreeNode == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphAddMemFreeNode" not found')
    err = (<CUresult (*)(CUgraphNode*, CUgraph, const CUgraphNode*, size_t, CUdeviceptr) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphAddMemFreeNode)(phGraphNode, hGraph, dependencies, numDependencies, dptr)
    return err

cdef CUresult _cuGraphMemFreeNodeGetParams(CUgraphNode hNode, CUdeviceptr* dptr_out) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphMemFreeNodeGetParams
    cuPythonInit()
    if __cuGraphMemFreeNodeGetParams == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphMemFreeNodeGetParams" not found')
    err = (<CUresult (*)(CUgraphNode, CUdeviceptr*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphMemFreeNodeGetParams)(hNode, dptr_out)
    return err

cdef CUresult _cuDeviceGraphMemTrim(CUdevice device) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuDeviceGraphMemTrim
    cuPythonInit()
    if __cuDeviceGraphMemTrim == NULL:
        with gil:
            raise RuntimeError('Function "cuDeviceGraphMemTrim" not found')
    err = (<CUresult (*)(CUdevice) except ?CUDA_ERROR_NOT_FOUND nogil> __cuDeviceGraphMemTrim)(device)
    return err

cdef CUresult _cuDeviceGetGraphMemAttribute(CUdevice device, CUgraphMem_attribute attr, void* value) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuDeviceGetGraphMemAttribute
    cuPythonInit()
    if __cuDeviceGetGraphMemAttribute == NULL:
        with gil:
            raise RuntimeError('Function "cuDeviceGetGraphMemAttribute" not found')
    err = (<CUresult (*)(CUdevice, CUgraphMem_attribute, void*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuDeviceGetGraphMemAttribute)(device, attr, value)
    return err

cdef CUresult _cuDeviceSetGraphMemAttribute(CUdevice device, CUgraphMem_attribute attr, void* value) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuDeviceSetGraphMemAttribute
    cuPythonInit()
    if __cuDeviceSetGraphMemAttribute == NULL:
        with gil:
            raise RuntimeError('Function "cuDeviceSetGraphMemAttribute" not found')
    err = (<CUresult (*)(CUdevice, CUgraphMem_attribute, void*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuDeviceSetGraphMemAttribute)(device, attr, value)
    return err

cdef CUresult _cuGraphClone(CUgraph* phGraphClone, CUgraph originalGraph) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphClone
    cuPythonInit()
    if __cuGraphClone == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphClone" not found')
    err = (<CUresult (*)(CUgraph*, CUgraph) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphClone)(phGraphClone, originalGraph)
    return err

cdef CUresult _cuGraphNodeFindInClone(CUgraphNode* phNode, CUgraphNode hOriginalNode, CUgraph hClonedGraph) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphNodeFindInClone
    cuPythonInit()
    if __cuGraphNodeFindInClone == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphNodeFindInClone" not found')
    err = (<CUresult (*)(CUgraphNode*, CUgraphNode, CUgraph) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphNodeFindInClone)(phNode, hOriginalNode, hClonedGraph)
    return err

cdef CUresult _cuGraphNodeGetType(CUgraphNode hNode, CUgraphNodeType* typename) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphNodeGetType
    cuPythonInit()
    if __cuGraphNodeGetType == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphNodeGetType" not found')
    err = (<CUresult (*)(CUgraphNode, CUgraphNodeType*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphNodeGetType)(hNode, typename)
    return err

cdef CUresult _cuGraphGetNodes(CUgraph hGraph, CUgraphNode* nodes, size_t* numNodes) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphGetNodes
    cuPythonInit()
    if __cuGraphGetNodes == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphGetNodes" not found')
    err = (<CUresult (*)(CUgraph, CUgraphNode*, size_t*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphGetNodes)(hGraph, nodes, numNodes)
    return err

cdef CUresult _cuGraphGetRootNodes(CUgraph hGraph, CUgraphNode* rootNodes, size_t* numRootNodes) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphGetRootNodes
    cuPythonInit()
    if __cuGraphGetRootNodes == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphGetRootNodes" not found')
    err = (<CUresult (*)(CUgraph, CUgraphNode*, size_t*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphGetRootNodes)(hGraph, rootNodes, numRootNodes)
    return err

cdef CUresult _cuGraphGetEdges(CUgraph hGraph, CUgraphNode* from_, CUgraphNode* to, size_t* numEdges) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphGetEdges
    cuPythonInit()
    if __cuGraphGetEdges == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphGetEdges" not found')
    err = (<CUresult (*)(CUgraph, CUgraphNode*, CUgraphNode*, size_t*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphGetEdges)(hGraph, from_, to, numEdges)
    return err

cdef CUresult _cuGraphGetEdges_v2(CUgraph hGraph, CUgraphNode* from_, CUgraphNode* to, CUgraphEdgeData* edgeData, size_t* numEdges) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphGetEdges_v2
    cuPythonInit()
    if __cuGraphGetEdges_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphGetEdges_v2" not found')
    err = (<CUresult (*)(CUgraph, CUgraphNode*, CUgraphNode*, CUgraphEdgeData*, size_t*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphGetEdges_v2)(hGraph, from_, to, edgeData, numEdges)
    return err

cdef CUresult _cuGraphNodeGetDependencies(CUgraphNode hNode, CUgraphNode* dependencies, size_t* numDependencies) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphNodeGetDependencies
    cuPythonInit()
    if __cuGraphNodeGetDependencies == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphNodeGetDependencies" not found')
    err = (<CUresult (*)(CUgraphNode, CUgraphNode*, size_t*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphNodeGetDependencies)(hNode, dependencies, numDependencies)
    return err

cdef CUresult _cuGraphNodeGetDependencies_v2(CUgraphNode hNode, CUgraphNode* dependencies, CUgraphEdgeData* edgeData, size_t* numDependencies) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphNodeGetDependencies_v2
    cuPythonInit()
    if __cuGraphNodeGetDependencies_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphNodeGetDependencies_v2" not found')
    err = (<CUresult (*)(CUgraphNode, CUgraphNode*, CUgraphEdgeData*, size_t*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphNodeGetDependencies_v2)(hNode, dependencies, edgeData, numDependencies)
    return err

cdef CUresult _cuGraphNodeGetDependentNodes(CUgraphNode hNode, CUgraphNode* dependentNodes, size_t* numDependentNodes) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphNodeGetDependentNodes
    cuPythonInit()
    if __cuGraphNodeGetDependentNodes == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphNodeGetDependentNodes" not found')
    err = (<CUresult (*)(CUgraphNode, CUgraphNode*, size_t*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphNodeGetDependentNodes)(hNode, dependentNodes, numDependentNodes)
    return err

cdef CUresult _cuGraphNodeGetDependentNodes_v2(CUgraphNode hNode, CUgraphNode* dependentNodes, CUgraphEdgeData* edgeData, size_t* numDependentNodes) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphNodeGetDependentNodes_v2
    cuPythonInit()
    if __cuGraphNodeGetDependentNodes_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphNodeGetDependentNodes_v2" not found')
    err = (<CUresult (*)(CUgraphNode, CUgraphNode*, CUgraphEdgeData*, size_t*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphNodeGetDependentNodes_v2)(hNode, dependentNodes, edgeData, numDependentNodes)
    return err

cdef CUresult _cuGraphAddDependencies(CUgraph hGraph, const CUgraphNode* from_, const CUgraphNode* to, size_t numDependencies) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphAddDependencies
    cuPythonInit()
    if __cuGraphAddDependencies == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphAddDependencies" not found')
    err = (<CUresult (*)(CUgraph, const CUgraphNode*, const CUgraphNode*, size_t) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphAddDependencies)(hGraph, from_, to, numDependencies)
    return err

cdef CUresult _cuGraphAddDependencies_v2(CUgraph hGraph, const CUgraphNode* from_, const CUgraphNode* to, const CUgraphEdgeData* edgeData, size_t numDependencies) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphAddDependencies_v2
    cuPythonInit()
    if __cuGraphAddDependencies_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphAddDependencies_v2" not found')
    err = (<CUresult (*)(CUgraph, const CUgraphNode*, const CUgraphNode*, const CUgraphEdgeData*, size_t) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphAddDependencies_v2)(hGraph, from_, to, edgeData, numDependencies)
    return err

cdef CUresult _cuGraphRemoveDependencies(CUgraph hGraph, const CUgraphNode* from_, const CUgraphNode* to, size_t numDependencies) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphRemoveDependencies
    cuPythonInit()
    if __cuGraphRemoveDependencies == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphRemoveDependencies" not found')
    err = (<CUresult (*)(CUgraph, const CUgraphNode*, const CUgraphNode*, size_t) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphRemoveDependencies)(hGraph, from_, to, numDependencies)
    return err

cdef CUresult _cuGraphRemoveDependencies_v2(CUgraph hGraph, const CUgraphNode* from_, const CUgraphNode* to, const CUgraphEdgeData* edgeData, size_t numDependencies) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphRemoveDependencies_v2
    cuPythonInit()
    if __cuGraphRemoveDependencies_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphRemoveDependencies_v2" not found')
    err = (<CUresult (*)(CUgraph, const CUgraphNode*, const CUgraphNode*, const CUgraphEdgeData*, size_t) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphRemoveDependencies_v2)(hGraph, from_, to, edgeData, numDependencies)
    return err

cdef CUresult _cuGraphDestroyNode(CUgraphNode hNode) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphDestroyNode
    cuPythonInit()
    if __cuGraphDestroyNode == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphDestroyNode" not found')
    err = (<CUresult (*)(CUgraphNode) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphDestroyNode)(hNode)
    return err

cdef CUresult _cuGraphInstantiateWithFlags(CUgraphExec* phGraphExec, CUgraph hGraph, unsigned long long flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphInstantiateWithFlags
    cuPythonInit()
    if __cuGraphInstantiateWithFlags == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphInstantiateWithFlags" not found')
    err = (<CUresult (*)(CUgraphExec*, CUgraph, unsigned long long) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphInstantiateWithFlags)(phGraphExec, hGraph, flags)
    return err

cdef CUresult _cuGraphInstantiateWithParams(CUgraphExec* phGraphExec, CUgraph hGraph, CUDA_GRAPH_INSTANTIATE_PARAMS* instantiateParams) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphInstantiateWithParams
    cuPythonInit()
    if __cuGraphInstantiateWithParams == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphInstantiateWithParams" not found')
    err = (<CUresult (*)(CUgraphExec*, CUgraph, CUDA_GRAPH_INSTANTIATE_PARAMS*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphInstantiateWithParams)(phGraphExec, hGraph, instantiateParams)
    return err

cdef CUresult _cuGraphExecGetFlags(CUgraphExec hGraphExec, cuuint64_t* flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphExecGetFlags
    cuPythonInit()
    if __cuGraphExecGetFlags == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphExecGetFlags" not found')
    err = (<CUresult (*)(CUgraphExec, cuuint64_t*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphExecGetFlags)(hGraphExec, flags)
    return err

cdef CUresult _cuGraphExecKernelNodeSetParams_v2(CUgraphExec hGraphExec, CUgraphNode hNode, const CUDA_KERNEL_NODE_PARAMS* nodeParams) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphExecKernelNodeSetParams_v2
    cuPythonInit()
    if __cuGraphExecKernelNodeSetParams_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphExecKernelNodeSetParams_v2" not found')
    err = (<CUresult (*)(CUgraphExec, CUgraphNode, const CUDA_KERNEL_NODE_PARAMS*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphExecKernelNodeSetParams_v2)(hGraphExec, hNode, nodeParams)
    return err

cdef CUresult _cuGraphExecMemcpyNodeSetParams(CUgraphExec hGraphExec, CUgraphNode hNode, const CUDA_MEMCPY3D* copyParams, CUcontext ctx) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphExecMemcpyNodeSetParams
    cuPythonInit()
    if __cuGraphExecMemcpyNodeSetParams == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphExecMemcpyNodeSetParams" not found')
    err = (<CUresult (*)(CUgraphExec, CUgraphNode, const CUDA_MEMCPY3D*, CUcontext) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphExecMemcpyNodeSetParams)(hGraphExec, hNode, copyParams, ctx)
    return err

cdef CUresult _cuGraphExecMemsetNodeSetParams(CUgraphExec hGraphExec, CUgraphNode hNode, const CUDA_MEMSET_NODE_PARAMS* memsetParams, CUcontext ctx) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphExecMemsetNodeSetParams
    cuPythonInit()
    if __cuGraphExecMemsetNodeSetParams == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphExecMemsetNodeSetParams" not found')
    err = (<CUresult (*)(CUgraphExec, CUgraphNode, const CUDA_MEMSET_NODE_PARAMS*, CUcontext) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphExecMemsetNodeSetParams)(hGraphExec, hNode, memsetParams, ctx)
    return err

cdef CUresult _cuGraphExecHostNodeSetParams(CUgraphExec hGraphExec, CUgraphNode hNode, const CUDA_HOST_NODE_PARAMS* nodeParams) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphExecHostNodeSetParams
    cuPythonInit()
    if __cuGraphExecHostNodeSetParams == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphExecHostNodeSetParams" not found')
    err = (<CUresult (*)(CUgraphExec, CUgraphNode, const CUDA_HOST_NODE_PARAMS*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphExecHostNodeSetParams)(hGraphExec, hNode, nodeParams)
    return err

cdef CUresult _cuGraphExecChildGraphNodeSetParams(CUgraphExec hGraphExec, CUgraphNode hNode, CUgraph childGraph) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphExecChildGraphNodeSetParams
    cuPythonInit()
    if __cuGraphExecChildGraphNodeSetParams == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphExecChildGraphNodeSetParams" not found')
    err = (<CUresult (*)(CUgraphExec, CUgraphNode, CUgraph) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphExecChildGraphNodeSetParams)(hGraphExec, hNode, childGraph)
    return err

cdef CUresult _cuGraphExecEventRecordNodeSetEvent(CUgraphExec hGraphExec, CUgraphNode hNode, CUevent event) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphExecEventRecordNodeSetEvent
    cuPythonInit()
    if __cuGraphExecEventRecordNodeSetEvent == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphExecEventRecordNodeSetEvent" not found')
    err = (<CUresult (*)(CUgraphExec, CUgraphNode, CUevent) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphExecEventRecordNodeSetEvent)(hGraphExec, hNode, event)
    return err

cdef CUresult _cuGraphExecEventWaitNodeSetEvent(CUgraphExec hGraphExec, CUgraphNode hNode, CUevent event) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphExecEventWaitNodeSetEvent
    cuPythonInit()
    if __cuGraphExecEventWaitNodeSetEvent == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphExecEventWaitNodeSetEvent" not found')
    err = (<CUresult (*)(CUgraphExec, CUgraphNode, CUevent) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphExecEventWaitNodeSetEvent)(hGraphExec, hNode, event)
    return err

cdef CUresult _cuGraphExecExternalSemaphoresSignalNodeSetParams(CUgraphExec hGraphExec, CUgraphNode hNode, const CUDA_EXT_SEM_SIGNAL_NODE_PARAMS* nodeParams) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphExecExternalSemaphoresSignalNodeSetParams
    cuPythonInit()
    if __cuGraphExecExternalSemaphoresSignalNodeSetParams == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphExecExternalSemaphoresSignalNodeSetParams" not found')
    err = (<CUresult (*)(CUgraphExec, CUgraphNode, const CUDA_EXT_SEM_SIGNAL_NODE_PARAMS*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphExecExternalSemaphoresSignalNodeSetParams)(hGraphExec, hNode, nodeParams)
    return err

cdef CUresult _cuGraphExecExternalSemaphoresWaitNodeSetParams(CUgraphExec hGraphExec, CUgraphNode hNode, const CUDA_EXT_SEM_WAIT_NODE_PARAMS* nodeParams) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphExecExternalSemaphoresWaitNodeSetParams
    cuPythonInit()
    if __cuGraphExecExternalSemaphoresWaitNodeSetParams == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphExecExternalSemaphoresWaitNodeSetParams" not found')
    err = (<CUresult (*)(CUgraphExec, CUgraphNode, const CUDA_EXT_SEM_WAIT_NODE_PARAMS*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphExecExternalSemaphoresWaitNodeSetParams)(hGraphExec, hNode, nodeParams)
    return err

cdef CUresult _cuGraphNodeSetEnabled(CUgraphExec hGraphExec, CUgraphNode hNode, unsigned int isEnabled) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphNodeSetEnabled
    cuPythonInit()
    if __cuGraphNodeSetEnabled == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphNodeSetEnabled" not found')
    err = (<CUresult (*)(CUgraphExec, CUgraphNode, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphNodeSetEnabled)(hGraphExec, hNode, isEnabled)
    return err

cdef CUresult _cuGraphNodeGetEnabled(CUgraphExec hGraphExec, CUgraphNode hNode, unsigned int* isEnabled) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphNodeGetEnabled
    cuPythonInit()
    if __cuGraphNodeGetEnabled == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphNodeGetEnabled" not found')
    err = (<CUresult (*)(CUgraphExec, CUgraphNode, unsigned int*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphNodeGetEnabled)(hGraphExec, hNode, isEnabled)
    return err

cdef CUresult _cuGraphUpload(CUgraphExec hGraphExec, CUstream hStream) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphUpload
    cuPythonInit()
    if __cuGraphUpload == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphUpload" not found')
    err = (<CUresult (*)(CUgraphExec, CUstream) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphUpload)(hGraphExec, hStream)
    return err

cdef CUresult _cuGraphLaunch(CUgraphExec hGraphExec, CUstream hStream) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphLaunch
    cuPythonInit()
    if __cuGraphLaunch == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphLaunch" not found')
    err = (<CUresult (*)(CUgraphExec, CUstream) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphLaunch)(hGraphExec, hStream)
    return err

cdef CUresult _cuGraphExecDestroy(CUgraphExec hGraphExec) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphExecDestroy
    cuPythonInit()
    if __cuGraphExecDestroy == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphExecDestroy" not found')
    err = (<CUresult (*)(CUgraphExec) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphExecDestroy)(hGraphExec)
    return err

cdef CUresult _cuGraphDestroy(CUgraph hGraph) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphDestroy
    cuPythonInit()
    if __cuGraphDestroy == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphDestroy" not found')
    err = (<CUresult (*)(CUgraph) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphDestroy)(hGraph)
    return err

cdef CUresult _cuGraphExecUpdate_v2(CUgraphExec hGraphExec, CUgraph hGraph, CUgraphExecUpdateResultInfo* resultInfo) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphExecUpdate_v2
    cuPythonInit()
    if __cuGraphExecUpdate_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphExecUpdate_v2" not found')
    err = (<CUresult (*)(CUgraphExec, CUgraph, CUgraphExecUpdateResultInfo*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphExecUpdate_v2)(hGraphExec, hGraph, resultInfo)
    return err

cdef CUresult _cuGraphKernelNodeCopyAttributes(CUgraphNode dst, CUgraphNode src) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphKernelNodeCopyAttributes
    cuPythonInit()
    if __cuGraphKernelNodeCopyAttributes == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphKernelNodeCopyAttributes" not found')
    err = (<CUresult (*)(CUgraphNode, CUgraphNode) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphKernelNodeCopyAttributes)(dst, src)
    return err

cdef CUresult _cuGraphKernelNodeGetAttribute(CUgraphNode hNode, CUkernelNodeAttrID attr, CUkernelNodeAttrValue* value_out) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphKernelNodeGetAttribute
    cuPythonInit()
    if __cuGraphKernelNodeGetAttribute == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphKernelNodeGetAttribute" not found')
    err = (<CUresult (*)(CUgraphNode, CUkernelNodeAttrID, CUkernelNodeAttrValue*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphKernelNodeGetAttribute)(hNode, attr, value_out)
    return err

cdef CUresult _cuGraphKernelNodeSetAttribute(CUgraphNode hNode, CUkernelNodeAttrID attr, const CUkernelNodeAttrValue* value) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphKernelNodeSetAttribute
    cuPythonInit()
    if __cuGraphKernelNodeSetAttribute == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphKernelNodeSetAttribute" not found')
    err = (<CUresult (*)(CUgraphNode, CUkernelNodeAttrID, const CUkernelNodeAttrValue*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphKernelNodeSetAttribute)(hNode, attr, value)
    return err

cdef CUresult _cuGraphDebugDotPrint(CUgraph hGraph, const char* path, unsigned int flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphDebugDotPrint
    cuPythonInit()
    if __cuGraphDebugDotPrint == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphDebugDotPrint" not found')
    err = (<CUresult (*)(CUgraph, const char*, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphDebugDotPrint)(hGraph, path, flags)
    return err

cdef CUresult _cuUserObjectCreate(CUuserObject* object_out, void* ptr, CUhostFn destroy, unsigned int initialRefcount, unsigned int flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuUserObjectCreate
    cuPythonInit()
    if __cuUserObjectCreate == NULL:
        with gil:
            raise RuntimeError('Function "cuUserObjectCreate" not found')
    err = (<CUresult (*)(CUuserObject*, void*, CUhostFn, unsigned int, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuUserObjectCreate)(object_out, ptr, destroy, initialRefcount, flags)
    return err

cdef CUresult _cuUserObjectRetain(CUuserObject object, unsigned int count) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuUserObjectRetain
    cuPythonInit()
    if __cuUserObjectRetain == NULL:
        with gil:
            raise RuntimeError('Function "cuUserObjectRetain" not found')
    err = (<CUresult (*)(CUuserObject, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuUserObjectRetain)(object, count)
    return err

cdef CUresult _cuUserObjectRelease(CUuserObject object, unsigned int count) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuUserObjectRelease
    cuPythonInit()
    if __cuUserObjectRelease == NULL:
        with gil:
            raise RuntimeError('Function "cuUserObjectRelease" not found')
    err = (<CUresult (*)(CUuserObject, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuUserObjectRelease)(object, count)
    return err

cdef CUresult _cuGraphRetainUserObject(CUgraph graph, CUuserObject object, unsigned int count, unsigned int flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphRetainUserObject
    cuPythonInit()
    if __cuGraphRetainUserObject == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphRetainUserObject" not found')
    err = (<CUresult (*)(CUgraph, CUuserObject, unsigned int, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphRetainUserObject)(graph, object, count, flags)
    return err

cdef CUresult _cuGraphReleaseUserObject(CUgraph graph, CUuserObject object, unsigned int count) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphReleaseUserObject
    cuPythonInit()
    if __cuGraphReleaseUserObject == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphReleaseUserObject" not found')
    err = (<CUresult (*)(CUgraph, CUuserObject, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphReleaseUserObject)(graph, object, count)
    return err

cdef CUresult _cuGraphAddNode(CUgraphNode* phGraphNode, CUgraph hGraph, const CUgraphNode* dependencies, size_t numDependencies, CUgraphNodeParams* nodeParams) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphAddNode
    cuPythonInit()
    if __cuGraphAddNode == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphAddNode" not found')
    err = (<CUresult (*)(CUgraphNode*, CUgraph, const CUgraphNode*, size_t, CUgraphNodeParams*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphAddNode)(phGraphNode, hGraph, dependencies, numDependencies, nodeParams)
    return err

cdef CUresult _cuGraphAddNode_v2(CUgraphNode* phGraphNode, CUgraph hGraph, const CUgraphNode* dependencies, const CUgraphEdgeData* dependencyData, size_t numDependencies, CUgraphNodeParams* nodeParams) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphAddNode_v2
    cuPythonInit()
    if __cuGraphAddNode_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphAddNode_v2" not found')
    err = (<CUresult (*)(CUgraphNode*, CUgraph, const CUgraphNode*, const CUgraphEdgeData*, size_t, CUgraphNodeParams*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphAddNode_v2)(phGraphNode, hGraph, dependencies, dependencyData, numDependencies, nodeParams)
    return err

cdef CUresult _cuGraphNodeSetParams(CUgraphNode hNode, CUgraphNodeParams* nodeParams) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphNodeSetParams
    cuPythonInit()
    if __cuGraphNodeSetParams == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphNodeSetParams" not found')
    err = (<CUresult (*)(CUgraphNode, CUgraphNodeParams*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphNodeSetParams)(hNode, nodeParams)
    return err

cdef CUresult _cuGraphExecNodeSetParams(CUgraphExec hGraphExec, CUgraphNode hNode, CUgraphNodeParams* nodeParams) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphExecNodeSetParams
    cuPythonInit()
    if __cuGraphExecNodeSetParams == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphExecNodeSetParams" not found')
    err = (<CUresult (*)(CUgraphExec, CUgraphNode, CUgraphNodeParams*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphExecNodeSetParams)(hGraphExec, hNode, nodeParams)
    return err

cdef CUresult _cuGraphConditionalHandleCreate(CUgraphConditionalHandle* pHandle_out, CUgraph hGraph, CUcontext ctx, unsigned int defaultLaunchValue, unsigned int flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphConditionalHandleCreate
    cuPythonInit()
    if __cuGraphConditionalHandleCreate == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphConditionalHandleCreate" not found')
    err = (<CUresult (*)(CUgraphConditionalHandle*, CUgraph, CUcontext, unsigned int, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphConditionalHandleCreate)(pHandle_out, hGraph, ctx, defaultLaunchValue, flags)
    return err

cdef CUresult _cuOccupancyMaxActiveBlocksPerMultiprocessor(int* numBlocks, CUfunction func, int blockSize, size_t dynamicSMemSize) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuOccupancyMaxActiveBlocksPerMultiprocessor
    cuPythonInit()
    if __cuOccupancyMaxActiveBlocksPerMultiprocessor == NULL:
        with gil:
            raise RuntimeError('Function "cuOccupancyMaxActiveBlocksPerMultiprocessor" not found')
    err = (<CUresult (*)(int*, CUfunction, int, size_t) except ?CUDA_ERROR_NOT_FOUND nogil> __cuOccupancyMaxActiveBlocksPerMultiprocessor)(numBlocks, func, blockSize, dynamicSMemSize)
    return err

cdef CUresult _cuOccupancyMaxActiveBlocksPerMultiprocessorWithFlags(int* numBlocks, CUfunction func, int blockSize, size_t dynamicSMemSize, unsigned int flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuOccupancyMaxActiveBlocksPerMultiprocessorWithFlags
    cuPythonInit()
    if __cuOccupancyMaxActiveBlocksPerMultiprocessorWithFlags == NULL:
        with gil:
            raise RuntimeError('Function "cuOccupancyMaxActiveBlocksPerMultiprocessorWithFlags" not found')
    err = (<CUresult (*)(int*, CUfunction, int, size_t, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuOccupancyMaxActiveBlocksPerMultiprocessorWithFlags)(numBlocks, func, blockSize, dynamicSMemSize, flags)
    return err

cdef CUresult _cuOccupancyMaxPotentialBlockSize(int* minGridSize, int* blockSize, CUfunction func, CUoccupancyB2DSize blockSizeToDynamicSMemSize, size_t dynamicSMemSize, int blockSizeLimit) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuOccupancyMaxPotentialBlockSize
    cuPythonInit()
    if __cuOccupancyMaxPotentialBlockSize == NULL:
        with gil:
            raise RuntimeError('Function "cuOccupancyMaxPotentialBlockSize" not found')
    err = (<CUresult (*)(int*, int*, CUfunction, CUoccupancyB2DSize, size_t, int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuOccupancyMaxPotentialBlockSize)(minGridSize, blockSize, func, blockSizeToDynamicSMemSize, dynamicSMemSize, blockSizeLimit)
    return err

cdef CUresult _cuOccupancyMaxPotentialBlockSizeWithFlags(int* minGridSize, int* blockSize, CUfunction func, CUoccupancyB2DSize blockSizeToDynamicSMemSize, size_t dynamicSMemSize, int blockSizeLimit, unsigned int flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuOccupancyMaxPotentialBlockSizeWithFlags
    cuPythonInit()
    if __cuOccupancyMaxPotentialBlockSizeWithFlags == NULL:
        with gil:
            raise RuntimeError('Function "cuOccupancyMaxPotentialBlockSizeWithFlags" not found')
    err = (<CUresult (*)(int*, int*, CUfunction, CUoccupancyB2DSize, size_t, int, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuOccupancyMaxPotentialBlockSizeWithFlags)(minGridSize, blockSize, func, blockSizeToDynamicSMemSize, dynamicSMemSize, blockSizeLimit, flags)
    return err

cdef CUresult _cuOccupancyAvailableDynamicSMemPerBlock(size_t* dynamicSmemSize, CUfunction func, int numBlocks, int blockSize) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuOccupancyAvailableDynamicSMemPerBlock
    cuPythonInit()
    if __cuOccupancyAvailableDynamicSMemPerBlock == NULL:
        with gil:
            raise RuntimeError('Function "cuOccupancyAvailableDynamicSMemPerBlock" not found')
    err = (<CUresult (*)(size_t*, CUfunction, int, int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuOccupancyAvailableDynamicSMemPerBlock)(dynamicSmemSize, func, numBlocks, blockSize)
    return err

cdef CUresult _cuOccupancyMaxPotentialClusterSize(int* clusterSize, CUfunction func, const CUlaunchConfig* config) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuOccupancyMaxPotentialClusterSize
    cuPythonInit()
    if __cuOccupancyMaxPotentialClusterSize == NULL:
        with gil:
            raise RuntimeError('Function "cuOccupancyMaxPotentialClusterSize" not found')
    err = (<CUresult (*)(int*, CUfunction, const CUlaunchConfig*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuOccupancyMaxPotentialClusterSize)(clusterSize, func, config)
    return err

cdef CUresult _cuOccupancyMaxActiveClusters(int* numClusters, CUfunction func, const CUlaunchConfig* config) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuOccupancyMaxActiveClusters
    cuPythonInit()
    if __cuOccupancyMaxActiveClusters == NULL:
        with gil:
            raise RuntimeError('Function "cuOccupancyMaxActiveClusters" not found')
    err = (<CUresult (*)(int*, CUfunction, const CUlaunchConfig*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuOccupancyMaxActiveClusters)(numClusters, func, config)
    return err

cdef CUresult _cuTexRefSetArray(CUtexref hTexRef, CUarray hArray, unsigned int Flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuTexRefSetArray
    cuPythonInit()
    if __cuTexRefSetArray == NULL:
        with gil:
            raise RuntimeError('Function "cuTexRefSetArray" not found')
    err = (<CUresult (*)(CUtexref, CUarray, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuTexRefSetArray)(hTexRef, hArray, Flags)
    return err

cdef CUresult _cuTexRefSetMipmappedArray(CUtexref hTexRef, CUmipmappedArray hMipmappedArray, unsigned int Flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuTexRefSetMipmappedArray
    cuPythonInit()
    if __cuTexRefSetMipmappedArray == NULL:
        with gil:
            raise RuntimeError('Function "cuTexRefSetMipmappedArray" not found')
    err = (<CUresult (*)(CUtexref, CUmipmappedArray, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuTexRefSetMipmappedArray)(hTexRef, hMipmappedArray, Flags)
    return err

cdef CUresult _cuTexRefSetAddress_v2(size_t* ByteOffset, CUtexref hTexRef, CUdeviceptr dptr, size_t numbytes) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuTexRefSetAddress_v2
    cuPythonInit()
    if __cuTexRefSetAddress_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuTexRefSetAddress_v2" not found')
    err = (<CUresult (*)(size_t*, CUtexref, CUdeviceptr, size_t) except ?CUDA_ERROR_NOT_FOUND nogil> __cuTexRefSetAddress_v2)(ByteOffset, hTexRef, dptr, numbytes)
    return err

cdef CUresult _cuTexRefSetAddress2D_v3(CUtexref hTexRef, const CUDA_ARRAY_DESCRIPTOR* desc, CUdeviceptr dptr, size_t Pitch) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuTexRefSetAddress2D_v3
    cuPythonInit()
    if __cuTexRefSetAddress2D_v3 == NULL:
        with gil:
            raise RuntimeError('Function "cuTexRefSetAddress2D_v3" not found')
    err = (<CUresult (*)(CUtexref, const CUDA_ARRAY_DESCRIPTOR*, CUdeviceptr, size_t) except ?CUDA_ERROR_NOT_FOUND nogil> __cuTexRefSetAddress2D_v3)(hTexRef, desc, dptr, Pitch)
    return err

cdef CUresult _cuTexRefSetFormat(CUtexref hTexRef, CUarray_format fmt, int NumPackedComponents) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuTexRefSetFormat
    cuPythonInit()
    if __cuTexRefSetFormat == NULL:
        with gil:
            raise RuntimeError('Function "cuTexRefSetFormat" not found')
    err = (<CUresult (*)(CUtexref, CUarray_format, int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuTexRefSetFormat)(hTexRef, fmt, NumPackedComponents)
    return err

cdef CUresult _cuTexRefSetAddressMode(CUtexref hTexRef, int dim, CUaddress_mode am) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuTexRefSetAddressMode
    cuPythonInit()
    if __cuTexRefSetAddressMode == NULL:
        with gil:
            raise RuntimeError('Function "cuTexRefSetAddressMode" not found')
    err = (<CUresult (*)(CUtexref, int, CUaddress_mode) except ?CUDA_ERROR_NOT_FOUND nogil> __cuTexRefSetAddressMode)(hTexRef, dim, am)
    return err

cdef CUresult _cuTexRefSetFilterMode(CUtexref hTexRef, CUfilter_mode fm) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuTexRefSetFilterMode
    cuPythonInit()
    if __cuTexRefSetFilterMode == NULL:
        with gil:
            raise RuntimeError('Function "cuTexRefSetFilterMode" not found')
    err = (<CUresult (*)(CUtexref, CUfilter_mode) except ?CUDA_ERROR_NOT_FOUND nogil> __cuTexRefSetFilterMode)(hTexRef, fm)
    return err

cdef CUresult _cuTexRefSetMipmapFilterMode(CUtexref hTexRef, CUfilter_mode fm) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuTexRefSetMipmapFilterMode
    cuPythonInit()
    if __cuTexRefSetMipmapFilterMode == NULL:
        with gil:
            raise RuntimeError('Function "cuTexRefSetMipmapFilterMode" not found')
    err = (<CUresult (*)(CUtexref, CUfilter_mode) except ?CUDA_ERROR_NOT_FOUND nogil> __cuTexRefSetMipmapFilterMode)(hTexRef, fm)
    return err

cdef CUresult _cuTexRefSetMipmapLevelBias(CUtexref hTexRef, float bias) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuTexRefSetMipmapLevelBias
    cuPythonInit()
    if __cuTexRefSetMipmapLevelBias == NULL:
        with gil:
            raise RuntimeError('Function "cuTexRefSetMipmapLevelBias" not found')
    err = (<CUresult (*)(CUtexref, float) except ?CUDA_ERROR_NOT_FOUND nogil> __cuTexRefSetMipmapLevelBias)(hTexRef, bias)
    return err

cdef CUresult _cuTexRefSetMipmapLevelClamp(CUtexref hTexRef, float minMipmapLevelClamp, float maxMipmapLevelClamp) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuTexRefSetMipmapLevelClamp
    cuPythonInit()
    if __cuTexRefSetMipmapLevelClamp == NULL:
        with gil:
            raise RuntimeError('Function "cuTexRefSetMipmapLevelClamp" not found')
    err = (<CUresult (*)(CUtexref, float, float) except ?CUDA_ERROR_NOT_FOUND nogil> __cuTexRefSetMipmapLevelClamp)(hTexRef, minMipmapLevelClamp, maxMipmapLevelClamp)
    return err

cdef CUresult _cuTexRefSetMaxAnisotropy(CUtexref hTexRef, unsigned int maxAniso) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuTexRefSetMaxAnisotropy
    cuPythonInit()
    if __cuTexRefSetMaxAnisotropy == NULL:
        with gil:
            raise RuntimeError('Function "cuTexRefSetMaxAnisotropy" not found')
    err = (<CUresult (*)(CUtexref, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuTexRefSetMaxAnisotropy)(hTexRef, maxAniso)
    return err

cdef CUresult _cuTexRefSetBorderColor(CUtexref hTexRef, float* pBorderColor) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuTexRefSetBorderColor
    cuPythonInit()
    if __cuTexRefSetBorderColor == NULL:
        with gil:
            raise RuntimeError('Function "cuTexRefSetBorderColor" not found')
    err = (<CUresult (*)(CUtexref, float*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuTexRefSetBorderColor)(hTexRef, pBorderColor)
    return err

cdef CUresult _cuTexRefSetFlags(CUtexref hTexRef, unsigned int Flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuTexRefSetFlags
    cuPythonInit()
    if __cuTexRefSetFlags == NULL:
        with gil:
            raise RuntimeError('Function "cuTexRefSetFlags" not found')
    err = (<CUresult (*)(CUtexref, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuTexRefSetFlags)(hTexRef, Flags)
    return err

cdef CUresult _cuTexRefGetAddress_v2(CUdeviceptr* pdptr, CUtexref hTexRef) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuTexRefGetAddress_v2
    cuPythonInit()
    if __cuTexRefGetAddress_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuTexRefGetAddress_v2" not found')
    err = (<CUresult (*)(CUdeviceptr*, CUtexref) except ?CUDA_ERROR_NOT_FOUND nogil> __cuTexRefGetAddress_v2)(pdptr, hTexRef)
    return err

cdef CUresult _cuTexRefGetArray(CUarray* phArray, CUtexref hTexRef) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuTexRefGetArray
    cuPythonInit()
    if __cuTexRefGetArray == NULL:
        with gil:
            raise RuntimeError('Function "cuTexRefGetArray" not found')
    err = (<CUresult (*)(CUarray*, CUtexref) except ?CUDA_ERROR_NOT_FOUND nogil> __cuTexRefGetArray)(phArray, hTexRef)
    return err

cdef CUresult _cuTexRefGetMipmappedArray(CUmipmappedArray* phMipmappedArray, CUtexref hTexRef) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuTexRefGetMipmappedArray
    cuPythonInit()
    if __cuTexRefGetMipmappedArray == NULL:
        with gil:
            raise RuntimeError('Function "cuTexRefGetMipmappedArray" not found')
    err = (<CUresult (*)(CUmipmappedArray*, CUtexref) except ?CUDA_ERROR_NOT_FOUND nogil> __cuTexRefGetMipmappedArray)(phMipmappedArray, hTexRef)
    return err

cdef CUresult _cuTexRefGetAddressMode(CUaddress_mode* pam, CUtexref hTexRef, int dim) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuTexRefGetAddressMode
    cuPythonInit()
    if __cuTexRefGetAddressMode == NULL:
        with gil:
            raise RuntimeError('Function "cuTexRefGetAddressMode" not found')
    err = (<CUresult (*)(CUaddress_mode*, CUtexref, int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuTexRefGetAddressMode)(pam, hTexRef, dim)
    return err

cdef CUresult _cuTexRefGetFilterMode(CUfilter_mode* pfm, CUtexref hTexRef) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuTexRefGetFilterMode
    cuPythonInit()
    if __cuTexRefGetFilterMode == NULL:
        with gil:
            raise RuntimeError('Function "cuTexRefGetFilterMode" not found')
    err = (<CUresult (*)(CUfilter_mode*, CUtexref) except ?CUDA_ERROR_NOT_FOUND nogil> __cuTexRefGetFilterMode)(pfm, hTexRef)
    return err

cdef CUresult _cuTexRefGetFormat(CUarray_format* pFormat, int* pNumChannels, CUtexref hTexRef) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuTexRefGetFormat
    cuPythonInit()
    if __cuTexRefGetFormat == NULL:
        with gil:
            raise RuntimeError('Function "cuTexRefGetFormat" not found')
    err = (<CUresult (*)(CUarray_format*, int*, CUtexref) except ?CUDA_ERROR_NOT_FOUND nogil> __cuTexRefGetFormat)(pFormat, pNumChannels, hTexRef)
    return err

cdef CUresult _cuTexRefGetMipmapFilterMode(CUfilter_mode* pfm, CUtexref hTexRef) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuTexRefGetMipmapFilterMode
    cuPythonInit()
    if __cuTexRefGetMipmapFilterMode == NULL:
        with gil:
            raise RuntimeError('Function "cuTexRefGetMipmapFilterMode" not found')
    err = (<CUresult (*)(CUfilter_mode*, CUtexref) except ?CUDA_ERROR_NOT_FOUND nogil> __cuTexRefGetMipmapFilterMode)(pfm, hTexRef)
    return err

cdef CUresult _cuTexRefGetMipmapLevelBias(float* pbias, CUtexref hTexRef) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuTexRefGetMipmapLevelBias
    cuPythonInit()
    if __cuTexRefGetMipmapLevelBias == NULL:
        with gil:
            raise RuntimeError('Function "cuTexRefGetMipmapLevelBias" not found')
    err = (<CUresult (*)(float*, CUtexref) except ?CUDA_ERROR_NOT_FOUND nogil> __cuTexRefGetMipmapLevelBias)(pbias, hTexRef)
    return err

cdef CUresult _cuTexRefGetMipmapLevelClamp(float* pminMipmapLevelClamp, float* pmaxMipmapLevelClamp, CUtexref hTexRef) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuTexRefGetMipmapLevelClamp
    cuPythonInit()
    if __cuTexRefGetMipmapLevelClamp == NULL:
        with gil:
            raise RuntimeError('Function "cuTexRefGetMipmapLevelClamp" not found')
    err = (<CUresult (*)(float*, float*, CUtexref) except ?CUDA_ERROR_NOT_FOUND nogil> __cuTexRefGetMipmapLevelClamp)(pminMipmapLevelClamp, pmaxMipmapLevelClamp, hTexRef)
    return err

cdef CUresult _cuTexRefGetMaxAnisotropy(int* pmaxAniso, CUtexref hTexRef) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuTexRefGetMaxAnisotropy
    cuPythonInit()
    if __cuTexRefGetMaxAnisotropy == NULL:
        with gil:
            raise RuntimeError('Function "cuTexRefGetMaxAnisotropy" not found')
    err = (<CUresult (*)(int*, CUtexref) except ?CUDA_ERROR_NOT_FOUND nogil> __cuTexRefGetMaxAnisotropy)(pmaxAniso, hTexRef)
    return err

cdef CUresult _cuTexRefGetBorderColor(float* pBorderColor, CUtexref hTexRef) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuTexRefGetBorderColor
    cuPythonInit()
    if __cuTexRefGetBorderColor == NULL:
        with gil:
            raise RuntimeError('Function "cuTexRefGetBorderColor" not found')
    err = (<CUresult (*)(float*, CUtexref) except ?CUDA_ERROR_NOT_FOUND nogil> __cuTexRefGetBorderColor)(pBorderColor, hTexRef)
    return err

cdef CUresult _cuTexRefGetFlags(unsigned int* pFlags, CUtexref hTexRef) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuTexRefGetFlags
    cuPythonInit()
    if __cuTexRefGetFlags == NULL:
        with gil:
            raise RuntimeError('Function "cuTexRefGetFlags" not found')
    err = (<CUresult (*)(unsigned int*, CUtexref) except ?CUDA_ERROR_NOT_FOUND nogil> __cuTexRefGetFlags)(pFlags, hTexRef)
    return err

cdef CUresult _cuTexRefCreate(CUtexref* pTexRef) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuTexRefCreate
    cuPythonInit()
    if __cuTexRefCreate == NULL:
        with gil:
            raise RuntimeError('Function "cuTexRefCreate" not found')
    err = (<CUresult (*)(CUtexref*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuTexRefCreate)(pTexRef)
    return err

cdef CUresult _cuTexRefDestroy(CUtexref hTexRef) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuTexRefDestroy
    cuPythonInit()
    if __cuTexRefDestroy == NULL:
        with gil:
            raise RuntimeError('Function "cuTexRefDestroy" not found')
    err = (<CUresult (*)(CUtexref) except ?CUDA_ERROR_NOT_FOUND nogil> __cuTexRefDestroy)(hTexRef)
    return err

cdef CUresult _cuSurfRefSetArray(CUsurfref hSurfRef, CUarray hArray, unsigned int Flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuSurfRefSetArray
    cuPythonInit()
    if __cuSurfRefSetArray == NULL:
        with gil:
            raise RuntimeError('Function "cuSurfRefSetArray" not found')
    err = (<CUresult (*)(CUsurfref, CUarray, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuSurfRefSetArray)(hSurfRef, hArray, Flags)
    return err

cdef CUresult _cuSurfRefGetArray(CUarray* phArray, CUsurfref hSurfRef) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuSurfRefGetArray
    cuPythonInit()
    if __cuSurfRefGetArray == NULL:
        with gil:
            raise RuntimeError('Function "cuSurfRefGetArray" not found')
    err = (<CUresult (*)(CUarray*, CUsurfref) except ?CUDA_ERROR_NOT_FOUND nogil> __cuSurfRefGetArray)(phArray, hSurfRef)
    return err

cdef CUresult _cuTexObjectCreate(CUtexObject* pTexObject, const CUDA_RESOURCE_DESC* pResDesc, const CUDA_TEXTURE_DESC* pTexDesc, const CUDA_RESOURCE_VIEW_DESC* pResViewDesc) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuTexObjectCreate
    cuPythonInit()
    if __cuTexObjectCreate == NULL:
        with gil:
            raise RuntimeError('Function "cuTexObjectCreate" not found')
    err = (<CUresult (*)(CUtexObject*, const CUDA_RESOURCE_DESC*, const CUDA_TEXTURE_DESC*, const CUDA_RESOURCE_VIEW_DESC*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuTexObjectCreate)(pTexObject, pResDesc, pTexDesc, pResViewDesc)
    return err

cdef CUresult _cuTexObjectDestroy(CUtexObject texObject) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuTexObjectDestroy
    cuPythonInit()
    if __cuTexObjectDestroy == NULL:
        with gil:
            raise RuntimeError('Function "cuTexObjectDestroy" not found')
    err = (<CUresult (*)(CUtexObject) except ?CUDA_ERROR_NOT_FOUND nogil> __cuTexObjectDestroy)(texObject)
    return err

cdef CUresult _cuTexObjectGetResourceDesc(CUDA_RESOURCE_DESC* pResDesc, CUtexObject texObject) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuTexObjectGetResourceDesc
    cuPythonInit()
    if __cuTexObjectGetResourceDesc == NULL:
        with gil:
            raise RuntimeError('Function "cuTexObjectGetResourceDesc" not found')
    err = (<CUresult (*)(CUDA_RESOURCE_DESC*, CUtexObject) except ?CUDA_ERROR_NOT_FOUND nogil> __cuTexObjectGetResourceDesc)(pResDesc, texObject)
    return err

cdef CUresult _cuTexObjectGetTextureDesc(CUDA_TEXTURE_DESC* pTexDesc, CUtexObject texObject) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuTexObjectGetTextureDesc
    cuPythonInit()
    if __cuTexObjectGetTextureDesc == NULL:
        with gil:
            raise RuntimeError('Function "cuTexObjectGetTextureDesc" not found')
    err = (<CUresult (*)(CUDA_TEXTURE_DESC*, CUtexObject) except ?CUDA_ERROR_NOT_FOUND nogil> __cuTexObjectGetTextureDesc)(pTexDesc, texObject)
    return err

cdef CUresult _cuTexObjectGetResourceViewDesc(CUDA_RESOURCE_VIEW_DESC* pResViewDesc, CUtexObject texObject) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuTexObjectGetResourceViewDesc
    cuPythonInit()
    if __cuTexObjectGetResourceViewDesc == NULL:
        with gil:
            raise RuntimeError('Function "cuTexObjectGetResourceViewDesc" not found')
    err = (<CUresult (*)(CUDA_RESOURCE_VIEW_DESC*, CUtexObject) except ?CUDA_ERROR_NOT_FOUND nogil> __cuTexObjectGetResourceViewDesc)(pResViewDesc, texObject)
    return err

cdef CUresult _cuSurfObjectCreate(CUsurfObject* pSurfObject, const CUDA_RESOURCE_DESC* pResDesc) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuSurfObjectCreate
    cuPythonInit()
    if __cuSurfObjectCreate == NULL:
        with gil:
            raise RuntimeError('Function "cuSurfObjectCreate" not found')
    err = (<CUresult (*)(CUsurfObject*, const CUDA_RESOURCE_DESC*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuSurfObjectCreate)(pSurfObject, pResDesc)
    return err

cdef CUresult _cuSurfObjectDestroy(CUsurfObject surfObject) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuSurfObjectDestroy
    cuPythonInit()
    if __cuSurfObjectDestroy == NULL:
        with gil:
            raise RuntimeError('Function "cuSurfObjectDestroy" not found')
    err = (<CUresult (*)(CUsurfObject) except ?CUDA_ERROR_NOT_FOUND nogil> __cuSurfObjectDestroy)(surfObject)
    return err

cdef CUresult _cuSurfObjectGetResourceDesc(CUDA_RESOURCE_DESC* pResDesc, CUsurfObject surfObject) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuSurfObjectGetResourceDesc
    cuPythonInit()
    if __cuSurfObjectGetResourceDesc == NULL:
        with gil:
            raise RuntimeError('Function "cuSurfObjectGetResourceDesc" not found')
    err = (<CUresult (*)(CUDA_RESOURCE_DESC*, CUsurfObject) except ?CUDA_ERROR_NOT_FOUND nogil> __cuSurfObjectGetResourceDesc)(pResDesc, surfObject)
    return err

cdef CUresult _cuTensorMapEncodeTiled(CUtensorMap* tensorMap, CUtensorMapDataType tensorDataType, cuuint32_t tensorRank, void* globalAddress, const cuuint64_t* globalDim, const cuuint64_t* globalStrides, const cuuint32_t* boxDim, const cuuint32_t* elementStrides, CUtensorMapInterleave interleave, CUtensorMapSwizzle swizzle, CUtensorMapL2promotion l2Promotion, CUtensorMapFloatOOBfill oobFill) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuTensorMapEncodeTiled
    cuPythonInit()
    if __cuTensorMapEncodeTiled == NULL:
        with gil:
            raise RuntimeError('Function "cuTensorMapEncodeTiled" not found')
    err = (<CUresult (*)(CUtensorMap*, CUtensorMapDataType, cuuint32_t, void*, const cuuint64_t*, const cuuint64_t*, const cuuint32_t*, const cuuint32_t*, CUtensorMapInterleave, CUtensorMapSwizzle, CUtensorMapL2promotion, CUtensorMapFloatOOBfill) except ?CUDA_ERROR_NOT_FOUND nogil> __cuTensorMapEncodeTiled)(tensorMap, tensorDataType, tensorRank, globalAddress, globalDim, globalStrides, boxDim, elementStrides, interleave, swizzle, l2Promotion, oobFill)
    return err

cdef CUresult _cuTensorMapEncodeIm2col(CUtensorMap* tensorMap, CUtensorMapDataType tensorDataType, cuuint32_t tensorRank, void* globalAddress, const cuuint64_t* globalDim, const cuuint64_t* globalStrides, const int* pixelBoxLowerCorner, const int* pixelBoxUpperCorner, cuuint32_t channelsPerPixel, cuuint32_t pixelsPerColumn, const cuuint32_t* elementStrides, CUtensorMapInterleave interleave, CUtensorMapSwizzle swizzle, CUtensorMapL2promotion l2Promotion, CUtensorMapFloatOOBfill oobFill) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuTensorMapEncodeIm2col
    cuPythonInit()
    if __cuTensorMapEncodeIm2col == NULL:
        with gil:
            raise RuntimeError('Function "cuTensorMapEncodeIm2col" not found')
    err = (<CUresult (*)(CUtensorMap*, CUtensorMapDataType, cuuint32_t, void*, const cuuint64_t*, const cuuint64_t*, const int*, const int*, cuuint32_t, cuuint32_t, const cuuint32_t*, CUtensorMapInterleave, CUtensorMapSwizzle, CUtensorMapL2promotion, CUtensorMapFloatOOBfill) except ?CUDA_ERROR_NOT_FOUND nogil> __cuTensorMapEncodeIm2col)(tensorMap, tensorDataType, tensorRank, globalAddress, globalDim, globalStrides, pixelBoxLowerCorner, pixelBoxUpperCorner, channelsPerPixel, pixelsPerColumn, elementStrides, interleave, swizzle, l2Promotion, oobFill)
    return err

cdef CUresult _cuTensorMapEncodeIm2colWide(CUtensorMap* tensorMap, CUtensorMapDataType tensorDataType, cuuint32_t tensorRank, void* globalAddress, const cuuint64_t* globalDim, const cuuint64_t* globalStrides, int pixelBoxLowerCornerWidth, int pixelBoxUpperCornerWidth, cuuint32_t channelsPerPixel, cuuint32_t pixelsPerColumn, const cuuint32_t* elementStrides, CUtensorMapInterleave interleave, CUtensorMapIm2ColWideMode mode, CUtensorMapSwizzle swizzle, CUtensorMapL2promotion l2Promotion, CUtensorMapFloatOOBfill oobFill) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuTensorMapEncodeIm2colWide
    cuPythonInit()
    if __cuTensorMapEncodeIm2colWide == NULL:
        with gil:
            raise RuntimeError('Function "cuTensorMapEncodeIm2colWide" not found')
    err = (<CUresult (*)(CUtensorMap*, CUtensorMapDataType, cuuint32_t, void*, const cuuint64_t*, const cuuint64_t*, int, int, cuuint32_t, cuuint32_t, const cuuint32_t*, CUtensorMapInterleave, CUtensorMapIm2ColWideMode, CUtensorMapSwizzle, CUtensorMapL2promotion, CUtensorMapFloatOOBfill) except ?CUDA_ERROR_NOT_FOUND nogil> __cuTensorMapEncodeIm2colWide)(tensorMap, tensorDataType, tensorRank, globalAddress, globalDim, globalStrides, pixelBoxLowerCornerWidth, pixelBoxUpperCornerWidth, channelsPerPixel, pixelsPerColumn, elementStrides, interleave, mode, swizzle, l2Promotion, oobFill)
    return err

cdef CUresult _cuTensorMapReplaceAddress(CUtensorMap* tensorMap, void* globalAddress) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuTensorMapReplaceAddress
    cuPythonInit()
    if __cuTensorMapReplaceAddress == NULL:
        with gil:
            raise RuntimeError('Function "cuTensorMapReplaceAddress" not found')
    err = (<CUresult (*)(CUtensorMap*, void*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuTensorMapReplaceAddress)(tensorMap, globalAddress)
    return err

cdef CUresult _cuDeviceCanAccessPeer(int* canAccessPeer, CUdevice dev, CUdevice peerDev) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuDeviceCanAccessPeer
    cuPythonInit()
    if __cuDeviceCanAccessPeer == NULL:
        with gil:
            raise RuntimeError('Function "cuDeviceCanAccessPeer" not found')
    err = (<CUresult (*)(int*, CUdevice, CUdevice) except ?CUDA_ERROR_NOT_FOUND nogil> __cuDeviceCanAccessPeer)(canAccessPeer, dev, peerDev)
    return err

cdef CUresult _cuCtxEnablePeerAccess(CUcontext peerContext, unsigned int Flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCtxEnablePeerAccess
    cuPythonInit()
    if __cuCtxEnablePeerAccess == NULL:
        with gil:
            raise RuntimeError('Function "cuCtxEnablePeerAccess" not found')
    err = (<CUresult (*)(CUcontext, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuCtxEnablePeerAccess)(peerContext, Flags)
    return err

cdef CUresult _cuCtxDisablePeerAccess(CUcontext peerContext) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCtxDisablePeerAccess
    cuPythonInit()
    if __cuCtxDisablePeerAccess == NULL:
        with gil:
            raise RuntimeError('Function "cuCtxDisablePeerAccess" not found')
    err = (<CUresult (*)(CUcontext) except ?CUDA_ERROR_NOT_FOUND nogil> __cuCtxDisablePeerAccess)(peerContext)
    return err

cdef CUresult _cuDeviceGetP2PAttribute(int* value, CUdevice_P2PAttribute attrib, CUdevice srcDevice, CUdevice dstDevice) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuDeviceGetP2PAttribute
    cuPythonInit()
    if __cuDeviceGetP2PAttribute == NULL:
        with gil:
            raise RuntimeError('Function "cuDeviceGetP2PAttribute" not found')
    err = (<CUresult (*)(int*, CUdevice_P2PAttribute, CUdevice, CUdevice) except ?CUDA_ERROR_NOT_FOUND nogil> __cuDeviceGetP2PAttribute)(value, attrib, srcDevice, dstDevice)
    return err

cdef CUresult _cuGraphicsUnregisterResource(CUgraphicsResource resource) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphicsUnregisterResource
    cuPythonInit()
    if __cuGraphicsUnregisterResource == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphicsUnregisterResource" not found')
    err = (<CUresult (*)(CUgraphicsResource) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphicsUnregisterResource)(resource)
    return err

cdef CUresult _cuGraphicsSubResourceGetMappedArray(CUarray* pArray, CUgraphicsResource resource, unsigned int arrayIndex, unsigned int mipLevel) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphicsSubResourceGetMappedArray
    cuPythonInit()
    if __cuGraphicsSubResourceGetMappedArray == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphicsSubResourceGetMappedArray" not found')
    err = (<CUresult (*)(CUarray*, CUgraphicsResource, unsigned int, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphicsSubResourceGetMappedArray)(pArray, resource, arrayIndex, mipLevel)
    return err

cdef CUresult _cuGraphicsResourceGetMappedMipmappedArray(CUmipmappedArray* pMipmappedArray, CUgraphicsResource resource) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphicsResourceGetMappedMipmappedArray
    cuPythonInit()
    if __cuGraphicsResourceGetMappedMipmappedArray == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphicsResourceGetMappedMipmappedArray" not found')
    err = (<CUresult (*)(CUmipmappedArray*, CUgraphicsResource) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphicsResourceGetMappedMipmappedArray)(pMipmappedArray, resource)
    return err

cdef CUresult _cuGraphicsResourceGetMappedPointer_v2(CUdeviceptr* pDevPtr, size_t* pSize, CUgraphicsResource resource) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphicsResourceGetMappedPointer_v2
    cuPythonInit()
    if __cuGraphicsResourceGetMappedPointer_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphicsResourceGetMappedPointer_v2" not found')
    err = (<CUresult (*)(CUdeviceptr*, size_t*, CUgraphicsResource) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphicsResourceGetMappedPointer_v2)(pDevPtr, pSize, resource)
    return err

cdef CUresult _cuGraphicsResourceSetMapFlags_v2(CUgraphicsResource resource, unsigned int flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphicsResourceSetMapFlags_v2
    cuPythonInit()
    if __cuGraphicsResourceSetMapFlags_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphicsResourceSetMapFlags_v2" not found')
    err = (<CUresult (*)(CUgraphicsResource, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphicsResourceSetMapFlags_v2)(resource, flags)
    return err

cdef CUresult _cuGraphicsMapResources(unsigned int count, CUgraphicsResource* resources, CUstream hStream) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphicsMapResources
    cuPythonInit()
    if __cuGraphicsMapResources == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphicsMapResources" not found')
    err = (<CUresult (*)(unsigned int, CUgraphicsResource*, CUstream) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphicsMapResources)(count, resources, hStream)
    return err

cdef CUresult _cuGraphicsUnmapResources(unsigned int count, CUgraphicsResource* resources, CUstream hStream) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphicsUnmapResources
    cuPythonInit()
    if __cuGraphicsUnmapResources == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphicsUnmapResources" not found')
    err = (<CUresult (*)(unsigned int, CUgraphicsResource*, CUstream) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphicsUnmapResources)(count, resources, hStream)
    return err

cdef CUresult _cuGetProcAddress_v2(const char* symbol, void** pfn, int cudaVersion, cuuint64_t flags, CUdriverProcAddressQueryResult* symbolStatus) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGetProcAddress_v2
    cuPythonInit()
    if __cuGetProcAddress_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuGetProcAddress_v2" not found')
    err = (<CUresult (*)(const char*, void**, int, cuuint64_t, CUdriverProcAddressQueryResult*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGetProcAddress_v2)(symbol, pfn, cudaVersion, flags, symbolStatus)
    return err

cdef CUresult _cuCoredumpGetAttribute(CUcoredumpSettings attrib, void* value, size_t* size) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCoredumpGetAttribute
    cuPythonInit()
    if __cuCoredumpGetAttribute == NULL:
        with gil:
            raise RuntimeError('Function "cuCoredumpGetAttribute" not found')
    err = (<CUresult (*)(CUcoredumpSettings, void*, size_t*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuCoredumpGetAttribute)(attrib, value, size)
    return err

cdef CUresult _cuCoredumpGetAttributeGlobal(CUcoredumpSettings attrib, void* value, size_t* size) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCoredumpGetAttributeGlobal
    cuPythonInit()
    if __cuCoredumpGetAttributeGlobal == NULL:
        with gil:
            raise RuntimeError('Function "cuCoredumpGetAttributeGlobal" not found')
    err = (<CUresult (*)(CUcoredumpSettings, void*, size_t*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuCoredumpGetAttributeGlobal)(attrib, value, size)
    return err

cdef CUresult _cuCoredumpSetAttribute(CUcoredumpSettings attrib, void* value, size_t* size) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCoredumpSetAttribute
    cuPythonInit()
    if __cuCoredumpSetAttribute == NULL:
        with gil:
            raise RuntimeError('Function "cuCoredumpSetAttribute" not found')
    err = (<CUresult (*)(CUcoredumpSettings, void*, size_t*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuCoredumpSetAttribute)(attrib, value, size)
    return err

cdef CUresult _cuCoredumpSetAttributeGlobal(CUcoredumpSettings attrib, void* value, size_t* size) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCoredumpSetAttributeGlobal
    cuPythonInit()
    if __cuCoredumpSetAttributeGlobal == NULL:
        with gil:
            raise RuntimeError('Function "cuCoredumpSetAttributeGlobal" not found')
    err = (<CUresult (*)(CUcoredumpSettings, void*, size_t*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuCoredumpSetAttributeGlobal)(attrib, value, size)
    return err

cdef CUresult _cuGetExportTable(const void** ppExportTable, const CUuuid* pExportTableId) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGetExportTable
    cuPythonInit()
    if __cuGetExportTable == NULL:
        with gil:
            raise RuntimeError('Function "cuGetExportTable" not found')
    err = (<CUresult (*)(const void**, const CUuuid*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGetExportTable)(ppExportTable, pExportTableId)
    return err

cdef CUresult _cuGreenCtxCreate(CUgreenCtx* phCtx, CUdevResourceDesc desc, CUdevice dev, unsigned int flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGreenCtxCreate
    cuPythonInit()
    if __cuGreenCtxCreate == NULL:
        with gil:
            raise RuntimeError('Function "cuGreenCtxCreate" not found')
    err = (<CUresult (*)(CUgreenCtx*, CUdevResourceDesc, CUdevice, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGreenCtxCreate)(phCtx, desc, dev, flags)
    return err

cdef CUresult _cuGreenCtxDestroy(CUgreenCtx hCtx) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGreenCtxDestroy
    cuPythonInit()
    if __cuGreenCtxDestroy == NULL:
        with gil:
            raise RuntimeError('Function "cuGreenCtxDestroy" not found')
    err = (<CUresult (*)(CUgreenCtx) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGreenCtxDestroy)(hCtx)
    return err

cdef CUresult _cuCtxFromGreenCtx(CUcontext* pContext, CUgreenCtx hCtx) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCtxFromGreenCtx
    cuPythonInit()
    if __cuCtxFromGreenCtx == NULL:
        with gil:
            raise RuntimeError('Function "cuCtxFromGreenCtx" not found')
    err = (<CUresult (*)(CUcontext*, CUgreenCtx) except ?CUDA_ERROR_NOT_FOUND nogil> __cuCtxFromGreenCtx)(pContext, hCtx)
    return err

cdef CUresult _cuDeviceGetDevResource(CUdevice device, CUdevResource* resource, CUdevResourceType typename) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuDeviceGetDevResource
    cuPythonInit()
    if __cuDeviceGetDevResource == NULL:
        with gil:
            raise RuntimeError('Function "cuDeviceGetDevResource" not found')
    err = (<CUresult (*)(CUdevice, CUdevResource*, CUdevResourceType) except ?CUDA_ERROR_NOT_FOUND nogil> __cuDeviceGetDevResource)(device, resource, typename)
    return err

cdef CUresult _cuCtxGetDevResource(CUcontext hCtx, CUdevResource* resource, CUdevResourceType typename) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCtxGetDevResource
    cuPythonInit()
    if __cuCtxGetDevResource == NULL:
        with gil:
            raise RuntimeError('Function "cuCtxGetDevResource" not found')
    err = (<CUresult (*)(CUcontext, CUdevResource*, CUdevResourceType) except ?CUDA_ERROR_NOT_FOUND nogil> __cuCtxGetDevResource)(hCtx, resource, typename)
    return err

cdef CUresult _cuGreenCtxGetDevResource(CUgreenCtx hCtx, CUdevResource* resource, CUdevResourceType typename) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGreenCtxGetDevResource
    cuPythonInit()
    if __cuGreenCtxGetDevResource == NULL:
        with gil:
            raise RuntimeError('Function "cuGreenCtxGetDevResource" not found')
    err = (<CUresult (*)(CUgreenCtx, CUdevResource*, CUdevResourceType) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGreenCtxGetDevResource)(hCtx, resource, typename)
    return err

cdef CUresult _cuDevSmResourceSplitByCount(CUdevResource* result, unsigned int* nbGroups, const CUdevResource* input, CUdevResource* remaining, unsigned int useFlags, unsigned int minCount) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuDevSmResourceSplitByCount
    cuPythonInit()
    if __cuDevSmResourceSplitByCount == NULL:
        with gil:
            raise RuntimeError('Function "cuDevSmResourceSplitByCount" not found')
    err = (<CUresult (*)(CUdevResource*, unsigned int*, const CUdevResource*, CUdevResource*, unsigned int, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuDevSmResourceSplitByCount)(result, nbGroups, input, remaining, useFlags, minCount)
    return err

cdef CUresult _cuDevResourceGenerateDesc(CUdevResourceDesc* phDesc, CUdevResource* resources, unsigned int nbResources) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuDevResourceGenerateDesc
    cuPythonInit()
    if __cuDevResourceGenerateDesc == NULL:
        with gil:
            raise RuntimeError('Function "cuDevResourceGenerateDesc" not found')
    err = (<CUresult (*)(CUdevResourceDesc*, CUdevResource*, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuDevResourceGenerateDesc)(phDesc, resources, nbResources)
    return err

cdef CUresult _cuGreenCtxRecordEvent(CUgreenCtx hCtx, CUevent hEvent) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGreenCtxRecordEvent
    cuPythonInit()
    if __cuGreenCtxRecordEvent == NULL:
        with gil:
            raise RuntimeError('Function "cuGreenCtxRecordEvent" not found')
    err = (<CUresult (*)(CUgreenCtx, CUevent) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGreenCtxRecordEvent)(hCtx, hEvent)
    return err

cdef CUresult _cuGreenCtxWaitEvent(CUgreenCtx hCtx, CUevent hEvent) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGreenCtxWaitEvent
    cuPythonInit()
    if __cuGreenCtxWaitEvent == NULL:
        with gil:
            raise RuntimeError('Function "cuGreenCtxWaitEvent" not found')
    err = (<CUresult (*)(CUgreenCtx, CUevent) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGreenCtxWaitEvent)(hCtx, hEvent)
    return err

cdef CUresult _cuStreamGetGreenCtx(CUstream hStream, CUgreenCtx* phCtx) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuStreamGetGreenCtx
    cuPythonInit()
    if __cuStreamGetGreenCtx == NULL:
        with gil:
            raise RuntimeError('Function "cuStreamGetGreenCtx" not found')
    err = (<CUresult (*)(CUstream, CUgreenCtx*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuStreamGetGreenCtx)(hStream, phCtx)
    return err

cdef CUresult _cuGreenCtxStreamCreate(CUstream* phStream, CUgreenCtx greenCtx, unsigned int flags, int priority) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGreenCtxStreamCreate
    cuPythonInit()
    if __cuGreenCtxStreamCreate == NULL:
        with gil:
            raise RuntimeError('Function "cuGreenCtxStreamCreate" not found')
    err = (<CUresult (*)(CUstream*, CUgreenCtx, unsigned int, int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGreenCtxStreamCreate)(phStream, greenCtx, flags, priority)
    return err

cdef CUresult _cuLogsRegisterCallback(CUlogsCallback callbackFunc, void* userData, CUlogsCallbackHandle* callback_out) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuLogsRegisterCallback
    cuPythonInit()
    if __cuLogsRegisterCallback == NULL:
        with gil:
            raise RuntimeError('Function "cuLogsRegisterCallback" not found')
    err = (<CUresult (*)(CUlogsCallback, void*, CUlogsCallbackHandle*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuLogsRegisterCallback)(callbackFunc, userData, callback_out)
    return err

cdef CUresult _cuLogsUnregisterCallback(CUlogsCallbackHandle callback) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuLogsUnregisterCallback
    cuPythonInit()
    if __cuLogsUnregisterCallback == NULL:
        with gil:
            raise RuntimeError('Function "cuLogsUnregisterCallback" not found')
    err = (<CUresult (*)(CUlogsCallbackHandle) except ?CUDA_ERROR_NOT_FOUND nogil> __cuLogsUnregisterCallback)(callback)
    return err

cdef CUresult _cuLogsCurrent(CUlogIterator* iterator_out, unsigned int flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuLogsCurrent
    cuPythonInit()
    if __cuLogsCurrent == NULL:
        with gil:
            raise RuntimeError('Function "cuLogsCurrent" not found')
    err = (<CUresult (*)(CUlogIterator*, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuLogsCurrent)(iterator_out, flags)
    return err

cdef CUresult _cuLogsDumpToFile(CUlogIterator* iterator, const char* pathToFile, unsigned int flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuLogsDumpToFile
    cuPythonInit()
    if __cuLogsDumpToFile == NULL:
        with gil:
            raise RuntimeError('Function "cuLogsDumpToFile" not found')
    err = (<CUresult (*)(CUlogIterator*, const char*, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuLogsDumpToFile)(iterator, pathToFile, flags)
    return err

cdef CUresult _cuLogsDumpToMemory(CUlogIterator* iterator, char* buffer, size_t* size, unsigned int flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuLogsDumpToMemory
    cuPythonInit()
    if __cuLogsDumpToMemory == NULL:
        with gil:
            raise RuntimeError('Function "cuLogsDumpToMemory" not found')
    err = (<CUresult (*)(CUlogIterator*, char*, size_t*, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuLogsDumpToMemory)(iterator, buffer, size, flags)
    return err

cdef CUresult _cuCheckpointProcessGetRestoreThreadId(int pid, int* tid) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCheckpointProcessGetRestoreThreadId
    cuPythonInit()
    if __cuCheckpointProcessGetRestoreThreadId == NULL:
        with gil:
            raise RuntimeError('Function "cuCheckpointProcessGetRestoreThreadId" not found')
    err = (<CUresult (*)(int, int*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuCheckpointProcessGetRestoreThreadId)(pid, tid)
    return err

cdef CUresult _cuCheckpointProcessGetState(int pid, CUprocessState* state) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCheckpointProcessGetState
    cuPythonInit()
    if __cuCheckpointProcessGetState == NULL:
        with gil:
            raise RuntimeError('Function "cuCheckpointProcessGetState" not found')
    err = (<CUresult (*)(int, CUprocessState*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuCheckpointProcessGetState)(pid, state)
    return err

cdef CUresult _cuCheckpointProcessLock(int pid, CUcheckpointLockArgs* args) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCheckpointProcessLock
    cuPythonInit()
    if __cuCheckpointProcessLock == NULL:
        with gil:
            raise RuntimeError('Function "cuCheckpointProcessLock" not found')
    err = (<CUresult (*)(int, CUcheckpointLockArgs*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuCheckpointProcessLock)(pid, args)
    return err

cdef CUresult _cuCheckpointProcessCheckpoint(int pid, CUcheckpointCheckpointArgs* args) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCheckpointProcessCheckpoint
    cuPythonInit()
    if __cuCheckpointProcessCheckpoint == NULL:
        with gil:
            raise RuntimeError('Function "cuCheckpointProcessCheckpoint" not found')
    err = (<CUresult (*)(int, CUcheckpointCheckpointArgs*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuCheckpointProcessCheckpoint)(pid, args)
    return err

cdef CUresult _cuCheckpointProcessRestore(int pid, CUcheckpointRestoreArgs* args) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCheckpointProcessRestore
    cuPythonInit()
    if __cuCheckpointProcessRestore == NULL:
        with gil:
            raise RuntimeError('Function "cuCheckpointProcessRestore" not found')
    err = (<CUresult (*)(int, CUcheckpointRestoreArgs*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuCheckpointProcessRestore)(pid, args)
    return err

cdef CUresult _cuCheckpointProcessUnlock(int pid, CUcheckpointUnlockArgs* args) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuCheckpointProcessUnlock
    cuPythonInit()
    if __cuCheckpointProcessUnlock == NULL:
        with gil:
            raise RuntimeError('Function "cuCheckpointProcessUnlock" not found')
    err = (<CUresult (*)(int, CUcheckpointUnlockArgs*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuCheckpointProcessUnlock)(pid, args)
    return err

cdef CUresult _cuProfilerStart() except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuProfilerStart
    cuPythonInit()
    if __cuProfilerStart == NULL:
        with gil:
            raise RuntimeError('Function "cuProfilerStart" not found')
    err = (<CUresult (*)() except ?CUDA_ERROR_NOT_FOUND nogil> __cuProfilerStart)()
    return err

cdef CUresult _cuProfilerStop() except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuProfilerStop
    cuPythonInit()
    if __cuProfilerStop == NULL:
        with gil:
            raise RuntimeError('Function "cuProfilerStop" not found')
    err = (<CUresult (*)() except ?CUDA_ERROR_NOT_FOUND nogil> __cuProfilerStop)()
    return err

cdef CUresult _cuGraphicsEGLRegisterImage(CUgraphicsResource* pCudaResource, EGLImageKHR image, unsigned int flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphicsEGLRegisterImage
    cuPythonInit()
    if __cuGraphicsEGLRegisterImage == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphicsEGLRegisterImage" not found')
    err = (<CUresult (*)(CUgraphicsResource*, EGLImageKHR, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphicsEGLRegisterImage)(pCudaResource, image, flags)
    return err

cdef CUresult _cuEGLStreamConsumerConnect(CUeglStreamConnection* conn, EGLStreamKHR stream) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuEGLStreamConsumerConnect
    cuPythonInit()
    if __cuEGLStreamConsumerConnect == NULL:
        with gil:
            raise RuntimeError('Function "cuEGLStreamConsumerConnect" not found')
    err = (<CUresult (*)(CUeglStreamConnection*, EGLStreamKHR) except ?CUDA_ERROR_NOT_FOUND nogil> __cuEGLStreamConsumerConnect)(conn, stream)
    return err

cdef CUresult _cuEGLStreamConsumerConnectWithFlags(CUeglStreamConnection* conn, EGLStreamKHR stream, unsigned int flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuEGLStreamConsumerConnectWithFlags
    cuPythonInit()
    if __cuEGLStreamConsumerConnectWithFlags == NULL:
        with gil:
            raise RuntimeError('Function "cuEGLStreamConsumerConnectWithFlags" not found')
    err = (<CUresult (*)(CUeglStreamConnection*, EGLStreamKHR, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuEGLStreamConsumerConnectWithFlags)(conn, stream, flags)
    return err

cdef CUresult _cuEGLStreamConsumerDisconnect(CUeglStreamConnection* conn) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuEGLStreamConsumerDisconnect
    cuPythonInit()
    if __cuEGLStreamConsumerDisconnect == NULL:
        with gil:
            raise RuntimeError('Function "cuEGLStreamConsumerDisconnect" not found')
    err = (<CUresult (*)(CUeglStreamConnection*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuEGLStreamConsumerDisconnect)(conn)
    return err

cdef CUresult _cuEGLStreamConsumerAcquireFrame(CUeglStreamConnection* conn, CUgraphicsResource* pCudaResource, CUstream* pStream, unsigned int timeout) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuEGLStreamConsumerAcquireFrame
    cuPythonInit()
    if __cuEGLStreamConsumerAcquireFrame == NULL:
        with gil:
            raise RuntimeError('Function "cuEGLStreamConsumerAcquireFrame" not found')
    err = (<CUresult (*)(CUeglStreamConnection*, CUgraphicsResource*, CUstream*, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuEGLStreamConsumerAcquireFrame)(conn, pCudaResource, pStream, timeout)
    return err

cdef CUresult _cuEGLStreamConsumerReleaseFrame(CUeglStreamConnection* conn, CUgraphicsResource pCudaResource, CUstream* pStream) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuEGLStreamConsumerReleaseFrame
    cuPythonInit()
    if __cuEGLStreamConsumerReleaseFrame == NULL:
        with gil:
            raise RuntimeError('Function "cuEGLStreamConsumerReleaseFrame" not found')
    err = (<CUresult (*)(CUeglStreamConnection*, CUgraphicsResource, CUstream*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuEGLStreamConsumerReleaseFrame)(conn, pCudaResource, pStream)
    return err

cdef CUresult _cuEGLStreamProducerConnect(CUeglStreamConnection* conn, EGLStreamKHR stream, EGLint width, EGLint height) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuEGLStreamProducerConnect
    cuPythonInit()
    if __cuEGLStreamProducerConnect == NULL:
        with gil:
            raise RuntimeError('Function "cuEGLStreamProducerConnect" not found')
    err = (<CUresult (*)(CUeglStreamConnection*, EGLStreamKHR, EGLint, EGLint) except ?CUDA_ERROR_NOT_FOUND nogil> __cuEGLStreamProducerConnect)(conn, stream, width, height)
    return err

cdef CUresult _cuEGLStreamProducerDisconnect(CUeglStreamConnection* conn) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuEGLStreamProducerDisconnect
    cuPythonInit()
    if __cuEGLStreamProducerDisconnect == NULL:
        with gil:
            raise RuntimeError('Function "cuEGLStreamProducerDisconnect" not found')
    err = (<CUresult (*)(CUeglStreamConnection*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuEGLStreamProducerDisconnect)(conn)
    return err

cdef CUresult _cuEGLStreamProducerPresentFrame(CUeglStreamConnection* conn, CUeglFrame eglframe, CUstream* pStream) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuEGLStreamProducerPresentFrame
    cuPythonInit()
    if __cuEGLStreamProducerPresentFrame == NULL:
        with gil:
            raise RuntimeError('Function "cuEGLStreamProducerPresentFrame" not found')
    err = (<CUresult (*)(CUeglStreamConnection*, CUeglFrame, CUstream*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuEGLStreamProducerPresentFrame)(conn, eglframe, pStream)
    return err

cdef CUresult _cuEGLStreamProducerReturnFrame(CUeglStreamConnection* conn, CUeglFrame* eglframe, CUstream* pStream) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuEGLStreamProducerReturnFrame
    cuPythonInit()
    if __cuEGLStreamProducerReturnFrame == NULL:
        with gil:
            raise RuntimeError('Function "cuEGLStreamProducerReturnFrame" not found')
    err = (<CUresult (*)(CUeglStreamConnection*, CUeglFrame*, CUstream*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuEGLStreamProducerReturnFrame)(conn, eglframe, pStream)
    return err

cdef CUresult _cuGraphicsResourceGetMappedEglFrame(CUeglFrame* eglFrame, CUgraphicsResource resource, unsigned int index, unsigned int mipLevel) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphicsResourceGetMappedEglFrame
    cuPythonInit()
    if __cuGraphicsResourceGetMappedEglFrame == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphicsResourceGetMappedEglFrame" not found')
    err = (<CUresult (*)(CUeglFrame*, CUgraphicsResource, unsigned int, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphicsResourceGetMappedEglFrame)(eglFrame, resource, index, mipLevel)
    return err

cdef CUresult _cuEventCreateFromEGLSync(CUevent* phEvent, EGLSyncKHR eglSync, unsigned int flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuEventCreateFromEGLSync
    cuPythonInit()
    if __cuEventCreateFromEGLSync == NULL:
        with gil:
            raise RuntimeError('Function "cuEventCreateFromEGLSync" not found')
    err = (<CUresult (*)(CUevent*, EGLSyncKHR, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuEventCreateFromEGLSync)(phEvent, eglSync, flags)
    return err

cdef CUresult _cuGraphicsGLRegisterBuffer(CUgraphicsResource* pCudaResource, GLuint buffer, unsigned int Flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphicsGLRegisterBuffer
    cuPythonInit()
    if __cuGraphicsGLRegisterBuffer == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphicsGLRegisterBuffer" not found')
    err = (<CUresult (*)(CUgraphicsResource*, GLuint, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphicsGLRegisterBuffer)(pCudaResource, buffer, Flags)
    return err

cdef CUresult _cuGraphicsGLRegisterImage(CUgraphicsResource* pCudaResource, GLuint image, GLenum target, unsigned int Flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphicsGLRegisterImage
    cuPythonInit()
    if __cuGraphicsGLRegisterImage == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphicsGLRegisterImage" not found')
    err = (<CUresult (*)(CUgraphicsResource*, GLuint, GLenum, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphicsGLRegisterImage)(pCudaResource, image, target, Flags)
    return err

cdef CUresult _cuGLGetDevices_v2(unsigned int* pCudaDeviceCount, CUdevice* pCudaDevices, unsigned int cudaDeviceCount, CUGLDeviceList deviceList) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGLGetDevices_v2
    cuPythonInit()
    if __cuGLGetDevices_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuGLGetDevices_v2" not found')
    err = (<CUresult (*)(unsigned int*, CUdevice*, unsigned int, CUGLDeviceList) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGLGetDevices_v2)(pCudaDeviceCount, pCudaDevices, cudaDeviceCount, deviceList)
    return err

cdef CUresult _cuVDPAUGetDevice(CUdevice* pDevice, VdpDevice vdpDevice, VdpGetProcAddress* vdpGetProcAddress) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuVDPAUGetDevice
    cuPythonInit()
    if __cuVDPAUGetDevice == NULL:
        with gil:
            raise RuntimeError('Function "cuVDPAUGetDevice" not found')
    err = (<CUresult (*)(CUdevice*, VdpDevice, VdpGetProcAddress*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuVDPAUGetDevice)(pDevice, vdpDevice, vdpGetProcAddress)
    return err

cdef CUresult _cuVDPAUCtxCreate_v2(CUcontext* pCtx, unsigned int flags, CUdevice device, VdpDevice vdpDevice, VdpGetProcAddress* vdpGetProcAddress) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuVDPAUCtxCreate_v2
    cuPythonInit()
    if __cuVDPAUCtxCreate_v2 == NULL:
        with gil:
            raise RuntimeError('Function "cuVDPAUCtxCreate_v2" not found')
    err = (<CUresult (*)(CUcontext*, unsigned int, CUdevice, VdpDevice, VdpGetProcAddress*) except ?CUDA_ERROR_NOT_FOUND nogil> __cuVDPAUCtxCreate_v2)(pCtx, flags, device, vdpDevice, vdpGetProcAddress)
    return err

cdef CUresult _cuGraphicsVDPAURegisterVideoSurface(CUgraphicsResource* pCudaResource, VdpVideoSurface vdpSurface, unsigned int flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphicsVDPAURegisterVideoSurface
    cuPythonInit()
    if __cuGraphicsVDPAURegisterVideoSurface == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphicsVDPAURegisterVideoSurface" not found')
    err = (<CUresult (*)(CUgraphicsResource*, VdpVideoSurface, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphicsVDPAURegisterVideoSurface)(pCudaResource, vdpSurface, flags)
    return err

cdef CUresult _cuGraphicsVDPAURegisterOutputSurface(CUgraphicsResource* pCudaResource, VdpOutputSurface vdpSurface, unsigned int flags) except ?CUDA_ERROR_NOT_FOUND nogil:
    global __cuGraphicsVDPAURegisterOutputSurface
    cuPythonInit()
    if __cuGraphicsVDPAURegisterOutputSurface == NULL:
        with gil:
            raise RuntimeError('Function "cuGraphicsVDPAURegisterOutputSurface" not found')
    err = (<CUresult (*)(CUgraphicsResource*, VdpOutputSurface, unsigned int) except ?CUDA_ERROR_NOT_FOUND nogil> __cuGraphicsVDPAURegisterOutputSurface)(pCudaResource, vdpSurface, flags)
    return err

cdef dict func_ptrs = None

cpdef dict _inspect_function_pointers():
    global func_ptrs
    if func_ptrs is not None:
        return func_ptrs

    cuPythonInit()
    cdef dict data = {}

    global __cuGetErrorString
    data["__cuGetErrorString"] = <intptr_t>__cuGetErrorString
    global __cuGetErrorName
    data["__cuGetErrorName"] = <intptr_t>__cuGetErrorName
    global __cuInit
    data["__cuInit"] = <intptr_t>__cuInit
    global __cuDriverGetVersion
    data["__cuDriverGetVersion"] = <intptr_t>__cuDriverGetVersion
    global __cuDeviceGet
    data["__cuDeviceGet"] = <intptr_t>__cuDeviceGet
    global __cuDeviceGetCount
    data["__cuDeviceGetCount"] = <intptr_t>__cuDeviceGetCount
    global __cuDeviceGetName
    data["__cuDeviceGetName"] = <intptr_t>__cuDeviceGetName
    global __cuDeviceGetUuid
    data["__cuDeviceGetUuid"] = <intptr_t>__cuDeviceGetUuid
    global __cuDeviceGetUuid_v2
    data["__cuDeviceGetUuid_v2"] = <intptr_t>__cuDeviceGetUuid_v2
    global __cuDeviceGetLuid
    data["__cuDeviceGetLuid"] = <intptr_t>__cuDeviceGetLuid
    global __cuDeviceTotalMem_v2
    data["__cuDeviceTotalMem_v2"] = <intptr_t>__cuDeviceTotalMem_v2
    global __cuDeviceGetTexture1DLinearMaxWidth
    data["__cuDeviceGetTexture1DLinearMaxWidth"] = <intptr_t>__cuDeviceGetTexture1DLinearMaxWidth
    global __cuDeviceGetAttribute
    data["__cuDeviceGetAttribute"] = <intptr_t>__cuDeviceGetAttribute
    global __cuDeviceGetNvSciSyncAttributes
    data["__cuDeviceGetNvSciSyncAttributes"] = <intptr_t>__cuDeviceGetNvSciSyncAttributes
    global __cuDeviceSetMemPool
    data["__cuDeviceSetMemPool"] = <intptr_t>__cuDeviceSetMemPool
    global __cuDeviceGetMemPool
    data["__cuDeviceGetMemPool"] = <intptr_t>__cuDeviceGetMemPool
    global __cuDeviceGetDefaultMemPool
    data["__cuDeviceGetDefaultMemPool"] = <intptr_t>__cuDeviceGetDefaultMemPool
    global __cuDeviceGetExecAffinitySupport
    data["__cuDeviceGetExecAffinitySupport"] = <intptr_t>__cuDeviceGetExecAffinitySupport
    global __cuFlushGPUDirectRDMAWrites
    data["__cuFlushGPUDirectRDMAWrites"] = <intptr_t>__cuFlushGPUDirectRDMAWrites
    global __cuDeviceGetProperties
    data["__cuDeviceGetProperties"] = <intptr_t>__cuDeviceGetProperties
    global __cuDeviceComputeCapability
    data["__cuDeviceComputeCapability"] = <intptr_t>__cuDeviceComputeCapability
    global __cuDevicePrimaryCtxRetain
    data["__cuDevicePrimaryCtxRetain"] = <intptr_t>__cuDevicePrimaryCtxRetain
    global __cuDevicePrimaryCtxRelease_v2
    data["__cuDevicePrimaryCtxRelease_v2"] = <intptr_t>__cuDevicePrimaryCtxRelease_v2
    global __cuDevicePrimaryCtxSetFlags_v2
    data["__cuDevicePrimaryCtxSetFlags_v2"] = <intptr_t>__cuDevicePrimaryCtxSetFlags_v2
    global __cuDevicePrimaryCtxGetState
    data["__cuDevicePrimaryCtxGetState"] = <intptr_t>__cuDevicePrimaryCtxGetState
    global __cuDevicePrimaryCtxReset_v2
    data["__cuDevicePrimaryCtxReset_v2"] = <intptr_t>__cuDevicePrimaryCtxReset_v2
    global __cuCtxCreate_v2
    data["__cuCtxCreate_v2"] = <intptr_t>__cuCtxCreate_v2
    global __cuCtxCreate_v3
    data["__cuCtxCreate_v3"] = <intptr_t>__cuCtxCreate_v3
    global __cuCtxCreate_v4
    data["__cuCtxCreate_v4"] = <intptr_t>__cuCtxCreate_v4
    global __cuCtxDestroy_v2
    data["__cuCtxDestroy_v2"] = <intptr_t>__cuCtxDestroy_v2
    global __cuCtxPushCurrent_v2
    data["__cuCtxPushCurrent_v2"] = <intptr_t>__cuCtxPushCurrent_v2
    global __cuCtxPopCurrent_v2
    data["__cuCtxPopCurrent_v2"] = <intptr_t>__cuCtxPopCurrent_v2
    global __cuCtxSetCurrent
    data["__cuCtxSetCurrent"] = <intptr_t>__cuCtxSetCurrent
    global __cuCtxGetCurrent
    data["__cuCtxGetCurrent"] = <intptr_t>__cuCtxGetCurrent
    global __cuCtxGetDevice
    data["__cuCtxGetDevice"] = <intptr_t>__cuCtxGetDevice
    global __cuCtxGetFlags
    data["__cuCtxGetFlags"] = <intptr_t>__cuCtxGetFlags
    global __cuCtxSetFlags
    data["__cuCtxSetFlags"] = <intptr_t>__cuCtxSetFlags
    global __cuCtxGetId
    data["__cuCtxGetId"] = <intptr_t>__cuCtxGetId
    global __cuCtxSynchronize
    data["__cuCtxSynchronize"] = <intptr_t>__cuCtxSynchronize
    global __cuCtxSetLimit
    data["__cuCtxSetLimit"] = <intptr_t>__cuCtxSetLimit
    global __cuCtxGetLimit
    data["__cuCtxGetLimit"] = <intptr_t>__cuCtxGetLimit
    global __cuCtxGetCacheConfig
    data["__cuCtxGetCacheConfig"] = <intptr_t>__cuCtxGetCacheConfig
    global __cuCtxSetCacheConfig
    data["__cuCtxSetCacheConfig"] = <intptr_t>__cuCtxSetCacheConfig
    global __cuCtxGetApiVersion
    data["__cuCtxGetApiVersion"] = <intptr_t>__cuCtxGetApiVersion
    global __cuCtxGetStreamPriorityRange
    data["__cuCtxGetStreamPriorityRange"] = <intptr_t>__cuCtxGetStreamPriorityRange
    global __cuCtxResetPersistingL2Cache
    data["__cuCtxResetPersistingL2Cache"] = <intptr_t>__cuCtxResetPersistingL2Cache
    global __cuCtxGetExecAffinity
    data["__cuCtxGetExecAffinity"] = <intptr_t>__cuCtxGetExecAffinity
    global __cuCtxRecordEvent
    data["__cuCtxRecordEvent"] = <intptr_t>__cuCtxRecordEvent
    global __cuCtxWaitEvent
    data["__cuCtxWaitEvent"] = <intptr_t>__cuCtxWaitEvent
    global __cuCtxAttach
    data["__cuCtxAttach"] = <intptr_t>__cuCtxAttach
    global __cuCtxDetach
    data["__cuCtxDetach"] = <intptr_t>__cuCtxDetach
    global __cuCtxGetSharedMemConfig
    data["__cuCtxGetSharedMemConfig"] = <intptr_t>__cuCtxGetSharedMemConfig
    global __cuCtxSetSharedMemConfig
    data["__cuCtxSetSharedMemConfig"] = <intptr_t>__cuCtxSetSharedMemConfig
    global __cuModuleLoad
    data["__cuModuleLoad"] = <intptr_t>__cuModuleLoad
    global __cuModuleLoadData
    data["__cuModuleLoadData"] = <intptr_t>__cuModuleLoadData
    global __cuModuleLoadDataEx
    data["__cuModuleLoadDataEx"] = <intptr_t>__cuModuleLoadDataEx
    global __cuModuleLoadFatBinary
    data["__cuModuleLoadFatBinary"] = <intptr_t>__cuModuleLoadFatBinary
    global __cuModuleUnload
    data["__cuModuleUnload"] = <intptr_t>__cuModuleUnload
    global __cuModuleGetLoadingMode
    data["__cuModuleGetLoadingMode"] = <intptr_t>__cuModuleGetLoadingMode
    global __cuModuleGetFunction
    data["__cuModuleGetFunction"] = <intptr_t>__cuModuleGetFunction
    global __cuModuleGetFunctionCount
    data["__cuModuleGetFunctionCount"] = <intptr_t>__cuModuleGetFunctionCount
    global __cuModuleEnumerateFunctions
    data["__cuModuleEnumerateFunctions"] = <intptr_t>__cuModuleEnumerateFunctions
    global __cuModuleGetGlobal_v2
    data["__cuModuleGetGlobal_v2"] = <intptr_t>__cuModuleGetGlobal_v2
    global __cuLinkCreate_v2
    data["__cuLinkCreate_v2"] = <intptr_t>__cuLinkCreate_v2
    global __cuLinkAddData_v2
    data["__cuLinkAddData_v2"] = <intptr_t>__cuLinkAddData_v2
    global __cuLinkAddFile_v2
    data["__cuLinkAddFile_v2"] = <intptr_t>__cuLinkAddFile_v2
    global __cuLinkComplete
    data["__cuLinkComplete"] = <intptr_t>__cuLinkComplete
    global __cuLinkDestroy
    data["__cuLinkDestroy"] = <intptr_t>__cuLinkDestroy
    global __cuModuleGetTexRef
    data["__cuModuleGetTexRef"] = <intptr_t>__cuModuleGetTexRef
    global __cuModuleGetSurfRef
    data["__cuModuleGetSurfRef"] = <intptr_t>__cuModuleGetSurfRef
    global __cuLibraryLoadData
    data["__cuLibraryLoadData"] = <intptr_t>__cuLibraryLoadData
    global __cuLibraryLoadFromFile
    data["__cuLibraryLoadFromFile"] = <intptr_t>__cuLibraryLoadFromFile
    global __cuLibraryUnload
    data["__cuLibraryUnload"] = <intptr_t>__cuLibraryUnload
    global __cuLibraryGetKernel
    data["__cuLibraryGetKernel"] = <intptr_t>__cuLibraryGetKernel
    global __cuLibraryGetKernelCount
    data["__cuLibraryGetKernelCount"] = <intptr_t>__cuLibraryGetKernelCount
    global __cuLibraryEnumerateKernels
    data["__cuLibraryEnumerateKernels"] = <intptr_t>__cuLibraryEnumerateKernels
    global __cuLibraryGetModule
    data["__cuLibraryGetModule"] = <intptr_t>__cuLibraryGetModule
    global __cuKernelGetFunction
    data["__cuKernelGetFunction"] = <intptr_t>__cuKernelGetFunction
    global __cuKernelGetLibrary
    data["__cuKernelGetLibrary"] = <intptr_t>__cuKernelGetLibrary
    global __cuLibraryGetGlobal
    data["__cuLibraryGetGlobal"] = <intptr_t>__cuLibraryGetGlobal
    global __cuLibraryGetManaged
    data["__cuLibraryGetManaged"] = <intptr_t>__cuLibraryGetManaged
    global __cuLibraryGetUnifiedFunction
    data["__cuLibraryGetUnifiedFunction"] = <intptr_t>__cuLibraryGetUnifiedFunction
    global __cuKernelGetAttribute
    data["__cuKernelGetAttribute"] = <intptr_t>__cuKernelGetAttribute
    global __cuKernelSetAttribute
    data["__cuKernelSetAttribute"] = <intptr_t>__cuKernelSetAttribute
    global __cuKernelSetCacheConfig
    data["__cuKernelSetCacheConfig"] = <intptr_t>__cuKernelSetCacheConfig
    global __cuKernelGetName
    data["__cuKernelGetName"] = <intptr_t>__cuKernelGetName
    global __cuKernelGetParamInfo
    data["__cuKernelGetParamInfo"] = <intptr_t>__cuKernelGetParamInfo
    global __cuMemGetInfo_v2
    data["__cuMemGetInfo_v2"] = <intptr_t>__cuMemGetInfo_v2
    global __cuMemAlloc_v2
    data["__cuMemAlloc_v2"] = <intptr_t>__cuMemAlloc_v2
    global __cuMemAllocPitch_v2
    data["__cuMemAllocPitch_v2"] = <intptr_t>__cuMemAllocPitch_v2
    global __cuMemFree_v2
    data["__cuMemFree_v2"] = <intptr_t>__cuMemFree_v2
    global __cuMemGetAddressRange_v2
    data["__cuMemGetAddressRange_v2"] = <intptr_t>__cuMemGetAddressRange_v2
    global __cuMemAllocHost_v2
    data["__cuMemAllocHost_v2"] = <intptr_t>__cuMemAllocHost_v2
    global __cuMemFreeHost
    data["__cuMemFreeHost"] = <intptr_t>__cuMemFreeHost
    global __cuMemHostAlloc
    data["__cuMemHostAlloc"] = <intptr_t>__cuMemHostAlloc
    global __cuMemHostGetDevicePointer_v2
    data["__cuMemHostGetDevicePointer_v2"] = <intptr_t>__cuMemHostGetDevicePointer_v2
    global __cuMemHostGetFlags
    data["__cuMemHostGetFlags"] = <intptr_t>__cuMemHostGetFlags
    global __cuMemAllocManaged
    data["__cuMemAllocManaged"] = <intptr_t>__cuMemAllocManaged
    global __cuDeviceRegisterAsyncNotification
    data["__cuDeviceRegisterAsyncNotification"] = <intptr_t>__cuDeviceRegisterAsyncNotification
    global __cuDeviceUnregisterAsyncNotification
    data["__cuDeviceUnregisterAsyncNotification"] = <intptr_t>__cuDeviceUnregisterAsyncNotification
    global __cuDeviceGetByPCIBusId
    data["__cuDeviceGetByPCIBusId"] = <intptr_t>__cuDeviceGetByPCIBusId
    global __cuDeviceGetPCIBusId
    data["__cuDeviceGetPCIBusId"] = <intptr_t>__cuDeviceGetPCIBusId
    global __cuIpcGetEventHandle
    data["__cuIpcGetEventHandle"] = <intptr_t>__cuIpcGetEventHandle
    global __cuIpcOpenEventHandle
    data["__cuIpcOpenEventHandle"] = <intptr_t>__cuIpcOpenEventHandle
    global __cuIpcGetMemHandle
    data["__cuIpcGetMemHandle"] = <intptr_t>__cuIpcGetMemHandle
    global __cuIpcOpenMemHandle_v2
    data["__cuIpcOpenMemHandle_v2"] = <intptr_t>__cuIpcOpenMemHandle_v2
    global __cuIpcCloseMemHandle
    data["__cuIpcCloseMemHandle"] = <intptr_t>__cuIpcCloseMemHandle
    global __cuMemHostRegister_v2
    data["__cuMemHostRegister_v2"] = <intptr_t>__cuMemHostRegister_v2
    global __cuMemHostUnregister
    data["__cuMemHostUnregister"] = <intptr_t>__cuMemHostUnregister
    global __cuMemcpy
    data["__cuMemcpy"] = <intptr_t>__cuMemcpy
    global __cuMemcpyPeer
    data["__cuMemcpyPeer"] = <intptr_t>__cuMemcpyPeer
    global __cuMemcpyHtoD_v2
    data["__cuMemcpyHtoD_v2"] = <intptr_t>__cuMemcpyHtoD_v2
    global __cuMemcpyDtoH_v2
    data["__cuMemcpyDtoH_v2"] = <intptr_t>__cuMemcpyDtoH_v2
    global __cuMemcpyDtoD_v2
    data["__cuMemcpyDtoD_v2"] = <intptr_t>__cuMemcpyDtoD_v2
    global __cuMemcpyDtoA_v2
    data["__cuMemcpyDtoA_v2"] = <intptr_t>__cuMemcpyDtoA_v2
    global __cuMemcpyAtoD_v2
    data["__cuMemcpyAtoD_v2"] = <intptr_t>__cuMemcpyAtoD_v2
    global __cuMemcpyHtoA_v2
    data["__cuMemcpyHtoA_v2"] = <intptr_t>__cuMemcpyHtoA_v2
    global __cuMemcpyAtoH_v2
    data["__cuMemcpyAtoH_v2"] = <intptr_t>__cuMemcpyAtoH_v2
    global __cuMemcpyAtoA_v2
    data["__cuMemcpyAtoA_v2"] = <intptr_t>__cuMemcpyAtoA_v2
    global __cuMemcpy2D_v2
    data["__cuMemcpy2D_v2"] = <intptr_t>__cuMemcpy2D_v2
    global __cuMemcpy2DUnaligned_v2
    data["__cuMemcpy2DUnaligned_v2"] = <intptr_t>__cuMemcpy2DUnaligned_v2
    global __cuMemcpy3D_v2
    data["__cuMemcpy3D_v2"] = <intptr_t>__cuMemcpy3D_v2
    global __cuMemcpy3DPeer
    data["__cuMemcpy3DPeer"] = <intptr_t>__cuMemcpy3DPeer
    global __cuMemcpyAsync
    data["__cuMemcpyAsync"] = <intptr_t>__cuMemcpyAsync
    global __cuMemcpyPeerAsync
    data["__cuMemcpyPeerAsync"] = <intptr_t>__cuMemcpyPeerAsync
    global __cuMemcpyHtoDAsync_v2
    data["__cuMemcpyHtoDAsync_v2"] = <intptr_t>__cuMemcpyHtoDAsync_v2
    global __cuMemcpyDtoHAsync_v2
    data["__cuMemcpyDtoHAsync_v2"] = <intptr_t>__cuMemcpyDtoHAsync_v2
    global __cuMemcpyDtoDAsync_v2
    data["__cuMemcpyDtoDAsync_v2"] = <intptr_t>__cuMemcpyDtoDAsync_v2
    global __cuMemcpyHtoAAsync_v2
    data["__cuMemcpyHtoAAsync_v2"] = <intptr_t>__cuMemcpyHtoAAsync_v2
    global __cuMemcpyAtoHAsync_v2
    data["__cuMemcpyAtoHAsync_v2"] = <intptr_t>__cuMemcpyAtoHAsync_v2
    global __cuMemcpy2DAsync_v2
    data["__cuMemcpy2DAsync_v2"] = <intptr_t>__cuMemcpy2DAsync_v2
    global __cuMemcpy3DAsync_v2
    data["__cuMemcpy3DAsync_v2"] = <intptr_t>__cuMemcpy3DAsync_v2
    global __cuMemcpy3DPeerAsync
    data["__cuMemcpy3DPeerAsync"] = <intptr_t>__cuMemcpy3DPeerAsync
    global __cuMemcpyBatchAsync
    data["__cuMemcpyBatchAsync"] = <intptr_t>__cuMemcpyBatchAsync
    global __cuMemcpy3DBatchAsync
    data["__cuMemcpy3DBatchAsync"] = <intptr_t>__cuMemcpy3DBatchAsync
    global __cuMemsetD8_v2
    data["__cuMemsetD8_v2"] = <intptr_t>__cuMemsetD8_v2
    global __cuMemsetD16_v2
    data["__cuMemsetD16_v2"] = <intptr_t>__cuMemsetD16_v2
    global __cuMemsetD32_v2
    data["__cuMemsetD32_v2"] = <intptr_t>__cuMemsetD32_v2
    global __cuMemsetD2D8_v2
    data["__cuMemsetD2D8_v2"] = <intptr_t>__cuMemsetD2D8_v2
    global __cuMemsetD2D16_v2
    data["__cuMemsetD2D16_v2"] = <intptr_t>__cuMemsetD2D16_v2
    global __cuMemsetD2D32_v2
    data["__cuMemsetD2D32_v2"] = <intptr_t>__cuMemsetD2D32_v2
    global __cuMemsetD8Async
    data["__cuMemsetD8Async"] = <intptr_t>__cuMemsetD8Async
    global __cuMemsetD16Async
    data["__cuMemsetD16Async"] = <intptr_t>__cuMemsetD16Async
    global __cuMemsetD32Async
    data["__cuMemsetD32Async"] = <intptr_t>__cuMemsetD32Async
    global __cuMemsetD2D8Async
    data["__cuMemsetD2D8Async"] = <intptr_t>__cuMemsetD2D8Async
    global __cuMemsetD2D16Async
    data["__cuMemsetD2D16Async"] = <intptr_t>__cuMemsetD2D16Async
    global __cuMemsetD2D32Async
    data["__cuMemsetD2D32Async"] = <intptr_t>__cuMemsetD2D32Async
    global __cuArrayCreate_v2
    data["__cuArrayCreate_v2"] = <intptr_t>__cuArrayCreate_v2
    global __cuArrayGetDescriptor_v2
    data["__cuArrayGetDescriptor_v2"] = <intptr_t>__cuArrayGetDescriptor_v2
    global __cuArrayGetSparseProperties
    data["__cuArrayGetSparseProperties"] = <intptr_t>__cuArrayGetSparseProperties
    global __cuMipmappedArrayGetSparseProperties
    data["__cuMipmappedArrayGetSparseProperties"] = <intptr_t>__cuMipmappedArrayGetSparseProperties
    global __cuArrayGetMemoryRequirements
    data["__cuArrayGetMemoryRequirements"] = <intptr_t>__cuArrayGetMemoryRequirements
    global __cuMipmappedArrayGetMemoryRequirements
    data["__cuMipmappedArrayGetMemoryRequirements"] = <intptr_t>__cuMipmappedArrayGetMemoryRequirements
    global __cuArrayGetPlane
    data["__cuArrayGetPlane"] = <intptr_t>__cuArrayGetPlane
    global __cuArrayDestroy
    data["__cuArrayDestroy"] = <intptr_t>__cuArrayDestroy
    global __cuArray3DCreate_v2
    data["__cuArray3DCreate_v2"] = <intptr_t>__cuArray3DCreate_v2
    global __cuArray3DGetDescriptor_v2
    data["__cuArray3DGetDescriptor_v2"] = <intptr_t>__cuArray3DGetDescriptor_v2
    global __cuMipmappedArrayCreate
    data["__cuMipmappedArrayCreate"] = <intptr_t>__cuMipmappedArrayCreate
    global __cuMipmappedArrayGetLevel
    data["__cuMipmappedArrayGetLevel"] = <intptr_t>__cuMipmappedArrayGetLevel
    global __cuMipmappedArrayDestroy
    data["__cuMipmappedArrayDestroy"] = <intptr_t>__cuMipmappedArrayDestroy
    global __cuMemGetHandleForAddressRange
    data["__cuMemGetHandleForAddressRange"] = <intptr_t>__cuMemGetHandleForAddressRange
    global __cuMemBatchDecompressAsync
    data["__cuMemBatchDecompressAsync"] = <intptr_t>__cuMemBatchDecompressAsync
    global __cuMemAddressReserve
    data["__cuMemAddressReserve"] = <intptr_t>__cuMemAddressReserve
    global __cuMemAddressFree
    data["__cuMemAddressFree"] = <intptr_t>__cuMemAddressFree
    global __cuMemCreate
    data["__cuMemCreate"] = <intptr_t>__cuMemCreate
    global __cuMemRelease
    data["__cuMemRelease"] = <intptr_t>__cuMemRelease
    global __cuMemMap
    data["__cuMemMap"] = <intptr_t>__cuMemMap
    global __cuMemMapArrayAsync
    data["__cuMemMapArrayAsync"] = <intptr_t>__cuMemMapArrayAsync
    global __cuMemUnmap
    data["__cuMemUnmap"] = <intptr_t>__cuMemUnmap
    global __cuMemSetAccess
    data["__cuMemSetAccess"] = <intptr_t>__cuMemSetAccess
    global __cuMemGetAccess
    data["__cuMemGetAccess"] = <intptr_t>__cuMemGetAccess
    global __cuMemExportToShareableHandle
    data["__cuMemExportToShareableHandle"] = <intptr_t>__cuMemExportToShareableHandle
    global __cuMemImportFromShareableHandle
    data["__cuMemImportFromShareableHandle"] = <intptr_t>__cuMemImportFromShareableHandle
    global __cuMemGetAllocationGranularity
    data["__cuMemGetAllocationGranularity"] = <intptr_t>__cuMemGetAllocationGranularity
    global __cuMemGetAllocationPropertiesFromHandle
    data["__cuMemGetAllocationPropertiesFromHandle"] = <intptr_t>__cuMemGetAllocationPropertiesFromHandle
    global __cuMemRetainAllocationHandle
    data["__cuMemRetainAllocationHandle"] = <intptr_t>__cuMemRetainAllocationHandle
    global __cuMemFreeAsync
    data["__cuMemFreeAsync"] = <intptr_t>__cuMemFreeAsync
    global __cuMemAllocAsync
    data["__cuMemAllocAsync"] = <intptr_t>__cuMemAllocAsync
    global __cuMemPoolTrimTo
    data["__cuMemPoolTrimTo"] = <intptr_t>__cuMemPoolTrimTo
    global __cuMemPoolSetAttribute
    data["__cuMemPoolSetAttribute"] = <intptr_t>__cuMemPoolSetAttribute
    global __cuMemPoolGetAttribute
    data["__cuMemPoolGetAttribute"] = <intptr_t>__cuMemPoolGetAttribute
    global __cuMemPoolSetAccess
    data["__cuMemPoolSetAccess"] = <intptr_t>__cuMemPoolSetAccess
    global __cuMemPoolGetAccess
    data["__cuMemPoolGetAccess"] = <intptr_t>__cuMemPoolGetAccess
    global __cuMemPoolCreate
    data["__cuMemPoolCreate"] = <intptr_t>__cuMemPoolCreate
    global __cuMemPoolDestroy
    data["__cuMemPoolDestroy"] = <intptr_t>__cuMemPoolDestroy
    global __cuMemAllocFromPoolAsync
    data["__cuMemAllocFromPoolAsync"] = <intptr_t>__cuMemAllocFromPoolAsync
    global __cuMemPoolExportToShareableHandle
    data["__cuMemPoolExportToShareableHandle"] = <intptr_t>__cuMemPoolExportToShareableHandle
    global __cuMemPoolImportFromShareableHandle
    data["__cuMemPoolImportFromShareableHandle"] = <intptr_t>__cuMemPoolImportFromShareableHandle
    global __cuMemPoolExportPointer
    data["__cuMemPoolExportPointer"] = <intptr_t>__cuMemPoolExportPointer
    global __cuMemPoolImportPointer
    data["__cuMemPoolImportPointer"] = <intptr_t>__cuMemPoolImportPointer
    global __cuMulticastCreate
    data["__cuMulticastCreate"] = <intptr_t>__cuMulticastCreate
    global __cuMulticastAddDevice
    data["__cuMulticastAddDevice"] = <intptr_t>__cuMulticastAddDevice
    global __cuMulticastBindMem
    data["__cuMulticastBindMem"] = <intptr_t>__cuMulticastBindMem
    global __cuMulticastBindAddr
    data["__cuMulticastBindAddr"] = <intptr_t>__cuMulticastBindAddr
    global __cuMulticastUnbind
    data["__cuMulticastUnbind"] = <intptr_t>__cuMulticastUnbind
    global __cuMulticastGetGranularity
    data["__cuMulticastGetGranularity"] = <intptr_t>__cuMulticastGetGranularity
    global __cuPointerGetAttribute
    data["__cuPointerGetAttribute"] = <intptr_t>__cuPointerGetAttribute
    global __cuMemPrefetchAsync
    data["__cuMemPrefetchAsync"] = <intptr_t>__cuMemPrefetchAsync
    global __cuMemPrefetchAsync_v2
    data["__cuMemPrefetchAsync_v2"] = <intptr_t>__cuMemPrefetchAsync_v2
    global __cuMemAdvise
    data["__cuMemAdvise"] = <intptr_t>__cuMemAdvise
    global __cuMemAdvise_v2
    data["__cuMemAdvise_v2"] = <intptr_t>__cuMemAdvise_v2
    global __cuMemRangeGetAttribute
    data["__cuMemRangeGetAttribute"] = <intptr_t>__cuMemRangeGetAttribute
    global __cuMemRangeGetAttributes
    data["__cuMemRangeGetAttributes"] = <intptr_t>__cuMemRangeGetAttributes
    global __cuPointerSetAttribute
    data["__cuPointerSetAttribute"] = <intptr_t>__cuPointerSetAttribute
    global __cuPointerGetAttributes
    data["__cuPointerGetAttributes"] = <intptr_t>__cuPointerGetAttributes
    global __cuStreamCreate
    data["__cuStreamCreate"] = <intptr_t>__cuStreamCreate
    global __cuStreamCreateWithPriority
    data["__cuStreamCreateWithPriority"] = <intptr_t>__cuStreamCreateWithPriority
    global __cuStreamGetPriority
    data["__cuStreamGetPriority"] = <intptr_t>__cuStreamGetPriority
    global __cuStreamGetDevice
    data["__cuStreamGetDevice"] = <intptr_t>__cuStreamGetDevice
    global __cuStreamGetFlags
    data["__cuStreamGetFlags"] = <intptr_t>__cuStreamGetFlags
    global __cuStreamGetId
    data["__cuStreamGetId"] = <intptr_t>__cuStreamGetId
    global __cuStreamGetCtx
    data["__cuStreamGetCtx"] = <intptr_t>__cuStreamGetCtx
    global __cuStreamGetCtx_v2
    data["__cuStreamGetCtx_v2"] = <intptr_t>__cuStreamGetCtx_v2
    global __cuStreamWaitEvent
    data["__cuStreamWaitEvent"] = <intptr_t>__cuStreamWaitEvent
    global __cuStreamAddCallback
    data["__cuStreamAddCallback"] = <intptr_t>__cuStreamAddCallback
    global __cuStreamBeginCapture_v2
    data["__cuStreamBeginCapture_v2"] = <intptr_t>__cuStreamBeginCapture_v2
    global __cuStreamBeginCaptureToGraph
    data["__cuStreamBeginCaptureToGraph"] = <intptr_t>__cuStreamBeginCaptureToGraph
    global __cuThreadExchangeStreamCaptureMode
    data["__cuThreadExchangeStreamCaptureMode"] = <intptr_t>__cuThreadExchangeStreamCaptureMode
    global __cuStreamEndCapture
    data["__cuStreamEndCapture"] = <intptr_t>__cuStreamEndCapture
    global __cuStreamIsCapturing
    data["__cuStreamIsCapturing"] = <intptr_t>__cuStreamIsCapturing
    global __cuStreamGetCaptureInfo_v2
    data["__cuStreamGetCaptureInfo_v2"] = <intptr_t>__cuStreamGetCaptureInfo_v2
    global __cuStreamGetCaptureInfo_v3
    data["__cuStreamGetCaptureInfo_v3"] = <intptr_t>__cuStreamGetCaptureInfo_v3
    global __cuStreamUpdateCaptureDependencies
    data["__cuStreamUpdateCaptureDependencies"] = <intptr_t>__cuStreamUpdateCaptureDependencies
    global __cuStreamUpdateCaptureDependencies_v2
    data["__cuStreamUpdateCaptureDependencies_v2"] = <intptr_t>__cuStreamUpdateCaptureDependencies_v2
    global __cuStreamAttachMemAsync
    data["__cuStreamAttachMemAsync"] = <intptr_t>__cuStreamAttachMemAsync
    global __cuStreamQuery
    data["__cuStreamQuery"] = <intptr_t>__cuStreamQuery
    global __cuStreamSynchronize
    data["__cuStreamSynchronize"] = <intptr_t>__cuStreamSynchronize
    global __cuStreamDestroy_v2
    data["__cuStreamDestroy_v2"] = <intptr_t>__cuStreamDestroy_v2
    global __cuStreamCopyAttributes
    data["__cuStreamCopyAttributes"] = <intptr_t>__cuStreamCopyAttributes
    global __cuStreamGetAttribute
    data["__cuStreamGetAttribute"] = <intptr_t>__cuStreamGetAttribute
    global __cuStreamSetAttribute
    data["__cuStreamSetAttribute"] = <intptr_t>__cuStreamSetAttribute
    global __cuEventCreate
    data["__cuEventCreate"] = <intptr_t>__cuEventCreate
    global __cuEventRecord
    data["__cuEventRecord"] = <intptr_t>__cuEventRecord
    global __cuEventRecordWithFlags
    data["__cuEventRecordWithFlags"] = <intptr_t>__cuEventRecordWithFlags
    global __cuEventQuery
    data["__cuEventQuery"] = <intptr_t>__cuEventQuery
    global __cuEventSynchronize
    data["__cuEventSynchronize"] = <intptr_t>__cuEventSynchronize
    global __cuEventDestroy_v2
    data["__cuEventDestroy_v2"] = <intptr_t>__cuEventDestroy_v2
    global __cuEventElapsedTime
    data["__cuEventElapsedTime"] = <intptr_t>__cuEventElapsedTime
    global __cuEventElapsedTime_v2
    data["__cuEventElapsedTime_v2"] = <intptr_t>__cuEventElapsedTime_v2
    global __cuImportExternalMemory
    data["__cuImportExternalMemory"] = <intptr_t>__cuImportExternalMemory
    global __cuExternalMemoryGetMappedBuffer
    data["__cuExternalMemoryGetMappedBuffer"] = <intptr_t>__cuExternalMemoryGetMappedBuffer
    global __cuExternalMemoryGetMappedMipmappedArray
    data["__cuExternalMemoryGetMappedMipmappedArray"] = <intptr_t>__cuExternalMemoryGetMappedMipmappedArray
    global __cuDestroyExternalMemory
    data["__cuDestroyExternalMemory"] = <intptr_t>__cuDestroyExternalMemory
    global __cuImportExternalSemaphore
    data["__cuImportExternalSemaphore"] = <intptr_t>__cuImportExternalSemaphore
    global __cuSignalExternalSemaphoresAsync
    data["__cuSignalExternalSemaphoresAsync"] = <intptr_t>__cuSignalExternalSemaphoresAsync
    global __cuWaitExternalSemaphoresAsync
    data["__cuWaitExternalSemaphoresAsync"] = <intptr_t>__cuWaitExternalSemaphoresAsync
    global __cuDestroyExternalSemaphore
    data["__cuDestroyExternalSemaphore"] = <intptr_t>__cuDestroyExternalSemaphore
    global __cuStreamWaitValue32_v2
    data["__cuStreamWaitValue32_v2"] = <intptr_t>__cuStreamWaitValue32_v2
    global __cuStreamWaitValue64_v2
    data["__cuStreamWaitValue64_v2"] = <intptr_t>__cuStreamWaitValue64_v2
    global __cuStreamWriteValue32_v2
    data["__cuStreamWriteValue32_v2"] = <intptr_t>__cuStreamWriteValue32_v2
    global __cuStreamWriteValue64_v2
    data["__cuStreamWriteValue64_v2"] = <intptr_t>__cuStreamWriteValue64_v2
    global __cuStreamBatchMemOp_v2
    data["__cuStreamBatchMemOp_v2"] = <intptr_t>__cuStreamBatchMemOp_v2
    global __cuFuncGetAttribute
    data["__cuFuncGetAttribute"] = <intptr_t>__cuFuncGetAttribute
    global __cuFuncSetAttribute
    data["__cuFuncSetAttribute"] = <intptr_t>__cuFuncSetAttribute
    global __cuFuncSetCacheConfig
    data["__cuFuncSetCacheConfig"] = <intptr_t>__cuFuncSetCacheConfig
    global __cuFuncGetModule
    data["__cuFuncGetModule"] = <intptr_t>__cuFuncGetModule
    global __cuFuncGetName
    data["__cuFuncGetName"] = <intptr_t>__cuFuncGetName
    global __cuFuncGetParamInfo
    data["__cuFuncGetParamInfo"] = <intptr_t>__cuFuncGetParamInfo
    global __cuFuncIsLoaded
    data["__cuFuncIsLoaded"] = <intptr_t>__cuFuncIsLoaded
    global __cuFuncLoad
    data["__cuFuncLoad"] = <intptr_t>__cuFuncLoad
    global __cuLaunchKernel
    data["__cuLaunchKernel"] = <intptr_t>__cuLaunchKernel
    global __cuLaunchKernelEx
    data["__cuLaunchKernelEx"] = <intptr_t>__cuLaunchKernelEx
    global __cuLaunchCooperativeKernel
    data["__cuLaunchCooperativeKernel"] = <intptr_t>__cuLaunchCooperativeKernel
    global __cuLaunchCooperativeKernelMultiDevice
    data["__cuLaunchCooperativeKernelMultiDevice"] = <intptr_t>__cuLaunchCooperativeKernelMultiDevice
    global __cuLaunchHostFunc
    data["__cuLaunchHostFunc"] = <intptr_t>__cuLaunchHostFunc
    global __cuFuncSetBlockShape
    data["__cuFuncSetBlockShape"] = <intptr_t>__cuFuncSetBlockShape
    global __cuFuncSetSharedSize
    data["__cuFuncSetSharedSize"] = <intptr_t>__cuFuncSetSharedSize
    global __cuParamSetSize
    data["__cuParamSetSize"] = <intptr_t>__cuParamSetSize
    global __cuParamSeti
    data["__cuParamSeti"] = <intptr_t>__cuParamSeti
    global __cuParamSetf
    data["__cuParamSetf"] = <intptr_t>__cuParamSetf
    global __cuParamSetv
    data["__cuParamSetv"] = <intptr_t>__cuParamSetv
    global __cuLaunch
    data["__cuLaunch"] = <intptr_t>__cuLaunch
    global __cuLaunchGrid
    data["__cuLaunchGrid"] = <intptr_t>__cuLaunchGrid
    global __cuLaunchGridAsync
    data["__cuLaunchGridAsync"] = <intptr_t>__cuLaunchGridAsync
    global __cuParamSetTexRef
    data["__cuParamSetTexRef"] = <intptr_t>__cuParamSetTexRef
    global __cuFuncSetSharedMemConfig
    data["__cuFuncSetSharedMemConfig"] = <intptr_t>__cuFuncSetSharedMemConfig
    global __cuGraphCreate
    data["__cuGraphCreate"] = <intptr_t>__cuGraphCreate
    global __cuGraphAddKernelNode_v2
    data["__cuGraphAddKernelNode_v2"] = <intptr_t>__cuGraphAddKernelNode_v2
    global __cuGraphKernelNodeGetParams_v2
    data["__cuGraphKernelNodeGetParams_v2"] = <intptr_t>__cuGraphKernelNodeGetParams_v2
    global __cuGraphKernelNodeSetParams_v2
    data["__cuGraphKernelNodeSetParams_v2"] = <intptr_t>__cuGraphKernelNodeSetParams_v2
    global __cuGraphAddMemcpyNode
    data["__cuGraphAddMemcpyNode"] = <intptr_t>__cuGraphAddMemcpyNode
    global __cuGraphMemcpyNodeGetParams
    data["__cuGraphMemcpyNodeGetParams"] = <intptr_t>__cuGraphMemcpyNodeGetParams
    global __cuGraphMemcpyNodeSetParams
    data["__cuGraphMemcpyNodeSetParams"] = <intptr_t>__cuGraphMemcpyNodeSetParams
    global __cuGraphAddMemsetNode
    data["__cuGraphAddMemsetNode"] = <intptr_t>__cuGraphAddMemsetNode
    global __cuGraphMemsetNodeGetParams
    data["__cuGraphMemsetNodeGetParams"] = <intptr_t>__cuGraphMemsetNodeGetParams
    global __cuGraphMemsetNodeSetParams
    data["__cuGraphMemsetNodeSetParams"] = <intptr_t>__cuGraphMemsetNodeSetParams
    global __cuGraphAddHostNode
    data["__cuGraphAddHostNode"] = <intptr_t>__cuGraphAddHostNode
    global __cuGraphHostNodeGetParams
    data["__cuGraphHostNodeGetParams"] = <intptr_t>__cuGraphHostNodeGetParams
    global __cuGraphHostNodeSetParams
    data["__cuGraphHostNodeSetParams"] = <intptr_t>__cuGraphHostNodeSetParams
    global __cuGraphAddChildGraphNode
    data["__cuGraphAddChildGraphNode"] = <intptr_t>__cuGraphAddChildGraphNode
    global __cuGraphChildGraphNodeGetGraph
    data["__cuGraphChildGraphNodeGetGraph"] = <intptr_t>__cuGraphChildGraphNodeGetGraph
    global __cuGraphAddEmptyNode
    data["__cuGraphAddEmptyNode"] = <intptr_t>__cuGraphAddEmptyNode
    global __cuGraphAddEventRecordNode
    data["__cuGraphAddEventRecordNode"] = <intptr_t>__cuGraphAddEventRecordNode
    global __cuGraphEventRecordNodeGetEvent
    data["__cuGraphEventRecordNodeGetEvent"] = <intptr_t>__cuGraphEventRecordNodeGetEvent
    global __cuGraphEventRecordNodeSetEvent
    data["__cuGraphEventRecordNodeSetEvent"] = <intptr_t>__cuGraphEventRecordNodeSetEvent
    global __cuGraphAddEventWaitNode
    data["__cuGraphAddEventWaitNode"] = <intptr_t>__cuGraphAddEventWaitNode
    global __cuGraphEventWaitNodeGetEvent
    data["__cuGraphEventWaitNodeGetEvent"] = <intptr_t>__cuGraphEventWaitNodeGetEvent
    global __cuGraphEventWaitNodeSetEvent
    data["__cuGraphEventWaitNodeSetEvent"] = <intptr_t>__cuGraphEventWaitNodeSetEvent
    global __cuGraphAddExternalSemaphoresSignalNode
    data["__cuGraphAddExternalSemaphoresSignalNode"] = <intptr_t>__cuGraphAddExternalSemaphoresSignalNode
    global __cuGraphExternalSemaphoresSignalNodeGetParams
    data["__cuGraphExternalSemaphoresSignalNodeGetParams"] = <intptr_t>__cuGraphExternalSemaphoresSignalNodeGetParams
    global __cuGraphExternalSemaphoresSignalNodeSetParams
    data["__cuGraphExternalSemaphoresSignalNodeSetParams"] = <intptr_t>__cuGraphExternalSemaphoresSignalNodeSetParams
    global __cuGraphAddExternalSemaphoresWaitNode
    data["__cuGraphAddExternalSemaphoresWaitNode"] = <intptr_t>__cuGraphAddExternalSemaphoresWaitNode
    global __cuGraphExternalSemaphoresWaitNodeGetParams
    data["__cuGraphExternalSemaphoresWaitNodeGetParams"] = <intptr_t>__cuGraphExternalSemaphoresWaitNodeGetParams
    global __cuGraphExternalSemaphoresWaitNodeSetParams
    data["__cuGraphExternalSemaphoresWaitNodeSetParams"] = <intptr_t>__cuGraphExternalSemaphoresWaitNodeSetParams
    global __cuGraphAddBatchMemOpNode
    data["__cuGraphAddBatchMemOpNode"] = <intptr_t>__cuGraphAddBatchMemOpNode
    global __cuGraphBatchMemOpNodeGetParams
    data["__cuGraphBatchMemOpNodeGetParams"] = <intptr_t>__cuGraphBatchMemOpNodeGetParams
    global __cuGraphBatchMemOpNodeSetParams
    data["__cuGraphBatchMemOpNodeSetParams"] = <intptr_t>__cuGraphBatchMemOpNodeSetParams
    global __cuGraphExecBatchMemOpNodeSetParams
    data["__cuGraphExecBatchMemOpNodeSetParams"] = <intptr_t>__cuGraphExecBatchMemOpNodeSetParams
    global __cuGraphAddMemAllocNode
    data["__cuGraphAddMemAllocNode"] = <intptr_t>__cuGraphAddMemAllocNode
    global __cuGraphMemAllocNodeGetParams
    data["__cuGraphMemAllocNodeGetParams"] = <intptr_t>__cuGraphMemAllocNodeGetParams
    global __cuGraphAddMemFreeNode
    data["__cuGraphAddMemFreeNode"] = <intptr_t>__cuGraphAddMemFreeNode
    global __cuGraphMemFreeNodeGetParams
    data["__cuGraphMemFreeNodeGetParams"] = <intptr_t>__cuGraphMemFreeNodeGetParams
    global __cuDeviceGraphMemTrim
    data["__cuDeviceGraphMemTrim"] = <intptr_t>__cuDeviceGraphMemTrim
    global __cuDeviceGetGraphMemAttribute
    data["__cuDeviceGetGraphMemAttribute"] = <intptr_t>__cuDeviceGetGraphMemAttribute
    global __cuDeviceSetGraphMemAttribute
    data["__cuDeviceSetGraphMemAttribute"] = <intptr_t>__cuDeviceSetGraphMemAttribute
    global __cuGraphClone
    data["__cuGraphClone"] = <intptr_t>__cuGraphClone
    global __cuGraphNodeFindInClone
    data["__cuGraphNodeFindInClone"] = <intptr_t>__cuGraphNodeFindInClone
    global __cuGraphNodeGetType
    data["__cuGraphNodeGetType"] = <intptr_t>__cuGraphNodeGetType
    global __cuGraphGetNodes
    data["__cuGraphGetNodes"] = <intptr_t>__cuGraphGetNodes
    global __cuGraphGetRootNodes
    data["__cuGraphGetRootNodes"] = <intptr_t>__cuGraphGetRootNodes
    global __cuGraphGetEdges
    data["__cuGraphGetEdges"] = <intptr_t>__cuGraphGetEdges
    global __cuGraphGetEdges_v2
    data["__cuGraphGetEdges_v2"] = <intptr_t>__cuGraphGetEdges_v2
    global __cuGraphNodeGetDependencies
    data["__cuGraphNodeGetDependencies"] = <intptr_t>__cuGraphNodeGetDependencies
    global __cuGraphNodeGetDependencies_v2
    data["__cuGraphNodeGetDependencies_v2"] = <intptr_t>__cuGraphNodeGetDependencies_v2
    global __cuGraphNodeGetDependentNodes
    data["__cuGraphNodeGetDependentNodes"] = <intptr_t>__cuGraphNodeGetDependentNodes
    global __cuGraphNodeGetDependentNodes_v2
    data["__cuGraphNodeGetDependentNodes_v2"] = <intptr_t>__cuGraphNodeGetDependentNodes_v2
    global __cuGraphAddDependencies
    data["__cuGraphAddDependencies"] = <intptr_t>__cuGraphAddDependencies
    global __cuGraphAddDependencies_v2
    data["__cuGraphAddDependencies_v2"] = <intptr_t>__cuGraphAddDependencies_v2
    global __cuGraphRemoveDependencies
    data["__cuGraphRemoveDependencies"] = <intptr_t>__cuGraphRemoveDependencies
    global __cuGraphRemoveDependencies_v2
    data["__cuGraphRemoveDependencies_v2"] = <intptr_t>__cuGraphRemoveDependencies_v2
    global __cuGraphDestroyNode
    data["__cuGraphDestroyNode"] = <intptr_t>__cuGraphDestroyNode
    global __cuGraphInstantiateWithFlags
    data["__cuGraphInstantiateWithFlags"] = <intptr_t>__cuGraphInstantiateWithFlags
    global __cuGraphInstantiateWithParams
    data["__cuGraphInstantiateWithParams"] = <intptr_t>__cuGraphInstantiateWithParams
    global __cuGraphExecGetFlags
    data["__cuGraphExecGetFlags"] = <intptr_t>__cuGraphExecGetFlags
    global __cuGraphExecKernelNodeSetParams_v2
    data["__cuGraphExecKernelNodeSetParams_v2"] = <intptr_t>__cuGraphExecKernelNodeSetParams_v2
    global __cuGraphExecMemcpyNodeSetParams
    data["__cuGraphExecMemcpyNodeSetParams"] = <intptr_t>__cuGraphExecMemcpyNodeSetParams
    global __cuGraphExecMemsetNodeSetParams
    data["__cuGraphExecMemsetNodeSetParams"] = <intptr_t>__cuGraphExecMemsetNodeSetParams
    global __cuGraphExecHostNodeSetParams
    data["__cuGraphExecHostNodeSetParams"] = <intptr_t>__cuGraphExecHostNodeSetParams
    global __cuGraphExecChildGraphNodeSetParams
    data["__cuGraphExecChildGraphNodeSetParams"] = <intptr_t>__cuGraphExecChildGraphNodeSetParams
    global __cuGraphExecEventRecordNodeSetEvent
    data["__cuGraphExecEventRecordNodeSetEvent"] = <intptr_t>__cuGraphExecEventRecordNodeSetEvent
    global __cuGraphExecEventWaitNodeSetEvent
    data["__cuGraphExecEventWaitNodeSetEvent"] = <intptr_t>__cuGraphExecEventWaitNodeSetEvent
    global __cuGraphExecExternalSemaphoresSignalNodeSetParams
    data["__cuGraphExecExternalSemaphoresSignalNodeSetParams"] = <intptr_t>__cuGraphExecExternalSemaphoresSignalNodeSetParams
    global __cuGraphExecExternalSemaphoresWaitNodeSetParams
    data["__cuGraphExecExternalSemaphoresWaitNodeSetParams"] = <intptr_t>__cuGraphExecExternalSemaphoresWaitNodeSetParams
    global __cuGraphNodeSetEnabled
    data["__cuGraphNodeSetEnabled"] = <intptr_t>__cuGraphNodeSetEnabled
    global __cuGraphNodeGetEnabled
    data["__cuGraphNodeGetEnabled"] = <intptr_t>__cuGraphNodeGetEnabled
    global __cuGraphUpload
    data["__cuGraphUpload"] = <intptr_t>__cuGraphUpload
    global __cuGraphLaunch
    data["__cuGraphLaunch"] = <intptr_t>__cuGraphLaunch
    global __cuGraphExecDestroy
    data["__cuGraphExecDestroy"] = <intptr_t>__cuGraphExecDestroy
    global __cuGraphDestroy
    data["__cuGraphDestroy"] = <intptr_t>__cuGraphDestroy
    global __cuGraphExecUpdate_v2
    data["__cuGraphExecUpdate_v2"] = <intptr_t>__cuGraphExecUpdate_v2
    global __cuGraphKernelNodeCopyAttributes
    data["__cuGraphKernelNodeCopyAttributes"] = <intptr_t>__cuGraphKernelNodeCopyAttributes
    global __cuGraphKernelNodeGetAttribute
    data["__cuGraphKernelNodeGetAttribute"] = <intptr_t>__cuGraphKernelNodeGetAttribute
    global __cuGraphKernelNodeSetAttribute
    data["__cuGraphKernelNodeSetAttribute"] = <intptr_t>__cuGraphKernelNodeSetAttribute
    global __cuGraphDebugDotPrint
    data["__cuGraphDebugDotPrint"] = <intptr_t>__cuGraphDebugDotPrint
    global __cuUserObjectCreate
    data["__cuUserObjectCreate"] = <intptr_t>__cuUserObjectCreate
    global __cuUserObjectRetain
    data["__cuUserObjectRetain"] = <intptr_t>__cuUserObjectRetain
    global __cuUserObjectRelease
    data["__cuUserObjectRelease"] = <intptr_t>__cuUserObjectRelease
    global __cuGraphRetainUserObject
    data["__cuGraphRetainUserObject"] = <intptr_t>__cuGraphRetainUserObject
    global __cuGraphReleaseUserObject
    data["__cuGraphReleaseUserObject"] = <intptr_t>__cuGraphReleaseUserObject
    global __cuGraphAddNode
    data["__cuGraphAddNode"] = <intptr_t>__cuGraphAddNode
    global __cuGraphAddNode_v2
    data["__cuGraphAddNode_v2"] = <intptr_t>__cuGraphAddNode_v2
    global __cuGraphNodeSetParams
    data["__cuGraphNodeSetParams"] = <intptr_t>__cuGraphNodeSetParams
    global __cuGraphExecNodeSetParams
    data["__cuGraphExecNodeSetParams"] = <intptr_t>__cuGraphExecNodeSetParams
    global __cuGraphConditionalHandleCreate
    data["__cuGraphConditionalHandleCreate"] = <intptr_t>__cuGraphConditionalHandleCreate
    global __cuOccupancyMaxActiveBlocksPerMultiprocessor
    data["__cuOccupancyMaxActiveBlocksPerMultiprocessor"] = <intptr_t>__cuOccupancyMaxActiveBlocksPerMultiprocessor
    global __cuOccupancyMaxActiveBlocksPerMultiprocessorWithFlags
    data["__cuOccupancyMaxActiveBlocksPerMultiprocessorWithFlags"] = <intptr_t>__cuOccupancyMaxActiveBlocksPerMultiprocessorWithFlags
    global __cuOccupancyMaxPotentialBlockSize
    data["__cuOccupancyMaxPotentialBlockSize"] = <intptr_t>__cuOccupancyMaxPotentialBlockSize
    global __cuOccupancyMaxPotentialBlockSizeWithFlags
    data["__cuOccupancyMaxPotentialBlockSizeWithFlags"] = <intptr_t>__cuOccupancyMaxPotentialBlockSizeWithFlags
    global __cuOccupancyAvailableDynamicSMemPerBlock
    data["__cuOccupancyAvailableDynamicSMemPerBlock"] = <intptr_t>__cuOccupancyAvailableDynamicSMemPerBlock
    global __cuOccupancyMaxPotentialClusterSize
    data["__cuOccupancyMaxPotentialClusterSize"] = <intptr_t>__cuOccupancyMaxPotentialClusterSize
    global __cuOccupancyMaxActiveClusters
    data["__cuOccupancyMaxActiveClusters"] = <intptr_t>__cuOccupancyMaxActiveClusters
    global __cuTexRefSetArray
    data["__cuTexRefSetArray"] = <intptr_t>__cuTexRefSetArray
    global __cuTexRefSetMipmappedArray
    data["__cuTexRefSetMipmappedArray"] = <intptr_t>__cuTexRefSetMipmappedArray
    global __cuTexRefSetAddress_v2
    data["__cuTexRefSetAddress_v2"] = <intptr_t>__cuTexRefSetAddress_v2
    global __cuTexRefSetAddress2D_v3
    data["__cuTexRefSetAddress2D_v3"] = <intptr_t>__cuTexRefSetAddress2D_v3
    global __cuTexRefSetFormat
    data["__cuTexRefSetFormat"] = <intptr_t>__cuTexRefSetFormat
    global __cuTexRefSetAddressMode
    data["__cuTexRefSetAddressMode"] = <intptr_t>__cuTexRefSetAddressMode
    global __cuTexRefSetFilterMode
    data["__cuTexRefSetFilterMode"] = <intptr_t>__cuTexRefSetFilterMode
    global __cuTexRefSetMipmapFilterMode
    data["__cuTexRefSetMipmapFilterMode"] = <intptr_t>__cuTexRefSetMipmapFilterMode
    global __cuTexRefSetMipmapLevelBias
    data["__cuTexRefSetMipmapLevelBias"] = <intptr_t>__cuTexRefSetMipmapLevelBias
    global __cuTexRefSetMipmapLevelClamp
    data["__cuTexRefSetMipmapLevelClamp"] = <intptr_t>__cuTexRefSetMipmapLevelClamp
    global __cuTexRefSetMaxAnisotropy
    data["__cuTexRefSetMaxAnisotropy"] = <intptr_t>__cuTexRefSetMaxAnisotropy
    global __cuTexRefSetBorderColor
    data["__cuTexRefSetBorderColor"] = <intptr_t>__cuTexRefSetBorderColor
    global __cuTexRefSetFlags
    data["__cuTexRefSetFlags"] = <intptr_t>__cuTexRefSetFlags
    global __cuTexRefGetAddress_v2
    data["__cuTexRefGetAddress_v2"] = <intptr_t>__cuTexRefGetAddress_v2
    global __cuTexRefGetArray
    data["__cuTexRefGetArray"] = <intptr_t>__cuTexRefGetArray
    global __cuTexRefGetMipmappedArray
    data["__cuTexRefGetMipmappedArray"] = <intptr_t>__cuTexRefGetMipmappedArray
    global __cuTexRefGetAddressMode
    data["__cuTexRefGetAddressMode"] = <intptr_t>__cuTexRefGetAddressMode
    global __cuTexRefGetFilterMode
    data["__cuTexRefGetFilterMode"] = <intptr_t>__cuTexRefGetFilterMode
    global __cuTexRefGetFormat
    data["__cuTexRefGetFormat"] = <intptr_t>__cuTexRefGetFormat
    global __cuTexRefGetMipmapFilterMode
    data["__cuTexRefGetMipmapFilterMode"] = <intptr_t>__cuTexRefGetMipmapFilterMode
    global __cuTexRefGetMipmapLevelBias
    data["__cuTexRefGetMipmapLevelBias"] = <intptr_t>__cuTexRefGetMipmapLevelBias
    global __cuTexRefGetMipmapLevelClamp
    data["__cuTexRefGetMipmapLevelClamp"] = <intptr_t>__cuTexRefGetMipmapLevelClamp
    global __cuTexRefGetMaxAnisotropy
    data["__cuTexRefGetMaxAnisotropy"] = <intptr_t>__cuTexRefGetMaxAnisotropy
    global __cuTexRefGetBorderColor
    data["__cuTexRefGetBorderColor"] = <intptr_t>__cuTexRefGetBorderColor
    global __cuTexRefGetFlags
    data["__cuTexRefGetFlags"] = <intptr_t>__cuTexRefGetFlags
    global __cuTexRefCreate
    data["__cuTexRefCreate"] = <intptr_t>__cuTexRefCreate
    global __cuTexRefDestroy
    data["__cuTexRefDestroy"] = <intptr_t>__cuTexRefDestroy
    global __cuSurfRefSetArray
    data["__cuSurfRefSetArray"] = <intptr_t>__cuSurfRefSetArray
    global __cuSurfRefGetArray
    data["__cuSurfRefGetArray"] = <intptr_t>__cuSurfRefGetArray
    global __cuTexObjectCreate
    data["__cuTexObjectCreate"] = <intptr_t>__cuTexObjectCreate
    global __cuTexObjectDestroy
    data["__cuTexObjectDestroy"] = <intptr_t>__cuTexObjectDestroy
    global __cuTexObjectGetResourceDesc
    data["__cuTexObjectGetResourceDesc"] = <intptr_t>__cuTexObjectGetResourceDesc
    global __cuTexObjectGetTextureDesc
    data["__cuTexObjectGetTextureDesc"] = <intptr_t>__cuTexObjectGetTextureDesc
    global __cuTexObjectGetResourceViewDesc
    data["__cuTexObjectGetResourceViewDesc"] = <intptr_t>__cuTexObjectGetResourceViewDesc
    global __cuSurfObjectCreate
    data["__cuSurfObjectCreate"] = <intptr_t>__cuSurfObjectCreate
    global __cuSurfObjectDestroy
    data["__cuSurfObjectDestroy"] = <intptr_t>__cuSurfObjectDestroy
    global __cuSurfObjectGetResourceDesc
    data["__cuSurfObjectGetResourceDesc"] = <intptr_t>__cuSurfObjectGetResourceDesc
    global __cuTensorMapEncodeTiled
    data["__cuTensorMapEncodeTiled"] = <intptr_t>__cuTensorMapEncodeTiled
    global __cuTensorMapEncodeIm2col
    data["__cuTensorMapEncodeIm2col"] = <intptr_t>__cuTensorMapEncodeIm2col
    global __cuTensorMapEncodeIm2colWide
    data["__cuTensorMapEncodeIm2colWide"] = <intptr_t>__cuTensorMapEncodeIm2colWide
    global __cuTensorMapReplaceAddress
    data["__cuTensorMapReplaceAddress"] = <intptr_t>__cuTensorMapReplaceAddress
    global __cuDeviceCanAccessPeer
    data["__cuDeviceCanAccessPeer"] = <intptr_t>__cuDeviceCanAccessPeer
    global __cuCtxEnablePeerAccess
    data["__cuCtxEnablePeerAccess"] = <intptr_t>__cuCtxEnablePeerAccess
    global __cuCtxDisablePeerAccess
    data["__cuCtxDisablePeerAccess"] = <intptr_t>__cuCtxDisablePeerAccess
    global __cuDeviceGetP2PAttribute
    data["__cuDeviceGetP2PAttribute"] = <intptr_t>__cuDeviceGetP2PAttribute
    global __cuGraphicsUnregisterResource
    data["__cuGraphicsUnregisterResource"] = <intptr_t>__cuGraphicsUnregisterResource
    global __cuGraphicsSubResourceGetMappedArray
    data["__cuGraphicsSubResourceGetMappedArray"] = <intptr_t>__cuGraphicsSubResourceGetMappedArray
    global __cuGraphicsResourceGetMappedMipmappedArray
    data["__cuGraphicsResourceGetMappedMipmappedArray"] = <intptr_t>__cuGraphicsResourceGetMappedMipmappedArray
    global __cuGraphicsResourceGetMappedPointer_v2
    data["__cuGraphicsResourceGetMappedPointer_v2"] = <intptr_t>__cuGraphicsResourceGetMappedPointer_v2
    global __cuGraphicsResourceSetMapFlags_v2
    data["__cuGraphicsResourceSetMapFlags_v2"] = <intptr_t>__cuGraphicsResourceSetMapFlags_v2
    global __cuGraphicsMapResources
    data["__cuGraphicsMapResources"] = <intptr_t>__cuGraphicsMapResources
    global __cuGraphicsUnmapResources
    data["__cuGraphicsUnmapResources"] = <intptr_t>__cuGraphicsUnmapResources
    global __cuGetProcAddress_v2
    data["__cuGetProcAddress_v2"] = <intptr_t>__cuGetProcAddress_v2
    global __cuCoredumpGetAttribute
    data["__cuCoredumpGetAttribute"] = <intptr_t>__cuCoredumpGetAttribute
    global __cuCoredumpGetAttributeGlobal
    data["__cuCoredumpGetAttributeGlobal"] = <intptr_t>__cuCoredumpGetAttributeGlobal
    global __cuCoredumpSetAttribute
    data["__cuCoredumpSetAttribute"] = <intptr_t>__cuCoredumpSetAttribute
    global __cuCoredumpSetAttributeGlobal
    data["__cuCoredumpSetAttributeGlobal"] = <intptr_t>__cuCoredumpSetAttributeGlobal
    global __cuGetExportTable
    data["__cuGetExportTable"] = <intptr_t>__cuGetExportTable
    global __cuGreenCtxCreate
    data["__cuGreenCtxCreate"] = <intptr_t>__cuGreenCtxCreate
    global __cuGreenCtxDestroy
    data["__cuGreenCtxDestroy"] = <intptr_t>__cuGreenCtxDestroy
    global __cuCtxFromGreenCtx
    data["__cuCtxFromGreenCtx"] = <intptr_t>__cuCtxFromGreenCtx
    global __cuDeviceGetDevResource
    data["__cuDeviceGetDevResource"] = <intptr_t>__cuDeviceGetDevResource
    global __cuCtxGetDevResource
    data["__cuCtxGetDevResource"] = <intptr_t>__cuCtxGetDevResource
    global __cuGreenCtxGetDevResource
    data["__cuGreenCtxGetDevResource"] = <intptr_t>__cuGreenCtxGetDevResource
    global __cuDevSmResourceSplitByCount
    data["__cuDevSmResourceSplitByCount"] = <intptr_t>__cuDevSmResourceSplitByCount
    global __cuDevResourceGenerateDesc
    data["__cuDevResourceGenerateDesc"] = <intptr_t>__cuDevResourceGenerateDesc
    global __cuGreenCtxRecordEvent
    data["__cuGreenCtxRecordEvent"] = <intptr_t>__cuGreenCtxRecordEvent
    global __cuGreenCtxWaitEvent
    data["__cuGreenCtxWaitEvent"] = <intptr_t>__cuGreenCtxWaitEvent
    global __cuStreamGetGreenCtx
    data["__cuStreamGetGreenCtx"] = <intptr_t>__cuStreamGetGreenCtx
    global __cuGreenCtxStreamCreate
    data["__cuGreenCtxStreamCreate"] = <intptr_t>__cuGreenCtxStreamCreate
    global __cuLogsRegisterCallback
    data["__cuLogsRegisterCallback"] = <intptr_t>__cuLogsRegisterCallback
    global __cuLogsUnregisterCallback
    data["__cuLogsUnregisterCallback"] = <intptr_t>__cuLogsUnregisterCallback
    global __cuLogsCurrent
    data["__cuLogsCurrent"] = <intptr_t>__cuLogsCurrent
    global __cuLogsDumpToFile
    data["__cuLogsDumpToFile"] = <intptr_t>__cuLogsDumpToFile
    global __cuLogsDumpToMemory
    data["__cuLogsDumpToMemory"] = <intptr_t>__cuLogsDumpToMemory
    global __cuCheckpointProcessGetRestoreThreadId
    data["__cuCheckpointProcessGetRestoreThreadId"] = <intptr_t>__cuCheckpointProcessGetRestoreThreadId
    global __cuCheckpointProcessGetState
    data["__cuCheckpointProcessGetState"] = <intptr_t>__cuCheckpointProcessGetState
    global __cuCheckpointProcessLock
    data["__cuCheckpointProcessLock"] = <intptr_t>__cuCheckpointProcessLock
    global __cuCheckpointProcessCheckpoint
    data["__cuCheckpointProcessCheckpoint"] = <intptr_t>__cuCheckpointProcessCheckpoint
    global __cuCheckpointProcessRestore
    data["__cuCheckpointProcessRestore"] = <intptr_t>__cuCheckpointProcessRestore
    global __cuCheckpointProcessUnlock
    data["__cuCheckpointProcessUnlock"] = <intptr_t>__cuCheckpointProcessUnlock
    global __cuProfilerStart
    data["__cuProfilerStart"] = <intptr_t>__cuProfilerStart
    global __cuProfilerStop
    data["__cuProfilerStop"] = <intptr_t>__cuProfilerStop
    global __cuGraphicsEGLRegisterImage
    data["__cuGraphicsEGLRegisterImage"] = <intptr_t>__cuGraphicsEGLRegisterImage
    global __cuEGLStreamConsumerConnect
    data["__cuEGLStreamConsumerConnect"] = <intptr_t>__cuEGLStreamConsumerConnect
    global __cuEGLStreamConsumerConnectWithFlags
    data["__cuEGLStreamConsumerConnectWithFlags"] = <intptr_t>__cuEGLStreamConsumerConnectWithFlags
    global __cuEGLStreamConsumerDisconnect
    data["__cuEGLStreamConsumerDisconnect"] = <intptr_t>__cuEGLStreamConsumerDisconnect
    global __cuEGLStreamConsumerAcquireFrame
    data["__cuEGLStreamConsumerAcquireFrame"] = <intptr_t>__cuEGLStreamConsumerAcquireFrame
    global __cuEGLStreamConsumerReleaseFrame
    data["__cuEGLStreamConsumerReleaseFrame"] = <intptr_t>__cuEGLStreamConsumerReleaseFrame
    global __cuEGLStreamProducerConnect
    data["__cuEGLStreamProducerConnect"] = <intptr_t>__cuEGLStreamProducerConnect
    global __cuEGLStreamProducerDisconnect
    data["__cuEGLStreamProducerDisconnect"] = <intptr_t>__cuEGLStreamProducerDisconnect
    global __cuEGLStreamProducerPresentFrame
    data["__cuEGLStreamProducerPresentFrame"] = <intptr_t>__cuEGLStreamProducerPresentFrame
    global __cuEGLStreamProducerReturnFrame
    data["__cuEGLStreamProducerReturnFrame"] = <intptr_t>__cuEGLStreamProducerReturnFrame
    global __cuGraphicsResourceGetMappedEglFrame
    data["__cuGraphicsResourceGetMappedEglFrame"] = <intptr_t>__cuGraphicsResourceGetMappedEglFrame
    global __cuEventCreateFromEGLSync
    data["__cuEventCreateFromEGLSync"] = <intptr_t>__cuEventCreateFromEGLSync
    global __cuGraphicsGLRegisterBuffer
    data["__cuGraphicsGLRegisterBuffer"] = <intptr_t>__cuGraphicsGLRegisterBuffer
    global __cuGraphicsGLRegisterImage
    data["__cuGraphicsGLRegisterImage"] = <intptr_t>__cuGraphicsGLRegisterImage
    global __cuGLGetDevices_v2
    data["__cuGLGetDevices_v2"] = <intptr_t>__cuGLGetDevices_v2
    global __cuVDPAUGetDevice
    data["__cuVDPAUGetDevice"] = <intptr_t>__cuVDPAUGetDevice
    global __cuVDPAUCtxCreate_v2
    data["__cuVDPAUCtxCreate_v2"] = <intptr_t>__cuVDPAUCtxCreate_v2
    global __cuGraphicsVDPAURegisterVideoSurface
    data["__cuGraphicsVDPAURegisterVideoSurface"] = <intptr_t>__cuGraphicsVDPAURegisterVideoSurface
    global __cuGraphicsVDPAURegisterOutputSurface
    data["__cuGraphicsVDPAURegisterOutputSurface"] = <intptr_t>__cuGraphicsVDPAURegisterOutputSurface

    func_ptrs = data
    return data

cpdef _inspect_function_pointer(str name):
    global func_ptrs
    if func_ptrs is None:
        func_ptrs = _inspect_function_pointers()
    return func_ptrs[name]
