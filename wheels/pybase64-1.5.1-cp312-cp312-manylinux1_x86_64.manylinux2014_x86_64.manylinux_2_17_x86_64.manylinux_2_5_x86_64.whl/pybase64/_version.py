from __future__ import annotations

_version = "1.5.1"
