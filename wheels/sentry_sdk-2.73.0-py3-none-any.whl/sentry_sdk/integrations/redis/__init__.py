import warnings
from typing import TYPE_CHECKING

from sentry_sdk.integrations import DidNotEnable, Integration
from sentry_sdk.integrations.redis.consts import _DEFAULT_MAX_DATA_SIZE
from sentry_sdk.integrations.redis.rb import _patch_rb
from sentry_sdk.integrations.redis.redis import _patch_redis
from sentry_sdk.integrations.redis.redis_cluster import _patch_redis_cluster
from sentry_sdk.integrations.redis.redis_py_cluster_legacy import _patch_rediscluster
from sentry_sdk.utils import logger

if TYPE_CHECKING:
    from typing import Optional


class RedisIntegration(Integration):
    identifier = "redis"

    def __init__(
        self,
        max_data_size: "Optional[int]" = _DEFAULT_MAX_DATA_SIZE,
        cache_prefixes: "Optional[list[str]]" = None,
    ) -> None:
        self.max_data_size = max_data_size
        self.cache_prefixes = cache_prefixes if cache_prefixes is not None else []

        if max_data_size is not None:
            warnings.warn(
                "The `max_data_size` parameter of `RedisIntegration` is "
                "deprecated and will be removed in version 3.0 of sentry-sdk.",
                DeprecationWarning,
                stacklevel=2,
            )

    @staticmethod
    def setup_once() -> None:
        try:
            from redis import StrictRedis, client
        except ImportError:
            raise DidNotEnable("Redis client not installed")

        _patch_redis(StrictRedis, client)
        _patch_redis_cluster()
        _patch_rb()

        try:
            _patch_rediscluster()
        except Exception:
            logger.exception("Error occurred while patching `rediscluster` library")
