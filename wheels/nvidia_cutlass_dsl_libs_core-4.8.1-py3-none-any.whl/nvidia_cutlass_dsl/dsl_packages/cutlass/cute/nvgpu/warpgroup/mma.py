# SPDX-FileCopyrightText: Copyright (c) 2025 - 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# Use of this software is governed by the terms and conditions of the
# NVIDIA End User License Agreement (EULA), available at:
# https://docs.nvidia.com/cutlass/latest/media/docs/pythonDSL/license.html
#
# Any use, reproduction, disclosure, or distribution of this software
# and related documentation outside the scope permitted by the EULA
# is strictly prohibited.

import enum
from dataclasses import dataclass
from typing import Any, Optional, Type, Union, cast
import warnings

from cutlass import base_dsl
from cutlass.cutlass_dsl import DSLUserCodeError, BaseDSL, T, DSLRuntimeError
from typing_extensions import deprecated

from cutlass._mlir import ir
import cutlass._mlir.dialects.cute as _cute_ir
import cutlass._mlir.dialects.cute_nvgpu as _cute_nvgpu_ir

from ..common import normalize_field_to_ir_name
from ..common import OperandMajorMode as _OperandMajorMode
from ...core import _pack_shape, rank, depth
from ...typing import (
    Shape,
    Tensor,
    Float16,
    BFloat16,
    Float32,
    Boolean,
    Float8E5M2,
    Float8E4M3FN,
    Int32,
    Int8,
    Uint8,
    Integer,
    Numeric,
    AddressSpace,
)
from ...atom import MmaOp as AtomMmaOp, Trait, make_atom


####################################################################################################
#
# MMA Ops and Traits
#
####################################################################################################


class WarpGroupMmaOp(AtomMmaOp):
    """
    Base class for all warpgroup-level MMA operations.
    """

    pass


@deprecated(
    "warpgroup.OperandMajorMode is deprecated, use cute.nvgpu.OperandMajorMode instead"
)
class OperandMajorMode(enum.Enum):
    """
    An enumeration for the majorness of the input operands of the MMA.
    """

    MN = _cute_ir.MajorMode.mn
    K = _cute_ir.MajorMode.k

    def __str__(self) -> str:
        return f"{self.__class__.__name__}.{self.name}"

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__}.{self.name}>"

    def __eq__(self, other: object) -> bool:
        if hasattr(other, "_to_ir") and type(other._to_ir()) is type(self._to_ir()):
            return self._to_ir() == other._to_ir()
        raise DSLRuntimeError(
            f"{self.__module__}.{self.__class__.__qualname__} cannot be compared with "
            f"{getattr(other, '__module__', '?')}.{other.__class__.__qualname__}"
        )

    def __ne__(self, other: object) -> bool:
        return not self.__eq__(other)

    def __hash__(self) -> int:
        return hash(self.value)

    @classmethod
    def _missing_(cls, value: Any) -> Optional["OperandMajorMode"]:
        if isinstance(value, str):
            value = value.upper()
            if value == "MN":
                return OperandMajorMode.MN
            elif value == "K":
                return OperandMajorMode.K
        return None

    def _to_ir(self) -> _cute_ir.MajorMode:
        return self.value


class OperandSource(enum.Enum):
    """
    An enumeration for the source memory location of the A input operand of the MMA.
    """

    RMEM = _cute_ir.MmaFragKind.rmem
    SMEM = _cute_ir.MmaFragKind.smem_desc

    def __str__(self) -> str:
        return f"{self.__class__.__name__}.{self.name}"

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__}.{self.name}>"

    def _to_ir(self) -> _cute_ir.MmaFragKind:
        return self.value


class Field(enum.Enum):
    """
    An enumeration for the fields of the MMA Atom that can be modified at runtime.
    """

    ACCUMULATE = "accum_c"

    def __str__(self) -> str:
        return f"{self.__class__.__name__}.{self.name}"

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__}.{self.name}>"

    def _to_ir_field_name(self) -> str:
        return self.value


@dataclass(frozen=True)
class MmaOp(WarpGroupMmaOp):
    a_dtype: Type[Numeric]
    b_dtype: Type[Numeric]
    acc_dtype: Type[Numeric]
    shape_mnk: Shape
    a_src: OperandSource
    a_major_mode: Union[_OperandMajorMode, OperandMajorMode]
    b_major_mode: Union[_OperandMajorMode, OperandMajorMode]

    def __post_init__(self) -> None:
        # Verify arch
        arch = BaseDSL._get_dsl().get_arch_enum()
        if not arch == base_dsl.Arch.sm_90a:
            raise DSLUserCodeError(
                f"expects arch to be {base_dsl.Arch.sm_90a}, but got {arch}",
                suggestion="Ensure env CUTE_DSL_ARCH matches your GPU architecture",
            )
        # Verify that the user provided enum values
        if not isinstance(self.a_src, OperandSource):
            raise DSLUserCodeError(
                "expects the 'a_src' Op parameter to be a warpgroup.OperandSource instance",
            )
        if not isinstance(self.a_major_mode, _OperandMajorMode) and not isinstance(
            self.a_major_mode, OperandMajorMode
        ):
            raise DSLUserCodeError(
                "expects the 'a_major_mode' Op parameter to be a cute.nvgpu.OperandMajorMode or warpgroup.OperandMajorMode (deprecated) instance",
            )
        if not isinstance(self.b_major_mode, _OperandMajorMode) and not isinstance(
            self.b_major_mode, OperandMajorMode
        ):
            raise DSLUserCodeError(
                "expects the 'b_major_mode' Op parameter to be a cute.nvgpu.OperandMajorMode or warpgroup.OperandMajorMode (deprecated) instance",
            )
        if isinstance(self.a_major_mode, OperandMajorMode) or isinstance(
            self.b_major_mode, OperandMajorMode
        ):
            warnings.warn(
                "warpgroup.OperandMajorMode is deprecated, use cute.nvgpu.OperandMajorMode instead",
                DeprecationWarning,
                stacklevel=2,
            )
            # Normalize the major modes to the new enum type
            # Since this is a frozen dataclass, we need to use the object.__setattr__ method to set the attributes
            object.__setattr__(
                self, "a_major_mode", _OperandMajorMode(self.a_major_mode.value)
            )
            object.__setattr__(
                self, "b_major_mode", _OperandMajorMode(self.b_major_mode.value)
            )

        # Verify instruction shape
        shape_mnk_tuple: Any = cast(Any, self.shape_mnk)
        if (rank(shape_mnk_tuple) not in [2, 3]) or (depth(shape_mnk_tuple) != 1):
            raise DSLUserCodeError(
                f"expected a flat rank 2 or 3 tuple for the 'shape_mnk' Op parameter, "
                f"but got {self.shape_mnk}",
            )
        m, n = shape_mnk_tuple[0], shape_mnk_tuple[1]
        if m != 64:
            raise DSLUserCodeError(f"expects the M-mode to be 64, but got {m}")
        if (n < 8) or (n > 256) or (n % 8 != 0):
            raise DSLUserCodeError(
                f"expects the N-mode to satisfy 8 <= N <= 256 and N % 8 == 0. but got {n}",
            )

    def __str__(self) -> str:
        return (
            self.__class__.descriptive_name
            + f"\n  A data type           = {self.a_dtype}"
            + f"\n  B data type           = {self.b_dtype}"
            + f"\n  Accumulator data type = {self.acc_dtype}"
            + f"\n  A source location     = {self.a_src}"
            + f"\n  A major mode          = {self.a_major_mode}"
            + f"\n  B major mode          = {self.b_major_mode}"
            + f"\n  Instruction shape MNK = {self.shape_mnk}"
        )

    def _verify_fragment_A(
        self,
        input: Tensor,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> bool:
        if input.memspace == AddressSpace.smem and isinstance(
            input.layout.type, _cute_ir.ComposedLayoutType
        ):
            raise DSLUserCodeError(
                f"Expected affine layout for {self._make_trait()}'s operand A, "
                f"but got composed layout instead: {input.layout}"
                f"\nPlease use recast_ptr(ptr, {input.layout.inner}, element_type) operation to move swizzle to the ptr",
            )
        return True

    def _verify_fragment_B(
        self,
        input: Tensor,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> bool:
        if input.memspace == AddressSpace.smem and isinstance(
            input.layout.type, _cute_ir.ComposedLayoutType
        ):
            raise DSLUserCodeError(
                f"Expected affine layout for {self._make_trait()}'s operand B, "
                f"but got composed layout instead: {input.layout}"
                f"\nPlease use recast_ptr(ptr, {input.layout.inner}, element_type) operation to move swizzle to the ptr",
            )
        return True


class MmaTraits(Trait):
    admissible_fields = [Field.ACCUMULATE]

    def _normalize_field_name(self, field: Any) -> str:
        """
        Normalize a field specifier (enum or string) into the IR logical field name.
        Accepted inputs:
          - Field.ACCUMULATE
          - "accum_c"
        """
        return normalize_field_to_ir_name(field, self.admissible_fields)

    def set(
        self,
        field: Any,
        field_value: Any,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> None:
        field_ir_name = self._normalize_field_name(field)
        bool_val = Boolean(field_value).ir_value(loc=loc, ip=ip)
        trait_ir_val = self.value
        attr = _cute_nvgpu_ir.resolve_atom_field_attr(trait_ir_val, field_ir_name)
        self.value = _cute_nvgpu_ir.atom_set_value(
            trait_ir_val, attr, bool_val, loc=loc, ip=ip
        )

    def get(
        self,
        field: Any,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> Any:
        field_ir_name = self._normalize_field_name(field)
        trait_ir_val = self.value
        attr = _cute_nvgpu_ir.resolve_atom_field_attr(trait_ir_val, field_ir_name)
        return _cute_nvgpu_ir.atom_get_value(
            Boolean.mlir_type, trait_ir_val, attr, loc=loc, ip=ip
        )


@dataclass(frozen=True)
class MmaF16BF16Op(MmaOp):
    """
    F16/BF16 warpgroup MMA Operation.

    See the `PTX documentation <https://docs.nvidia.com/cuda/parallel-thread-execution/#asynchronous-warpgroup-level-matrix-instructions-wgmma-mma>`__.
    This Operation covers the instructions using the ``.f16`` or ``.bf16`` qualifiers for the input operands.

    **Supported data type combinations:**

    +-------------+-------------+----------+-------+
    | A Data Type | B Data Type | Acc Type | Mma-K |
    +=============+=============+==========+=======+
    | F16         | F16         | F16, F32 | 16    |
    +-------------+-------------+----------+-------+
    | BF16        | BF16        | F32      | 16    |
    +-------------+-------------+----------+-------+

    **Supported architectures:** sm_90a

    **Constraints:**

    * Mma-M = 64
    * 8 <= Mma-N <= 256, step 8
    * A and B support both K-major and MN-major (transpose) when A is in shared memory (descriptor).
      When A is in registers, only B can be transposed.

    **Execution Model:**

    * WGMMA is asynchronous and collective at warpgroup scope (4 contiguous warps).
      In user code, ``cute.gemm(...)`` should be issued warpgroup-uniformly.
    * Before issuing ``cute.gemm(...)``, call ``cute.nvgpu.warpgroup.fence()`` to order
      prior register writes to accumulator/A fragments with subsequent WGMMA reads.
    * After issuing ``cute.gemm(...)``, call ``cute.nvgpu.warpgroup.commit_group()``.
      Use ``cute.nvgpu.warpgroup.wait_group(N)`` before consuming or reusing accumulator
      values from pending WGMMA groups.

    .. code-block:: python

        cute.nvgpu.warpgroup.fence()
        cute.gemm(tiled_mma, acc, tCrA[tile_crd], tCrB[tile_crd], acc)
        cute.nvgpu.warpgroup.commit_group()
        cute.nvgpu.warpgroup.wait_group(1)
        # ... pipeline continues ...
        cute.nvgpu.warpgroup.wait_group(0)
    """

    descriptive_name = "warpgroup F16/BF16 MMA Operation"

    def __init__(
        self,
        ab_dtype: Type[Numeric],
        acc_dtype: Type[Numeric],
        instruction_shape: Shape,
        a_src: OperandSource,
        a_major_mode: Union[_OperandMajorMode, OperandMajorMode],
        b_major_mode: Union[_OperandMajorMode, OperandMajorMode],
    ) -> None:
        super().__init__(
            ab_dtype,
            ab_dtype,
            acc_dtype,
            instruction_shape,
            a_src,
            a_major_mode,
            b_major_mode,
        )
        self._verify()

    def _verify(self) -> None:
        # Input data type verification
        if self.a_dtype not in [Float16, BFloat16]:
            raise DSLUserCodeError(
                "expects the 'ab_dtype' Op parameter to be one of Float16 or BFloat16",
            )
        assert self.b_dtype == self.a_dtype, "a_dtype and b_dtype must be the same"
        # Accumulator data type verification
        if self.acc_dtype not in [Float16, Float32]:
            raise DSLUserCodeError(
                "expects the 'acc_dtype' Op parameter to be one of Float16 or Float32",
            )
        if (self.a_dtype == BFloat16) and (self.acc_dtype != Float32):
            raise DSLUserCodeError(
                "expects the 'acc_dtype' Op parameter to be Float32 when 'ab_dtype' is BFloat16",
            )
        # Verify the instruction shape
        instruction_k = 16
        shape_mnk_tuple: Any = cast(Any, self.shape_mnk)
        if rank(shape_mnk_tuple) == 2:
            object.__setattr__(self, "shape_mnk", (*shape_mnk_tuple, instruction_k))
            shape_mnk_tuple = cast(Any, self.shape_mnk)
        if shape_mnk_tuple[2] != instruction_k:
            raise DSLUserCodeError(
                f"expects the instruction extent in the K-mode to be {instruction_k}, "
                f"but got {shape_mnk_tuple[2]}",
            )

    def _make_trait(
        self,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
        **kwargs: Any,
    ) -> "MmaF16BF16Trait":
        shape_mnk = _pack_shape(self.shape_mnk, loc=loc, ip=ip)
        ty = _cute_nvgpu_ir.MmaAtomSM90Type.get(
            shape_mnk.type.attribute,
            self.a_major_mode._to_ir(),
            self.b_major_mode._to_ir(),
            self.a_dtype.mlir_type,
            self.b_dtype.mlir_type,
            self.acc_dtype.mlir_type,
            self.a_src._to_ir(),
        )
        return MmaF16BF16Trait(
            make_atom(ty, [Boolean(False).ir_value(loc=loc, ip=ip)], loc=loc, ip=ip)
        )


class MmaF16BF16Trait(MmaTraits):
    pass


@dataclass(frozen=True)
class MmaF8Op(MmaOp):
    """
    F8 warpgroup MMA Operation.

    See the `PTX documentation <https://docs.nvidia.com/cuda/parallel-thread-execution/#asynchronous-warpgroup-level-matrix-instructions-wgmma-mma>`__.
    This Operation covers the instructions using the ``.e4m3`` or ``.e5m2`` qualifiers for the input operands.

    **Supported data type combinations:**

    +-------------+-------------+----------+-------+
    | A Data Type | B Data Type | Acc Type | Mma-K |
    +=============+=============+==========+=======+
    | E4M3, E5M2  | E4M3, E5M2  | F16, F32 | 32    |
    +-------------+-------------+----------+-------+

    **Supported architectures:** sm_90a

    **Constraints:**

    * Mma-M = 64
    * 8 <= Mma-N <= 256, step 8
    * A and B data types are independent (mixed FP8 allowed)
    * Transpose (MN-major) is not supported for A or B. Both operands must be K-major.

    **Execution Model:**

    * WGMMA is asynchronous and collective at warpgroup scope (4 contiguous warps).
      In user code, ``cute.gemm(...)`` should be issued warpgroup-uniformly.
    * Before issuing ``cute.gemm(...)``, call ``cute.nvgpu.warpgroup.fence()`` to order
      prior register writes to accumulator/A fragments with subsequent WGMMA reads.
    * After issuing ``cute.gemm(...)``, call ``cute.nvgpu.warpgroup.commit_group()``.
      Use ``cute.nvgpu.warpgroup.wait_group(N)`` before consuming or reusing accumulator
      values from pending WGMMA groups.

    .. code-block:: python

        cute.nvgpu.warpgroup.fence()
        cute.gemm(tiled_mma, acc, tCrA[tile_crd], tCrB[tile_crd], acc)
        cute.nvgpu.warpgroup.commit_group()
        cute.nvgpu.warpgroup.wait_group(1)
        # ... pipeline continues ...
        cute.nvgpu.warpgroup.wait_group(0)
    """

    descriptive_name = "warpgroup F8 MMA Operation"

    def __init__(
        self,
        a_dtype: Type[Numeric],
        b_dtype: Type[Numeric],
        acc_dtype: Type[Numeric],
        instruction_shape: Shape,
        a_src: OperandSource,
        a_major_mode: Union[_OperandMajorMode, OperandMajorMode],
        b_major_mode: Union[_OperandMajorMode, OperandMajorMode],
    ) -> None:
        super().__init__(
            a_dtype,
            b_dtype,
            acc_dtype,
            instruction_shape,
            a_src,
            a_major_mode,
            b_major_mode,
        )
        self._verify()

    def _verify(self) -> None:
        # Input data type verification
        if self.a_dtype not in [Float8E5M2, Float8E4M3FN]:
            raise DSLUserCodeError(
                "expects the 'a_dtype' Op parameter to be one of Float8E5M2 or Float8E4M3FN",
            )
        if self.b_dtype not in [Float8E5M2, Float8E4M3FN]:
            raise DSLUserCodeError(
                "expects the 'b_dtype' Op parameter to be one of Float8E5M2 or Float8E4M3FN",
            )
        # Accumulator data type verification
        if self.acc_dtype not in [Float16, Float32]:
            raise DSLUserCodeError(
                "expects the 'acc_dtype' Op parameter to be one of Float16 or Float32",
            )
        # Verify the instruction shape
        instruction_k = 32
        shape_mnk_tuple: Any = cast(Any, self.shape_mnk)
        if rank(shape_mnk_tuple) == 2:
            object.__setattr__(self, "shape_mnk", (*shape_mnk_tuple, instruction_k))
            shape_mnk_tuple = cast(Any, self.shape_mnk)
        if shape_mnk_tuple[2] != instruction_k:
            raise DSLUserCodeError(
                f"expects the instruction extent in the K-mode to be {instruction_k}, "
                f"but got {shape_mnk_tuple[2]}",
            )

    def _make_trait(
        self,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
        **kwargs: Any,
    ) -> "MmaF8Trait":
        shape_mnk = _pack_shape(self.shape_mnk, loc=loc, ip=ip)
        ty = _cute_nvgpu_ir.MmaAtomSM90Type.get(
            shape_mnk.type.attribute,
            self.a_major_mode._to_ir(),
            self.b_major_mode._to_ir(),
            self.a_dtype.mlir_type,
            self.b_dtype.mlir_type,
            self.acc_dtype.mlir_type,
            self.a_src._to_ir(),
        )
        return MmaF8Trait(
            make_atom(ty, [Boolean(False).ir_value(loc=loc, ip=ip)], loc=loc, ip=ip)
        )


class MmaF8Trait(MmaTraits):
    pass


@dataclass(frozen=True)
class MmaI8Op(MmaOp):
    """
    I8 warpgroup MMA Operation.

    See the `PTX documentation <https://docs.nvidia.com/cuda/parallel-thread-execution/#asynchronous-warpgroup-level-matrix-instructions-wgmma-mma>`__.
    This Operation covers the instructions using the ``.s8`` or ``.u8`` qualifiers for the input operands.

    **Supported data type combinations:**

    +-------------+-------------+----------+-------+
    | A Data Type | B Data Type | Acc Type | Mma-K |
    +=============+=============+==========+=======+
    | Int8, Uint8 | Int8, Uint8 | Int32    | 32    |
    +-------------+-------------+----------+-------+

    **Supported architectures:** sm_90a

    **Constraints:**

    * Mma-M = 64
    * Mma-N in {8, 24} or Mma-N % 16 == 0, with 8 <= Mma-N <= 256
    * A and B signedness are independent (mixed signed/unsigned allowed)
    * Transpose (MN-major) is not supported for A or B. Both operands must be K-major.

    **Execution Model:**

    * WGMMA is asynchronous and collective at warpgroup scope (4 contiguous warps).
      In user code, ``cute.gemm(...)`` should be issued warpgroup-uniformly.
    * Before issuing ``cute.gemm(...)``, call ``cute.nvgpu.warpgroup.fence()`` to order
      prior register writes to accumulator/A fragments with subsequent WGMMA reads.
    * After issuing ``cute.gemm(...)``, call ``cute.nvgpu.warpgroup.commit_group()``.
      Use ``cute.nvgpu.warpgroup.wait_group(N)`` before consuming or reusing accumulator
      values from pending WGMMA groups.

    .. code-block:: python

        cute.nvgpu.warpgroup.fence()
        cute.gemm(tiled_mma, acc, tCrA[tile_crd], tCrB[tile_crd], acc)
        cute.nvgpu.warpgroup.commit_group()
        cute.nvgpu.warpgroup.wait_group(1)
        # ... pipeline continues ...
        cute.nvgpu.warpgroup.wait_group(0)
    """

    descriptive_name = "warpgroup I8 MMA Operation"

    def __init__(
        self,
        a_dtype: Type[Numeric],
        b_dtype: Type[Numeric],
        acc_dtype: Type[Numeric],
        instruction_shape: Shape,
        a_src: OperandSource,
        a_major_mode: Union[_OperandMajorMode, OperandMajorMode],
        b_major_mode: Union[_OperandMajorMode, OperandMajorMode],
    ) -> None:
        super().__init__(
            a_dtype,
            b_dtype,
            acc_dtype,
            instruction_shape,
            a_src,
            a_major_mode,
            b_major_mode,
        )
        self._verify()

    def _verify(self) -> None:
        # Input data type verification
        if self.a_dtype not in [Int8, Uint8]:
            raise DSLUserCodeError(
                "expects the 'a_dtype' Op parameter to be one of Int8 or Uint8",
            )
        if self.b_dtype not in [Int8, Uint8]:
            raise DSLUserCodeError(
                "expects the 'b_dtype' Op parameter to be one of Int8 or Uint8",
            )
        # Accumulator data type verification
        if self.acc_dtype != Int32:
            raise DSLUserCodeError(
                "expects the 'acc_dtype' Op parameter must be Int32",
            )

        # Verify the instruction shape
        instruction_k = 32
        shape_mnk_tuple: Any = cast(Any, self.shape_mnk)
        if rank(shape_mnk_tuple) == 2:
            object.__setattr__(self, "shape_mnk", (*shape_mnk_tuple, instruction_k))
            shape_mnk_tuple = cast(Any, self.shape_mnk)
        if shape_mnk_tuple[2] != instruction_k:
            raise DSLUserCodeError(
                f"expects the instruction extent in the K-mode to be {instruction_k}, "
                f"but got {shape_mnk_tuple[2]}",
            )

        n = shape_mnk_tuple[1]
        if not (n >= 8 and n <= 256 and (n == 8 or n == 24 or n % 16 == 0)):
            raise DSLUserCodeError(
                "expects the N-mode to satisfy N=8*i where i={1,2,3,4} ",
                suggestion=f"or N=16*i where i={{3,4,...,15,16}}. But got {n}",
            )

    def _make_trait(
        self,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
        **kwargs: Any,
    ) -> "MmaI8Trait":
        shape_mnk = _pack_shape(self.shape_mnk, loc=loc, ip=ip)
        # MmaI8 only operates on integer dtypes.
        assert issubclass(self.a_dtype, Integer) and issubclass(self.b_dtype, Integer)
        ty = _cute_nvgpu_ir.MmaAtomSM90Type.get(
            shape_mnk.type.attribute,
            self.a_major_mode._to_ir(),
            self.b_major_mode._to_ir(),
            (T.si8() if self.a_dtype.signed else T.ui8()),
            (T.si8() if self.b_dtype.signed else T.ui8()),
            self.acc_dtype.mlir_type,
            self.a_src._to_ir(),
        )
        return MmaI8Trait(
            make_atom(ty, [Boolean(False).ir_value(loc=loc, ip=ip)], loc=loc, ip=ip)
        )


class MmaI8Trait(MmaTraits):
    pass


####################################################################################################
#
# SMEM layout atoms
#
####################################################################################################


class SmemLayoutAtomKind(enum.Enum):
    """
    Enum class for the kinds of SMEM layout atoms for SM90.

    Given a swizzle kind, an SMEM layout atom is the compact layout of smallest size that can
    be used to construct an SMEM layout using blocked product for operand A or B such that the
    resulting layout is legal for both TMA and UMMA.

    Note that there are other ways of creating legal layouts for operand A and B.
    """

    MN_INTER = enum.auto()
    MN_SW32 = enum.auto()
    MN_SW64 = enum.auto()
    MN_SW128 = enum.auto()
    K_INTER = enum.auto()
    K_SW32 = enum.auto()
    K_SW64 = enum.auto()
    K_SW128 = enum.auto()
