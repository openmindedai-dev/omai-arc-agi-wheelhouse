# SPDX-FileCopyrightText: Copyright (c) 2025 - 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# Use of this software is governed by the terms and conditions of the
# NVIDIA End User License Agreement (EULA), available at:
# https://docs.nvidia.com/cutlass/latest/media/docs/pythonDSL/license.html
#
# Any use, reproduction, disclosure, or distribution of this software
# and related documentation outside the scope permitted by the EULA
# is strictly prohibited.

import importlib
import warnings
from typing import Any

from .static_persistent_tile_scheduler import (
    WorkTileInfo,
    PersistentTileSchedulerParams,
    StaticPersistentTileScheduler,
    StaticPersistentRuntimeTileScheduler,
)

from .dynamic_persistent_tile_scheduler import (
    ClcDynamicPersistentTileSchedulerParams,
    ClcDynamicPersistentTileScheduler,
)

from .hardware_info import HardwareInfo

from .blackwell_helpers import (
    cluster_shape_to_tma_atom_A,
    cluster_shape_to_tma_atom_B,
    cluster_shape_to_tma_atom_SFB,
    compute_epilogue_tile_shape,
    get_permutation_mnk,
    get_smem_layout_atom_ab,
    get_smem_layout_atom_epi,
    get_smem_store_op,
    get_tmem_load_op,
    make_smem_layout,
    make_smem_layout_a,
    make_smem_layout_b,
    make_smem_layout_epi,
    make_trivial_tiled_mma,
    make_blockscaled_trivial_tiled_mma,
)

from .hopper_helpers import (
    sm90_get_smem_store_op,
    get_smem_layout_atom as sm90_get_smem_layout_atom,
    make_smem_layout_a as sm90_make_smem_layout_a,
    make_smem_layout_b as sm90_make_smem_layout_b,
    make_smem_layout_epi as sm90_make_smem_layout_epi,
    make_trivial_tiled_mma as sm90_make_trivial_tiled_mma,
    compute_tile_shape_or_override,
)

from .blockscaled_layout import (
    BlockScaledBasicChunk,
    tile_atom_to_shape_SF,
    make_smem_layout_sfa,
    make_smem_layout_sfb,
    make_tmem_layout_sfa,
    make_tmem_layout_sfb,
)

from .grouped_gemm_persistent_tile_scheduler import (
    GroupSearchResult,
    GroupedGemmGroupSearchState,
    create_initial_search_state,
    GroupedWorkTileInfo,
    StaticPersistentGroupTileScheduler,
    GroupedGemmTileSchedulerHelper,
)

from .tensormap_manager import TensorMapManager

from .smem_allocator import (
    SmemAllocator,
    get_smem_capacity_in_bytes,
    get_kernel_smem_size,
)
from .tmem_allocator import (
    TmemAllocator,
    TmemBufferPool,
    get_num_tmem_alloc_cols,
    compute_tmem_cols_from_layout,
)

from . import layout
from .block import block_copy

from .mixed_input_helpers import (
    TransformMode,
    scale_tma_partition,
    transform_partition,
    scale_partition,
    epilog_gmem_copy_and_partition,
    epilog_smem_copy_and_partition,
    epilog_tmem_copy_and_partition,
    get_gmem_layout_scale,
    get_smem_layout_scale,
    compute_smem_layout,
    get_transform_a_source,
    get_tma_atom_kind,
    get_copy_atom_a_transform,
    is_valid_scale_granularity,
    is_shuffle_a,
    is_valid_tensor_alignment,
    is_valid_mma_tiler_and_cluster_shape,
    get_divisibility,
    create_initial_contiguous_group_search_state,
    contiguous_group_search,
    make_contiguous_group_work_tile_info,
    cvt_tensor_a,
    cvt_tensor_a_mxf8,
    store_transformed_a,
)

from . import gemm
from . import distributed

from . import hopper_helpers as sm90
from . import blackwell_helpers as sm100
from . import rubin_helpers as sm107
from .print_latex import (
    print_latex,
    print_latex_tv,
)

from .tensor_helpers import (
    is_fp8_dtype,
    create_cute_tensor_for_fp8,
)

__all__ = [
    "get_smem_capacity_in_bytes",
    "get_kernel_smem_size",
    "SmemAllocator",
    "TmemAllocator",
    "TmemBufferPool",
    "get_num_tmem_alloc_cols",
    "compute_tmem_cols_from_layout",
    "LayoutEnum",
    "WorkTileInfo",
    "PersistentTileSchedulerParams",
    "StaticPersistentTileScheduler",
    "StaticPersistentRuntimeTileScheduler",
    "TensorMapUpdateMode",
    "TensorMapManager",
    "GroupSearchResult",
    "GroupedGemmGroupSearchState",
    "create_initial_search_state",
    "GroupedGemmTileSchedulerHelper",
    "HardwareInfo",
    "TransformMode",
    "scale_tma_partition",
    "transform_partition",
    "scale_partition",
    "get_gmem_layout_scale",
    "get_smem_layout_scale",
    "compute_smem_layout",
    "get_transform_a_source",
    "get_tma_atom_kind",
    "get_copy_atom_a_transform",
    "is_valid_scale_granularity",
    "get_divisibility",
    "epilogue_tma_store",
    "epilogue",
    "create_tensor_a",
    "cluster_shape_to_tma_atom_A",
    "cluster_shape_to_tma_atom_B",
    "cluster_shape_to_tma_atom_SFB",
    "compute_epilogue_tile_shape",
    "get_permutation_mnk",
    "get_smem_layout_atom_ab",
    "get_smem_layout_atom_epi",
    "get_smem_store_op",
    "get_tmem_load_op",
    "make_smem_layout",
    "make_smem_layout_a",
    "make_smem_layout_b",
    "make_smem_layout_epi",
    "make_trivial_tiled_mma",
    "make_blockscaled_trivial_tiled_mma",
    "sm90_get_smem_layout_atom",
    "sm90_make_trivial_tiled_mma",
    "sm90",
    "sm100",
    "gemm",
    "block_copy",
    "ClcDynamicPersistentTileSchedulerParams",
    "ClcDynamicPersistentTileScheduler",
    "print_latex",
    "print_latex_tv",
    "PALETTES",
    "Band",
    "is_fp8_dtype",
    "create_cute_tensor_for_fp8",
    "distributed",
]

# Enums and shared data objects moved out of cutlass.utils compare by object
# identity, so the canonical objects themselves must be handed out rather
# than deprecated wrapper copies. A package-level __getattr__ (PEP 562) adds
# the deprecation warning a wrapper cannot.
_MOVED_ALIASES = {
    "LayoutEnum": "cutlass.tensor_utils",
    "TensorMapUpdateMode": "cutlass.tensor_utils",
    "SmemPartition": "cutlass.memory",
    "PALETTES": "cutlass.cute.viz",
    "Band": "cutlass.cute.viz",
}


def __getattr__(name: str) -> Any:
    if name in _MOVED_ALIASES:
        home = _MOVED_ALIASES[name]
        warnings.warn(
            f"cutlass.utils.{name} is deprecated; use {home}.{name} instead. "
            "It will be removed in a future release.",
            DeprecationWarning,
            stacklevel=2,
        )
        return getattr(importlib.import_module(home), name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
